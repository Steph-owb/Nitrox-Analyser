/*
 * ============================================================================
 *  ANALYSEUR NITROX v2.1  —  PHASE 2
 *  mesure O2 compensee en pression · horodatage · journal · interface refondue
 *  9H2WB / F5OWB  —  septembre 2026
 * ============================================================================
 *
 *  MATERIEL
 *      Elecrow CrowPanel 1.28" HMI ESP32-S3 Rotary Display (240x240 GC9A01)
 *      Adafruit ADS1115  (ADA1085)   0x48   \
 *      Adafruit DS3231   (ADA5188)   0x68    >  bus I2C EXTERNE, GPIO38/39
 *      Adafruit BMP581   (ADA5959)   0x46/47/
 *      Cellule galvanique Vandagraph R-17VAN (0110217)
 *      Adafruit PowerBoost 1000C + accu LiPo 3,7 V
 *
 *  CHAINE DE MESURE
 *      Cellule -> jack 3,5 mm (pointe = O2+, corps = O2-)
 *              -> ADS1115 AIN0 / AIN1 en DIFFERENTIEL
 *              -> PGA +/-256 mV  =>  1 LSB = 7,8125 uV
 *      Masse reprise A L'EMBASE JACK (liaison Kelvin) : une cellule totalement
 *      flottante peut sortir de la plage de mode commun de l'ADS1115.
 *
 *  COMPENSATION EN PRESSION  —  nouveaute de la phase 2
 *      Une cellule galvanique repond a la PRESSION PARTIELLE d'oxygene :
 *          V = k . FO2 . Pabs
 *      La calibration a l'air memorise V_cal sous la pression P_cal. Plus tard,
 *      sous la pression P :
 *          FO2 = 0,209 . (V / V_cal) . (P_cal / P)
 *      Sans ce facteur, une calibration a Malte (niveau de la mer, 1013 hPa)
 *      suivie d'une mesure a Massongy (~500 m, ~955 hPa) donne une lecture
 *      BASSE de 6 % relatif : un EAN32 s'affiche 30,1 %. C'est exactement
 *      l'erreur que le BMP581 supprime.
 *
 *      Le calcul n'utilise que la pression ABSOLUE, qui ne demande aucun
 *      reglage. L'altitude reglee dans la page AMBIANCE ne sert qu'a afficher
 *      un QNH lisible : elle n'entre PAS dans le calcul du %O2.
 *
 *  COMMANDES  —  encodeur seul (regle de conception : le tactile n'est jamais
 *  un passage oblige, il ne repond pas aux doigts mouilles ou gantes)
 *
 *      Deux niveaux, comme sur un bouton intelligent :
 *
 *      NAVIGATION (par defaut)   rotation = changer de page (5 pages)
 *                                appui court = entrer dans la page
 *
 *      EDITION (page entree)     rotation = regler la valeur de la page
 *                                appui court = sortir
 *
 *      Appuis longs, selon la page :
 *          MESURE  (non fige)  1,5 s  -> calibration a l'air 20,9 %
 *          MESURE  (fige)      1,5 s  -> enregistrer au journal
 *          JOURNAL             2,5 s  -> effacer le journal
 *      Un arc de progression accompagne l'appui : on voit ce qui va se passer
 *      avant de relacher, et on peut renoncer.
 *
 *  ANNEAU RGB
 *      ambre pulse = stabilisation     vert fixe = mesure verrouillee
 *      rouge       = defaut            bleu      = calibration en cours
 *
 *  BIBLIOTHEQUES (gestionnaire de bibliotheques de l'IDE Arduino)
 *      LovyanGFX           >= 1.1
 *      Adafruit ADS1X15    >= 2.4
 *      Adafruit NeoPixel   >= 1.12
 *      Adafruit BMP5xx     >= 1.0      (tire Adafruit BusIO + Unified Sensor)
 *      RTClib              >= 2.1
 *
 *  CARTE : "ESP32S3 Dev Module" · PSRAM = OPI PSRAM · Flash 16MB (128Mb)
 *          USB CDC On Boot = Enabled
 *
 *          Partition Scheme = "Huge APP (3MB No OTA/1MB SPIFFS)"
 *          C'EST IMPERATIF. LittleFS monte par defaut la partition dont
 *          l'ETIQUETTE est "spiffs". Or les deux profils 16 Mo de l'IDE
 *          ("16M Flash (2MB APP/12.5MB FATFS)" et "16M Flash (3MB APP/
 *          9.9MB FATFS)") ne creent qu'une partition "ffat" : avec eux,
 *          LittleFS.begin() echoue et le journal n'est jamais ecrit sur le
 *          flash. Le profil Huge APP donne 3 Mo d'application — trois fois
 *          ce que pese ce croquis — et 896 ko de journal, soit environ
 *          14 000 mesures.
 *
 *  COMMANDES SERIE (115200 bauds, terminer par Entree)
 *      d   deverser le journal CSV sur la liaison serie
 *      i   etat des peripheriques et de la calibration
 *      T<epoch>   regler l'horloge, ex. T1790000000
 *      ?   aide
 *
 *  Licence CC0 / domaine public.
 *
 *  AVERTISSEMENT : appareil non certifie. Toute analyse critique doit etre
 *  recoupee sur un second instrument independant. Ne jamais mettre la cellule
 *  en pression : restricteur DIN calibre + te de prelevement a sortie libre.
 * ============================================================================
 */

#define LGFX_USE_V1
#include <LovyanGFX.hpp>
#include <Wire.h>
#include <Adafruit_ADS1X15.h>
#include <Adafruit_NeoPixel.h>
#include <Adafruit_BMP5xx.h>
#include <RTClib.h>
#include <Preferences.h>
#include <LittleFS.h>
#include <WiFi.h>
#include <esp_bt.h>
#include <math.h>
#include <string.h>

// ===========================================================================
//  BROCHAGE  —  CrowPanel 1.28" HMI Rotary (wiki Elecrow)
// ===========================================================================
static const int PIN_LCD_SCLK = 10;
static const int PIN_LCD_MOSI = 11;
static const int PIN_LCD_DC   = 3;
static const int PIN_LCD_CS   = 9;
static const int PIN_LCD_RST  = 14;
static const int PIN_LCD_BL   = 46;   // retroeclairage, actif haut

// ATTENTION : sans ces deux broches a l'etat haut, le panneau reste NOIR.
static const int PIN_PANEL_EN1 = 1;   // alimentation dalle
static const int PIN_PANEL_EN2 = 2;   // anode LED retroeclairage

static const int PIN_ENC_A  = 45;
static const int PIN_ENC_B  = 42;
static const int PIN_ENC_SW = 41;     // actif bas

static const int PIN_RGB     = 48;    // anneau WS2812
static const int RGB_COUNT   = 5;
static const int PIN_PWR_LED = 40;    // temoin rouge integre

// Bus I2C EXTERNE (connecteurs STEMMA QT chaines). NE PAS confondre avec le bus
// du tactile CST816D, qui est sur GPIO6/7.
static const int PIN_EXT_SDA = 38;
static const int PIN_EXT_SCL = 39;

static const uint8_t ADDR_BMP581_A = 0x46;   // adresse par defaut Adafruit
static const uint8_t ADDR_BMP581_B = 0x47;   // si le pont d'adresse est coupe

// ===========================================================================
//  PARAMETRES METROLOGIQUES
// ===========================================================================
static const float AIR_O2_PCT = 20.9f;   // fraction d'O2 de l'air sec

// Fenetre de validite a l'air, calee sur la fiche technique R-17VAN
// (sortie nominale 7 a 13 mV), avec marge pour la dispersion de fabrication.
static const float CAL_MV_MIN = 4.0f;
static const float CAL_MV_MAX = 35.0f;

// Seuil de fin de vie. Il DOIT rester sous le minimum d'une cellule neuve
// (7 mV), sinon une cellule neuve mais basse serait signalee a tort.
static const float CELL_MV_WARN = 6.0f;

static const uint8_t  AVG_SIZE      = 24;     // profondeur du moyennage
static const uint16_t CAL_WINDOW_MS = 4000;   // integration a la calibration

// Critere de stabilite : ecart pic-a-pic sur la fenetre glissante.
// Le bruit de l'ADS1115 en PGA +/-256 mV est de 1 a 2 LSB (8 a 16 uV RMS) ;
// on retient le plus grand de 50 uV et de 0,4 % de la lecture.
static const float STABLE_MV_FLOOR = 0.050f;
static const float STABLE_REL      = 0.004f;

static const float   PPO2_TABLE[] = { 1.2f, 1.4f, 1.6f };
static const uint8_t PPO2_COUNT   = sizeof(PPO2_TABLE) / sizeof(PPO2_TABLE[0]);

static const uint16_t HOLD_CAL_MS   = 1500;   // appui long ordinaire
static const uint16_t HOLD_WIPE_MS  = 2500;   // effacement du journal
static const uint16_t DEBOUNCE_MS   = 40;
static const float    MOD_MAX_DISP  = 99.9f;

// Une calibration plus vieille que ceci n'est pas rechargee telle quelle :
// on redemande une calibration a l'air.
static const uint32_t CAL_MAX_AGE_S = 24UL * 3600UL;

// Plage de plausibilite du rapport P_cal / P_mesure. Au-dela, ce n'est plus de
// la meteo : c'est un changement d'altitude majeur ou un capteur en defaut.
static const float PRATIO_MIN = 0.80f;
static const float PRATIO_MAX = 1.25f;

// Temperature de travail recommandee de la cellule.
static const float TEMP_MIN_OK = 5.0f;
static const float TEMP_MAX_OK = 35.0f;

// Journal
static const uint8_t  LOG_RAM     = 40;       // entrees consultables a l'ecran
static const char     LOG_PATH[]  = "/journal.csv";

// ===========================================================================
//  AFFICHEUR  —  configuration LovyanGFX (valeurs du wiki Elecrow)
// ===========================================================================
class LGFX : public lgfx::LGFX_Device {
  lgfx::Panel_GC9A01 _panel;
  lgfx::Bus_SPI      _bus;
public:
  LGFX(void) {
    {
      auto cfg = _bus.config();
      cfg.spi_host   = SPI2_HOST;
      cfg.spi_mode   = 0;
      cfg.freq_write = 80000000;
      cfg.freq_read  = 20000000;
      cfg.spi_3wire  = true;
      cfg.use_lock   = true;
      cfg.dma_channel = SPI_DMA_CH_AUTO;
      cfg.pin_sclk   = PIN_LCD_SCLK;
      cfg.pin_mosi   = PIN_LCD_MOSI;
      cfg.pin_miso   = -1;
      cfg.pin_dc     = PIN_LCD_DC;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    {
      auto cfg = _panel.config();
      cfg.pin_cs          = PIN_LCD_CS;
      cfg.pin_rst         = PIN_LCD_RST;
      cfg.pin_busy        = -1;
      cfg.memory_width    = 240;
      cfg.memory_height   = 240;
      cfg.panel_width     = 240;
      cfg.panel_height    = 240;
      cfg.offset_x        = 0;
      cfg.offset_y        = 0;
      cfg.offset_rotation = 0;
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits  = 1;
      cfg.readable        = false;
      cfg.invert          = true;
      cfg.rgb_order       = false;
      cfg.dlen_16bit      = false;
      cfg.bus_shared      = false;
      _panel.config(cfg);
    }
    setPanel(&_panel);
  }
};

static LGFX        tft;
static LGFX_Sprite spr(&tft);          // double tampon 240x240 en PSRAM

static Adafruit_ADS1115  ads;
static Adafruit_NeoPixel ring(RGB_COUNT, PIN_RGB, NEO_GRB + NEO_KHZ800);
static Adafruit_BMP5xx   bmp;
static RTC_DS3231        rtc;
static Preferences       prefs;

// ===========================================================================
//  PALETTE
// ===========================================================================
//  Noir pur en fond, blanc pur pour la grandeur mesuree : c'est le rapport
//  noir/blanc affiche qui fait le contraste percu d'un IPS en plein soleil.
//  Les couleurs ne portent jamais seules une information : elles doublent un
//  texte. Un ecran lave par le soleil reste donc utilisable.
static const uint16_t COL_BG     = 0x0000;   // noir
static const uint16_t COL_FG     = 0xFFFF;   // blanc pur
static const uint16_t COL_TEXT   = 0xE73C;   // blanc casse, textes secondaires
static const uint16_t COL_DIM    = 0x8410;   // gris moyen, etiquettes
static const uint16_t COL_MUTE   = 0x4208;   // gris sombre, valeurs inactives
static const uint16_t COL_TRACK  = 0x1884;   // fond de piste de l'arc
static const uint16_t COL_CARD   = 0x10A2;   // fond de pastille
static const uint16_t COL_GREEN  = 0x0390;   // 0,224,130
static const uint16_t COL_TEAL   = 0x035C;   // 0,208,224
static const uint16_t COL_BLUE   = 0x429F;   // 64,160,255
static const uint16_t COL_AMBER  = 0xFAC4;   // 255,176,32
static const uint16_t COL_RED    = 0xF929;   // 255,72,72

// Degrade de l'arc de mesure : bleu froid a 0 %, vert a 100 %.
static const uint16_t ARC_C0 = 0x07BF;       // 0,120,255
static const uint16_t ARC_C1 = 0x0391;       // 0,230,140

static const int CX = 120, CY = 120;         // centre de la dalle ronde
static const float ARC_START = 135.0f;       // 7 h 30
static const float ARC_SPAN  = 270.0f;       // sens horaire, ouverture en bas
static const int   ARC_R0 = 96, ARC_R1 = 112;
static const int   TICK_R0 = 116, TICK_R1 = 123;

// ===========================================================================
//  ETAT
// ===========================================================================
enum UiState : uint8_t {
  ST_ADC_FAULT,    // ADS1115 injoignable
  ST_UNCAL,        // pas encore calibre
  ST_CELL_FAULT,   // cellule hors fenetre de calibration
  ST_CALIB,        // calibration en cours
  ST_SETTLING,     // acquisition, pas encore stable
  ST_OK            // mesure valide et stable
};

enum Page : uint8_t {
  PG_MESURE, PG_PLONGEE, PG_AMBIANCE, PG_JOURNAL, PG_CELLULE, PG_COUNT
};

static float   ringBuf[AVG_SIZE];
static uint8_t ringIdx  = 0;
static bool    ringFull = false;
static float   lastMv   = 0.0f;

static float    calMv    = 0.0f;       // tension memorisee a l'air
static float    calHpa   = 0.0f;       // pression absolue a la calibration
static uint32_t calUnix  = 0;          // horodatage de la calibration
static bool     calValid = false;
static bool     cellWeak = false;

static bool adcOk   = false;
static bool baroOk  = false;
static bool rtcOk   = false;
static bool fsOk    = false;
static bool rtcLost = false;           // pile morte : heure non fiable

static float pressHpa = 1013.25f;      // pression absolue mesuree
static float tempC    = 20.0f;
static int   altSetM  = 0;             // altitude du lieu, reglee a la main

static uint8_t ppo2Idx = 1;            // 1,4 bar par defaut
static bool    frozen  = false;
static float   frozenPct  = 0.0f;
static float   frozenMv   = 0.0f;
static float   frozenHpa  = 1013.25f;
static float   frozenTemp = 20.0f;
static uint32_t frozenUnix = 0;

static UiState state = ST_UNCAL;
static uint8_t page  = PG_MESURE;
static bool    focus = false;          // niveau 2 : la molette regle la page

static unsigned long lastDraw    = 0;
static unsigned long lastLedTick = 0;
static unsigned long lastEnv     = 0;
static bool          ledPhase    = false;
static char          flashMsg[24] = "";
static unsigned long flashUntil  = 0;

// ---------------------------------------------------------------------------
//  JOURNAL
// ---------------------------------------------------------------------------
struct LogEntry {
  uint32_t stamp;      // epoch Unix
  float pct, mv, refMv, hpa, temp, ppo2, mod;
};
static LogEntry logBuf[LOG_RAM];
static uint8_t  logCount = 0;          // entrees presentes dans logBuf
static uint16_t logTotal = 0;          // entrees ecrites dans le fichier
static uint8_t  logView  = 0;          // 0 = la plus recente

// ---------------------------------------------------------------------------
//  ENCODEUR  —  decodage quadrature par table, sur interruption
// ---------------------------------------------------------------------------
static volatile int32_t encAccum = 0;
static volatile uint8_t encPrev  = 0;

static const int8_t ENC_TABLE[16] = {
   0, -1,  1,  0,
   1,  0,  0, -1,
  -1,  0,  0,  1,
   0,  1, -1,  0
};

static void IRAM_ATTR encIsr() {
  uint8_t s = (uint8_t)((digitalRead(PIN_ENC_A) << 1) | digitalRead(PIN_ENC_B));
  encPrev = (uint8_t)(((encPrev << 2) | s) & 0x0F);
  encAccum += ENC_TABLE[encPrev];
}

// Retourne le nombre de crans (4 impulsions par cran sur cet encodeur).
static int encoderTakeDetents() {
  noInterrupts();
  int32_t raw = encAccum;
  int32_t det = raw / 4;
  encAccum   -= det * 4;
  interrupts();
  (void)raw;
  return (int)det;
}

// ===========================================================================
//  ACQUISITION DE LA CELLULE
// ===========================================================================
// Conversions UNIQUES enchainees, lecture non bloquante. SURTOUT PAS le mode
// continu — voici pourquoi, car l'erreur est invisible et couteuse :
//
//   conversionComplete() de la bibliotheque Adafruit lit le bit OS du registre
//   de configuration. Ce bit vaut 0 TANT QUE le convertisseur convertit, et 1
//   seulement quand il est au repos. En mode continu l'ADS1115 convertit sans
//   interruption : le bit reste donc a 0 indefiniment et conversionComplete()
//   ne repond JAMAIS vrai. Aucun echantillon n'entre dans la fenetre, la
//   moyenne vaut 0,00 mV, et la calibration echoue sur "hors plage" alors que
//   le cablage est irreprochable et que le multimetre lit 12 mV aux bornes de
//   la cellule. La bibliotheque elle-meme n'emploie le mode continu nulle part.
//
// En conversion unique, chaque echantillon correspond a une conversion reelle
// et distincte. C'est precisement ce que suppose le critere de stabilite, qui
// mesure un ecart pic-a-pic : des echantillons relus deux fois feraient
// paraitre stable un signal qui ne l'est pas.
//
// A 32 ech/s une conversion dure 31,25 ms ; la fenetre de 24 echantillons
// couvre donc environ 750 ms.
static const uint16_t CONV_MS = 26;        // garde temporelle, voir plus bas
static bool           convBusy  = false;
static unsigned long  convStart = 0;
static unsigned long  lastSample = 0;      // chien de garde d'acquisition

static void startConversion() {
  ads.startADCReading(ADS1X15_REG_CONFIG_MUX_DIFF_0_1, /*continuous=*/false);
  convStart = millis();
  convBusy  = true;
}

static bool pollCell() {
  if (!convBusy) { startConversion(); return false; }

  // Garde temporelle : dans les microsecondes qui suivent l'ecriture du
  // registre, le bit OS peut encore porter l'etat de repos precedent. On ne
  // l'interroge qu'une fois la duree de conversion pratiquement ecoulee, ce
  // qui interdit de relire un resultat perime.
  if (millis() - convStart < CONV_MS) return false;
  if (!ads.conversionComplete())      return false;

  int16_t raw = ads.getLastConversionResults();
  lastMv = ads.computeVolts(raw) * 1000.0f;
  ringBuf[ringIdx] = lastMv;
  ringIdx = (uint8_t)((ringIdx + 1) % AVG_SIZE);
  if (ringIdx == 0) ringFull = true;
  lastSample = millis();
  startConversion();                       // on relance aussitot
  return true;
}

// Plus aucun echantillon depuis 2,5 s : l'ADC s'est tu. Sans ce garde-fou, la
// panne se presente comme une cellule debranchee et l'on cherche au mauvais
// endroit — ce qui est exactement arrive.
static bool adcStale() { return (millis() - lastSample) > 2500UL; }

static uint8_t filled() { return ringFull ? AVG_SIZE : ringIdx; }

static float averageMv() {
  uint8_t n = filled();
  if (n == 0) return 0.0f;
  float s = 0.0f;
  for (uint8_t i = 0; i < n; i++) s += ringBuf[i];
  return s / n;
}

static float spreadMv() {
  uint8_t n = filled();
  if (n < 2) return 999.0f;
  float lo = ringBuf[0], hi = ringBuf[0];
  for (uint8_t i = 1; i < n; i++) {
    if (ringBuf[i] < lo) lo = ringBuf[i];
    if (ringBuf[i] > hi) hi = ringBuf[i];
  }
  return hi - lo;
}

static bool isStable() {
  if (!ringFull) return false;
  float tol = averageMv() * STABLE_REL;
  if (tol < STABLE_MV_FLOOR) tol = STABLE_MV_FLOOR;
  return spreadMv() <= tol;
}

static void flushRing() { ringIdx = 0; ringFull = false; }

// ===========================================================================
//  ACQUISITION DE L'AMBIANCE
// ===========================================================================
static void pollEnv() {
  if (millis() - lastEnv < 1000) return;
  lastEnv = millis();

  if (baroOk && bmp.performReading()) {
    float p = bmp.pressure;          // hPa
    float t = bmp.temperature;       // degres C
    // Garde-fou : le BMP581 couvre 30 a 1250 hPa. Hors de cette plage, c'est
    // une lecture ratee, pas une pression.
    if (p > 300.0f && p < 1200.0f) pressHpa = p;
    if (t > -45.0f && t <  90.0f)  tempC    = t;
  } else if (rtcOk) {
    // Repli : le DS3231 porte un capteur de temperature interne (0,25 degre de
    // resolution). Moins bon que le BMP581, mais mieux que rien.
    tempC = rtc.getTemperature();
  }
}

static uint32_t nowUnix() {
  if (rtcOk) return rtc.now().unixtime();
  return 0;
}

// QNH reduit au niveau de la mer pour l'altitude reglee (formule barometrique
// de l'atmosphere standard OACI). Affichage seulement : n'entre pas dans le
// calcul du %O2.
static float qnhFromAlt() {
  float f = 1.0f - ((float)altSetM / 44330.77f);
  if (f < 0.1f) f = 0.1f;
  return pressHpa / powf(f, 5.255f);
}

// ===========================================================================
//  CALCULS
// ===========================================================================
// Rapport de compensation applique au %O2. Vaut 1 si l'on ne dispose pas de
// pression, ou si le rapport sort de la plage de plausibilite.
static float pressureRatio(float pMeas) {
  if (!baroOk || calHpa <= 0.0f || pMeas <= 0.0f) return 1.0f;
  float r = calHpa / pMeas;
  if (r < PRATIO_MIN || r > PRATIO_MAX) return 1.0f;
  return r;
}

static bool pressureSuspect(float pMeas) {
  if (!baroOk || calHpa <= 0.0f || pMeas <= 0.0f) return false;
  float r = calHpa / pMeas;
  return (r < PRATIO_MIN || r > PRATIO_MAX);
}

// %O2 compense en pression.
//     V = k . FO2 . Pabs   =>   FO2 = 0,209 . (V/V_cal) . (P_cal/P)
static float o2Percent(float mv, float pMeas) {
  if (!calValid || calMv <= 0.0f) return 0.0f;
  float pct = AIR_O2_PCT * (mv / calMv) * pressureRatio(pMeas);
  if (pct < 0.0f)   pct = 0.0f;
  if (pct > 100.0f) pct = 100.0f;
  return pct;
}

// MOD en metres d'eau de mer pour la consigne ppO2 donnee.
static float modMeters(float pct, float ppo2) {
  if (pct < 1.0f) return MOD_MAX_DISP;
  float d = 10.0f * ((ppo2 / (pct / 100.0f)) - 1.0f);
  if (d < 0.0f) d = 0.0f;
  if (d > MOD_MAX_DISP) d = MOD_MAX_DISP;
  return d;
}

// MOD en texte. Au plafond d'affichage on ecrit ">99" et non "100" : un
// melange trop pauvre pour avoir une MOD utile ne doit pas presenter un chiffre
// qui ressemble a une profondeur reelle.
static void modStr(char *out, size_t n, float pct, float ppo2) {
  float m = modMeters(pct, ppo2);
  if (m >= MOD_MAX_DISP) snprintf(out, n, ">99");
  else                   snprintf(out, n, "%.0f", (double)m);
}

// Nom normalise du melange.
static void gasName(float pct, char *out, size_t n) {
  if (pct >= 99.0f)                      snprintf(out, n, "O2 PUR");
  else if (pct >= 20.4f && pct <= 21.4f) snprintf(out, n, "AIR");
  else                                   snprintf(out, n, "EAN%.0f", (double)pct);
}

// Verdict de sante de la cellule, base sur la tension de reference a l'air.
static const char *cellVerdict(float ref) {
  if (ref <= 0.0f)             return "non calibree";
  if (ref >= 10.0f)            return "neuve";
  if (ref >= 8.0f)             return "bonne";
  if (ref >= CELL_MV_WARN)     return "a surveiller";
  return "a remplacer";
}

// ===========================================================================
//  PERSISTANCE  —  calibration et reglages en NVS
// ===========================================================================
static void prefsSave() {
  prefs.begin("nitrox", false);
  prefs.putFloat("calmv",  calMv);
  prefs.putFloat("calhpa", calHpa);
  prefs.putUInt ("calts",  calUnix);
  prefs.putInt  ("altm",   altSetM);
  prefs.putUChar("ppo2",   ppo2Idx);
  prefs.end();
}

static void prefsLoad() {
  prefs.begin("nitrox", true);
  calMv   = prefs.getFloat("calmv",  0.0f);
  calHpa  = prefs.getFloat("calhpa", 0.0f);
  calUnix = prefs.getUInt ("calts",  0);
  altSetM = prefs.getInt  ("altm",   0);
  ppo2Idx = prefs.getUChar("ppo2",   1);
  prefs.end();
  if (ppo2Idx >= PPO2_COUNT) ppo2Idx = 1;
  if (altSetM < -200) altSetM = -200;
  if (altSetM > 4000) altSetM = 4000;
}

// ===========================================================================
//  JOURNAL  —  fichier CSV sur LittleFS
// ===========================================================================
static void logPushRam(const LogEntry &e) {
  // Insertion en tete : logBuf[0] est toujours l'entree la plus recente.
  uint8_t n = (logCount < LOG_RAM) ? logCount : (uint8_t)(LOG_RAM - 1);
  for (uint8_t i = n; i > 0; i--) logBuf[i] = logBuf[i - 1];
  logBuf[0] = e;
  if (logCount < LOG_RAM) logCount++;
}

static void logLoad() {
  logCount = 0; logTotal = 0; logView = 0;
  if (!fsOk) return;
  File f = LittleFS.open(LOG_PATH, "r");
  if (!f) return;

  char line[160];
  size_t k = 0;
  while (f.available()) {
    int c = f.read();
    if (c < 0) break;
    if (c == '\n' || k >= sizeof(line) - 1) {
      line[k] = '\0';
      k = 0;
      if (line[0] >= '0' && line[0] <= '9') {      // ignore l'en-tete
        LogEntry e;
        unsigned long st = 0;
        double pct = 0, mv = 0, ref = 0, hpa = 0, tp = 0, pp = 0, md = 0;
        int got = sscanf(line, "%lu;%lf;%lf;%lf;%lf;%lf;%lf;%lf",
                         &st, &pct, &mv, &ref, &hpa, &tp, &pp, &md);
        if (got == 8) {
          e.stamp = (uint32_t)st;
          e.pct = (float)pct; e.mv = (float)mv; e.refMv = (float)ref;
          e.hpa = (float)hpa; e.temp = (float)tp;
          e.ppo2 = (float)pp; e.mod = (float)md;
          logPushRam(e);
          if (logTotal < 65535) logTotal++;
        }
      }
      continue;
    }
    if (c != '\r') line[k++] = (char)c;
  }
  f.close();
}

static bool logAppend(const LogEntry &e) {
  logPushRam(e);
  if (logTotal < 65535) logTotal++;
  logView = 0;
  if (!fsOk) return false;

  bool fresh = !LittleFS.exists(LOG_PATH);
  File f = LittleFS.open(LOG_PATH, "a");
  if (!f) return false;
  if (fresh) f.print("epoch;pct_o2;mv;ref_mv;hpa;temp_c;ppo2;mod_m\n");
  // Point-virgule : Excel et LibreOffice l'ouvrent directement en francais.
  f.printf("%lu;%.2f;%.4f;%.4f;%.2f;%.2f;%.2f;%.1f\n",
           (unsigned long)e.stamp, (double)e.pct, (double)e.mv,
           (double)e.refMv, (double)e.hpa, (double)e.temp,
           (double)e.ppo2, (double)e.mod);
  f.close();
  return true;
}

static void logWipe() {
  if (fsOk) LittleFS.remove(LOG_PATH);
  logCount = 0; logTotal = 0; logView = 0;
}

// ===========================================================================
//  LIAISON SERIE  —  recuperation du journal et reglage de l'horloge
// ===========================================================================
//  Sans cela, le journal serait ecrit mais inaccessible : le televerseur
//  LittleFS de l'IDE Arduino sait ecrire dans la partition, pas la lire.
//  On deverse donc le CSV tel quel sur la liaison serie ; il suffit de
//  selectionner le texte dans le moniteur et de le coller dans un tableur.
static char    cmdBuf[24];
static uint8_t cmdLen = 0;

static void cmdDump() {
  Serial.println(F("---8<--- journal.csv ---8<---"));
  if (!fsOk) {
    Serial.println(F("(pas de systeme de fichiers : verifier le profil de partition)"));
  } else {
    File f = LittleFS.open(LOG_PATH, "r");
    if (!f) {
      Serial.println(F("(journal vide)"));
    } else {
      while (f.available()) {
        int c = f.read();
        if (c < 0) break;
        Serial.write((uint8_t)c);
      }
      f.close();
    }
  }
  Serial.println(F("---8<--- fin ---8<---"));
}

static void cmdStatus() {
  float mv = averageMv();
  Serial.println(F("--- etat ---"));
  Serial.printf("  ADS1115 %s   BMP581 %s   DS3231 %s   LittleFS %s\n",
                adcOk ? "ok" : "ABSENT", baroOk ? "ok" : "ABSENT",
                rtcOk ? "ok" : "ABSENT", fsOk ? "ok" : "ABSENT");
  Serial.printf("  cellule   %.4f mV   ecart p-p %.1f uV   %s\n",
                (double)mv, (double)(spreadMv() * 1000.0f),
                isStable() ? "stable" : "en cours");
  if (calValid)
    Serial.printf("  calibre   %.4f mV a %.2f hPa   epoch %lu\n",
                  (double)calMv, (double)calHpa, (unsigned long)calUnix);
  else
    Serial.println(F("  calibre   NON"));
  Serial.printf("  ambiance  %.2f hPa   %.2f C   correction x%.4f\n",
                (double)pressHpa, (double)tempC,
                (double)pressureRatio(pressHpa));
  Serial.printf("  %%O2       %.2f %%\n", (double)o2Percent(mv, pressHpa));
  Serial.printf("  journal   %u entree(s), %u en memoire\n",
                (unsigned)logTotal, (unsigned)logCount);
  Serial.printf("  horloge   epoch %lu%s\n", (unsigned long)nowUnix(),
                rtcLost ? "  (calee a la compilation, a regler)" : "");
}

static void cmdHelp() {
  Serial.println(F("  d          deverser le journal CSV"));
  Serial.println(F("  i          etat des peripheriques"));
  Serial.println(F("  T<epoch>   regler l'horloge, ex. T1790000000"));
  Serial.println(F("  ?          cette aide"));
}

static void handleCmd(const char *s) {
  switch (s[0]) {
    case 'd': case 'D': cmdDump();   break;
    case 'i': case 'I': cmdStatus(); break;
    case 't': case 'T': {
      unsigned long v = 0;
      // Garde-fou : un epoch anterieur a 2024 est une faute de frappe, pas
      // une date. Mieux vaut refuser que fausser tous les horodatages.
      if (sscanf(s + 1, "%lu", &v) == 1 && v > 1700000000UL) {
        if (rtcOk) {
          rtc.adjust(DateTime((uint32_t)v));
          rtcLost = false;
          Serial.printf("horloge reglee sur epoch %lu\n", v);
        } else {
          Serial.println(F("pas de DS3231 sur le bus"));
        }
      } else {
        Serial.println(F("usage : T<epoch Unix>, ex. T1790000000"));
      }
      break;
    }
    default: cmdHelp(); break;
  }
}

static void serviceSerial() {
  while (Serial.available() > 0) {
    int c = Serial.read();
    if (c < 0) break;
    if (c == '\r') continue;
    if (c == '\n') {
      cmdBuf[cmdLen] = '\0';
      if (cmdLen) handleCmd(cmdBuf);
      cmdLen = 0;
      continue;
    }
    if (cmdLen < sizeof(cmdBuf) - 1) cmdBuf[cmdLen++] = (char)c;
  }
}

// ===========================================================================
//  ANNEAU RGB
// ===========================================================================
static void setRing(uint8_t r, uint8_t g, uint8_t b) {
  for (int i = 0; i < RGB_COUNT; i++) ring.setPixelColor(i, ring.Color(r, g, b));
  ring.show();
}

static void serviceRing() {
  if (millis() - lastLedTick >= 320) {
    lastLedTick = millis();
    ledPhase = !ledPhase;
  }
  switch (state) {
    case ST_ADC_FAULT:
    case ST_CELL_FAULT: setRing(90, 0, 0);                        break;
    case ST_UNCAL:      setRing(ledPhase ? 90 : 10, 0, 0);        break;
    case ST_CALIB:      setRing(0, 30, 90);                       break;
    case ST_SETTLING:   setRing(ledPhase ? 90 : 12,
                                ledPhase ? 55 : 7, 0);            break;
    case ST_OK:         setRing(0, 80, 20);                       break;
  }
}

// ===========================================================================
//  PRIMITIVES GRAPHIQUES
// ===========================================================================
static uint16_t lerp565(uint16_t a, uint16_t b, float t) {
  if (t < 0.0f) t = 0.0f;
  if (t > 1.0f) t = 1.0f;
  int ra = (a >> 11) & 0x1F, ga = (a >> 5) & 0x3F, ba = a & 0x1F;
  int rb = (b >> 11) & 0x1F, gb = (b >> 5) & 0x3F, bb = b & 0x1F;
  int r = ra + (int)((float)(rb - ra) * t + 0.5f);
  int g = ga + (int)((float)(gb - ga) * t + 0.5f);
  int u = ba + (int)((float)(bb - ba) * t + 0.5f);
  return (uint16_t)((r << 11) | (g << 5) | u);
}

// Position d'un point sur un rayon donne. Convention LovyanGFX : 0 degre a
// 3 h, angles croissants dans le sens horaire.
static void polar(float deg, float r, int *x, int *y) {
  float a = deg * 0.01745329252f;
  *x = CX + (int)lrintf(cosf(a) * r);
  *y = CY + (int)lrintf(sinf(a) * r);
}

// Couronne de graduations : trait tous les 2,5 %, trait long tous les 10 %.
static void drawTickRing(uint16_t colMinor, uint16_t colMajor) {
  for (int i = 0; i <= 40; i++) {
    float deg = ARC_START + ARC_SPAN * (float)i / 40.0f;
    bool major = (i % 4 == 0);
    int x0, y0, x1, y1;
    polar(deg, major ? (float)TICK_R0 - 3.0f : (float)TICK_R0, &x0, &y0);
    polar(deg, (float)TICK_R1, &x1, &y1);
    spr.drawWideLine(x0, y0, x1, y1, major ? 1.4f : 0.7f,
                     major ? colMajor : colMinor);
  }
}

// Arc de mesure en degrade, avec capuchon arrondi a chaque extremite.
static void drawArcGauge(float frac, uint16_t c0, uint16_t c1) {
  if (frac < 0.0f) frac = 0.0f;
  if (frac > 1.0f) frac = 1.0f;

  spr.fillArc(CX, CY, ARC_R0, ARC_R1, ARC_START, ARC_START + ARC_SPAN,
              COL_TRACK);

  const float rMid = (float)(ARC_R0 + ARC_R1) * 0.5f;
  const int   cap  = (ARC_R1 - ARC_R0) / 2;

  // A zero, pas de capuchon de depart : un point isole au bas de l'ecran se
  // lit comme un temoin allume, ce qu'il n'est pas.
  if (frac <= 0.0005f) return;

  int xs, ys;
  polar(ARC_START, rMid, &xs, &ys);
  spr.fillSmoothCircle(xs, ys, cap, c0);

  // Une trentaine de segments : le degrade est continu a l'oeil et le cout de
  // trace reste tres inferieur au transfert du sprite vers la dalle.
  const int NSEG = 30;
  float span = ARC_SPAN * frac;
  for (int i = 0; i < NSEG; i++) {
    float a0 = ARC_START + span * (float)i / (float)NSEG;
    float a1 = ARC_START + span * (float)(i + 1) / (float)NSEG;
    // Le degrade est indexe sur la position ABSOLUE dans la couronne, pas sur
    // la fraction remplie : la teinte d'une valeur donnee ne change donc pas
    // quand l'aiguille bouge.
    float t = (a0 - ARC_START) / ARC_SPAN;
    spr.fillArc(CX, CY, ARC_R0, ARC_R1, a0, a1 + 0.6f, lerp565(c0, c1, t));
  }

  int xe, ye;
  polar(ARC_START + span, rMid, &xe, &ye);
  spr.fillSmoothCircle(xe, ye, cap, lerp565(c0, c1, frac));
  // Pointe claire : repere de lecture rapide, visible meme de loin.
  spr.fillSmoothCircle(xe, ye, cap - 5, COL_FG);
}

static void drawText(const char *s, int x, int y, uint16_t col,
                     const lgfx::IFont *f, textdatum_t d) {
  spr.setFont(f);
  spr.setTextColor(col, COL_BG);
  spr.setTextDatum(d);
  spr.drawString(s, x, y);
}

static void drawCentered(const char *s, int y, uint16_t col,
                         const lgfx::IFont *f) {
  drawText(s, CX, y, col, f, textdatum_t::middle_center);
}

// Pastille arrondie. fill == COL_BG -> pastille creuse a liseret.
static void drawPill(int cx, int cy, int h, uint16_t fill, uint16_t border,
                     const char *txt, uint16_t txtCol,
                     const lgfx::IFont *f, int minW) {
  spr.setFont(f);
  int tw = spr.textWidth(txt);
  int w = tw + h;                         // marge laterale = h/2 de chaque cote
  if (w < minW) w = minW;
  int r = h / 2;
  int x = cx - w / 2, y = cy - h / 2;
  if (fill != COL_BG) spr.fillSmoothRoundRect(x, y, w, h, r, fill);
  if (border != COL_BG) {
    spr.drawRoundRect(x, y, w, h, r, border);
    spr.drawRoundRect(x + 1, y + 1, w - 2, h - 2, r - 1, border);
  }
  spr.setTextColor(txtCol, (fill != COL_BG) ? fill : COL_BG);
  spr.setTextDatum(textdatum_t::middle_center);
  spr.drawString(txt, cx, cy);
}

static void drawPageDots(uint8_t cur) {
  const int step = 13, y = 224;
  int x0 = CX - (int)((PG_COUNT - 1) * step) / 2;
  for (uint8_t i = 0; i < PG_COUNT; i++) {
    int x = x0 + i * step;
    if (i == cur) spr.fillSmoothCircle(x, y, 3, COL_FG);
    else          spr.fillSmoothCircle(x, y, 2, COL_MUTE);
  }
}

// Bandeau d'etat en haut. Largeur utile a y = 48 : environ 96 px, soit onze
// caracteres en DejaVu12. Les libelles sont calibres pour cela.
static void drawStatusChip(const char *txt, uint16_t col, bool filled_) {
  if (filled_) drawPill(CX, 48, 22, col, COL_BG, txt, COL_BG,
                        &fonts::DejaVu12, 60);
  else         drawPill(CX, 48, 22, COL_CARD, col, txt, col,
                        &fonts::DejaVu12, 60);
}

// Couleur d'accent du moment : elle double toujours un texte.
static uint16_t accentColor() {
  switch (state) {
    case ST_ADC_FAULT:
    case ST_CELL_FAULT: return COL_RED;
    case ST_UNCAL:      return COL_RED;
    case ST_CALIB:      return COL_BLUE;
    case ST_SETTLING:   return COL_AMBER;
    case ST_OK:         return frozen ? COL_TEAL : COL_GREEN;
  }
  return COL_DIM;
}

static void flash(const char *msg) {
  snprintf(flashMsg, sizeof(flashMsg), "%s", msg);
  flashUntil = millis() + 1600;
}

// ===========================================================================
//  PAGE 1  —  MESURE
// ===========================================================================
static void pageMesure() {
  float mv   = frozen ? frozenMv  : averageMv();
  float hpa  = frozen ? frozenHpa : pressHpa;
  float pct  = frozen ? frozenPct : o2Percent(mv, hpa);
  uint16_t ac = accentColor();

  if (state == ST_OK || state == ST_SETTLING)
    drawArcGauge(pct / 100.0f, ARC_C0, ARC_C1);
  else
    drawArcGauge(0.0f, ac, ac);

  drawTickRing(COL_TRACK, COL_MUTE);

  const char *tag = frozen ? "FIGE"
                  : (state == ST_OK ? "VERROUILLE" : "ACQUISITION");
  drawStatusChip(tag, frozen ? COL_TEAL : ac, state == ST_OK || frozen);

  // Grandeur mesuree : blanc pur, le plus gros corps disponible.
  char buf[40];
  snprintf(buf, sizeof(buf), "%.1f", (double)pct);
  drawText(buf, 108, 110, (state == ST_OK || frozen) ? COL_FG : COL_DIM,
           &fonts::DejaVu56, textdatum_t::middle_center);
  drawText("%", 178, 92, COL_DIM, &fonts::DejaVu18,
           textdatum_t::middle_center);

  char gas[12];
  gasName(pct, gas, sizeof(gas));
  drawCentered(gas, 150, ac, &fonts::DejaVu18);

  // Tension brute et pression de la mesure : les deux grandeurs physiques dont
  // depend le chiffre affiche restent visibles en permanence.
  if (baroOk) snprintf(buf, sizeof(buf), "%.2f mV  %.0f hPa",
                       (double)mv, (double)hpa);
  else        snprintf(buf, sizeof(buf), "%.2f mV", (double)mv);
  drawCentered(buf, 171, cellWeak ? COL_AMBER : COL_DIM, &fonts::DejaVu12);

  float ppo2 = PPO2_TABLE[ppo2Idx];
  char md[8];
  modStr(md, sizeof(md), pct, ppo2);
  snprintf(buf, sizeof(buf), "MOD %s m  %.1f", md, (double)ppo2);
  drawPill(CX, 196, 24, COL_CARD, COL_MUTE, buf, COL_TEXT,
           &fonts::DejaVu12, 120);
}

// ===========================================================================
//  PAGE 2  —  PLONGEE : la table MOD complete
// ===========================================================================
static void pagePlongee() {
  float mv  = frozen ? frozenMv  : averageMv();
  float hpa = frozen ? frozenHpa : pressHpa;
  float pct = frozen ? frozenPct : o2Percent(mv, hpa);

  drawArcGauge(pct / 100.0f, ARC_C0, ARC_C1);
  drawTickRing(COL_TRACK, COL_MUTE);

  char gas[12];
  gasName(pct, gas, sizeof(gas));
  char chip[24];
  // Le bandeau ne porte que le nom du melange : une pastille plus longue a
  // y = 48 mord sur la couronne de graduations. Le pourcentage exact se lit
  // deux lignes plus bas.
  drawStatusChip(gas, focus ? COL_TEAL : COL_DIM, false);

  // Hierarchie : la profondeur maxi de la consigne retenue occupe le centre,
  // les trois consignes se lisent d'un coup d'oeil en bas. Trois lignes de
  // texte de meme poids obligeraient a chercher laquelle est active.
  char md[8];
  modStr(md, sizeof(md), pct, PPO2_TABLE[ppo2Idx]);
  int wide = (strlen(md) > 2) ? 12 : 0;
  drawText(md, 108 - wide, 100, COL_FG, &fonts::DejaVu56,
           textdatum_t::middle_center);
  drawText("m", 160 + wide, 114, COL_DIM, &fonts::DejaVu18,
           textdatum_t::middle_center);
  drawCentered("profondeur maxi", 138, COL_DIM, &fonts::DejaVu12);

  snprintf(chip, sizeof(chip), "%.1f %% O2", (double)pct);
  drawCentered(chip, 157, COL_TEXT, &fonts::DejaVu12);

  // Pastilles de consigne. Ecart de 42 px : les pastilles laterales restent
  // dans l'ouverture basse de la couronne, sans mordre sur l'arc.
  for (uint8_t i = 0; i < PPO2_COUNT; i++) {
    int x = CX + ((int)i - 1) * 42;
    bool sel = (i == ppo2Idx);
    snprintf(chip, sizeof(chip), "%.1f", (double)PPO2_TABLE[i]);
    if (sel) drawPill(x, 182, 24, focus ? COL_TEAL : COL_CARD,
                      focus ? COL_BG : COL_TEAL, chip,
                      focus ? COL_BG : COL_FG, &fonts::DejaVu12, 44);
    else     drawPill(x, 182, 24, COL_BG, COL_BG, chip, COL_MUTE,
                      &fonts::DejaVu12, 44);
  }

  drawCentered(focus ? "molette : consigne ppO2" : "appui : choisir la ppO2",
               206, COL_MUTE, &fonts::DejaVu9);
}

// ===========================================================================
//  PAGE 3  —  AMBIANCE : pression, temperature, heure
// ===========================================================================
static void pageAmbiance() {
  // La couronne porte la temperature sur 0 a 40 degres : c'est la grandeur de
  // cette page qui a une plage bornee et un domaine de validite. Elle vire a
  // l'ambre hors de 5 a 35 degres, ou la cellule sort de ses conditions.
  bool tOut = (tempC < TEMP_MIN_OK || tempC > TEMP_MAX_OK);
  float tf = tempC / 40.0f;
  if (tf < 0.0f) tf = 0.0f;
  if (tf > 1.0f) tf = 1.0f;
  uint16_t tc = tOut ? COL_AMBER : COL_TEAL;
  drawArcGauge(tf, tc, tc);
  drawTickRing(COL_TRACK, COL_MUTE);
  drawStatusChip("AMBIANCE", focus ? COL_TEAL : COL_DIM, false);

  char buf[40];
  if (baroOk) {
    snprintf(buf, sizeof(buf), "%.1f", (double)pressHpa);
    drawText(buf, 100, 96, COL_FG, &fonts::DejaVu40,
             textdatum_t::middle_center);
    drawText("hPa", 172, 104, COL_DIM, &fonts::DejaVu12,
             textdatum_t::middle_center);
  } else {
    drawCentered("BMP581 absent", 96, COL_RED, &fonts::DejaVu18);
  }

  snprintf(buf, sizeof(buf), "%.1f C", (double)tempC);
  drawCentered(buf, 128, tc, &fonts::DejaVu18);

  // Altitude reglee : reglage d'affichage uniquement. Le %O2 est compense par
  // la pression ABSOLUE, qui ne demande aucun etalonnage.
  if (focus) snprintf(buf, sizeof(buf), "< alt %d m >", altSetM);
  else       snprintf(buf, sizeof(buf), "alt %d m   QNH %.0f",
                      altSetM, (double)qnhFromAlt());
  drawPill(CX, 152, 20, focus ? COL_TEAL : COL_BG,
           focus ? COL_BG : COL_BG, buf, focus ? COL_BG : COL_DIM,
           &fonts::DejaVu12, 100);

  uint32_t u = nowUnix();
  if (rtcOk && u != 0) {
    DateTime t(u);
    snprintf(buf, sizeof(buf), "%02d/%02d/%04d  %02d:%02d",
             t.day(), t.month(), t.year(), t.hour(), t.minute());
    drawCentered(buf, 174, rtcLost ? COL_AMBER : COL_DIM, &fonts::DejaVu12);
  } else {
    drawCentered("horloge absente", 174, COL_RED, &fonts::DejaVu12);
  }

  // Ligne de texte et non pastille : a y = 198, une pastille de vingt
  // caracteres empiete sur la couronne. Le texte, moins haut et moins large,
  // reste dans l'ouverture basse.
  float r = pressureRatio(pressHpa);
  if (pressureSuspect(pressHpa))
    drawCentered("pression suspecte", 197, COL_AMBER, &fonts::DejaVu12);
  else if (calValid && baroOk) {
    snprintf(buf, sizeof(buf), "compens. x%.4f", (double)r);
    drawCentered(buf, 197, COL_TEXT, &fonts::DejaVu12);
  } else
    drawCentered("compens. inactive", 197, COL_MUTE, &fonts::DejaVu12);
}

// ===========================================================================
//  PAGE 4  —  JOURNAL
// ===========================================================================
static void pageJournal() {
  // Meme couronne, meme degrade que la page MESURE : une entree du journal se
  // compare a l'oeil avec la mesure en cours, sans lire les chiffres.
  if (logCount > 0) {
    uint8_t v = (logView < logCount) ? logView : (uint8_t)(logCount - 1);
    drawArcGauge(logBuf[v].pct / 100.0f, ARC_C0, ARC_C1);
  } else {
    drawArcGauge(0.0f, COL_TRACK, COL_TRACK);
  }
  drawTickRing(COL_TRACK, COL_MUTE);

  char buf[48];
  if (logCount == 0) {
    drawStatusChip("JOURNAL", COL_DIM, false);
    drawCentered("aucune mesure", 112, COL_DIM, &fonts::DejaVu18);
    drawCentered("figer puis appui long", 140, COL_MUTE, &fonts::DejaVu12);
    drawCentered("pour enregistrer", 158, COL_MUTE, &fonts::DejaVu12);
    return;
  }

  if (logView >= logCount) logView = (uint8_t)(logCount - 1);
  const LogEntry &e = logBuf[logView];

  snprintf(buf, sizeof(buf), "%u / %u", (unsigned)(logView + 1),
           (unsigned)logCount);
  drawStatusChip(buf, focus ? COL_TEAL : COL_DIM, focus);

  // Barre de position dans le journal : on sait ou l'on est dans la pile.
  if (logCount > 1) {
    int w = 110, x = CX - w / 2;
    spr.fillSmoothRoundRect(x, 66, w, 3, 1, COL_TRACK);
    int seg = w / (int)logCount; if (seg < 4) seg = 4;
    int px = x + (int)((long)logView * (w - seg) / (long)(logCount - 1));
    spr.fillSmoothRoundRect(px, 66, seg, 3, 1, focus ? COL_TEAL : COL_DIM);
  }

  snprintf(buf, sizeof(buf), "%.1f", (double)e.pct);
  drawText(buf, 104, 104, COL_FG, &fonts::DejaVu40,
           textdatum_t::middle_center);
  drawText("%", 164, 94, COL_DIM, &fonts::DejaVu12,
           textdatum_t::middle_center);

  // Deux lignes courtes plutot qu'une longue : a 25 caracteres, la chaine
  // depasse la corde utile du cercle et se fait rogner par la lunette.
  if (e.stamp != 0) {
    DateTime t(e.stamp);
    snprintf(buf, sizeof(buf), "%02d/%02d  %02d:%02d   %.0f C",
             t.day(), t.month(), t.hour(), t.minute(), (double)e.temp);
  } else {
    snprintf(buf, sizeof(buf), "heure inconnue   %.0f C", (double)e.temp);
  }
  drawCentered(buf, 137, COL_TEXT, &fonts::DejaVu12);

  snprintf(buf, sizeof(buf), "%.2f mV   %.0f hPa",
           (double)e.mv, (double)e.hpa);
  drawCentered(buf, 156, COL_DIM, &fonts::DejaVu12);

  char md[8];
  if (e.mod >= MOD_MAX_DISP) snprintf(md, sizeof(md), ">99");
  else                       snprintf(md, sizeof(md), "%.0f", (double)e.mod);
  snprintf(buf, sizeof(buf), "MOD %s m  %.1f", md, (double)e.ppo2);
  drawPill(CX, 182, 22, COL_CARD, COL_MUTE, buf, COL_TEXT,
           &fonts::DejaVu12, 118);

  drawCentered(focus ? "molette : defiler" : "appui long : effacer",
               204, COL_MUTE, &fonts::DejaVu9);
}

// ===========================================================================
//  PAGE 5  —  CELLULE : sante et calibration
// ===========================================================================
static void pageCellule() {
  float mv = averageMv();

  // Position de la reference dans la plage utile d'une cellule, 4 a 14 mV.
  float f = (calMv - 4.0f) / 10.0f;
  if (f < 0.0f) f = 0.0f;
  if (f > 1.0f) f = 1.0f;
  uint16_t hc = (calMv >= 8.0f) ? COL_GREEN
              : (calMv >= CELL_MV_WARN ? COL_AMBER : COL_RED);
  drawArcGauge(calValid ? f : 0.0f, hc, hc);
  drawTickRing(COL_TRACK, COL_MUTE);

  drawStatusChip("CELLULE", COL_DIM, false);

  char buf[48];
  snprintf(buf, sizeof(buf), "%.2f", (double)mv);
  drawText(buf, 102, 100, COL_FG, &fonts::DejaVu40,
           textdatum_t::middle_center);
  drawText("mV", 168, 108, COL_DIM, &fonts::DejaVu12,
           textdatum_t::middle_center);

  drawCentered(cellVerdict(calValid ? calMv : 0.0f), 134, hc,
               &fonts::DejaVu18);

  if (calValid) {
    snprintf(buf, sizeof(buf), "ref %.2f mV  %.0f hPa",
             (double)calMv, (double)calHpa);
    drawCentered(buf, 158, COL_DIM, &fonts::DejaVu12);

    // Libelle court : "cal. 23 h 59" tient dans l'ouverture basse, alors que
    // "calibree il y a 23 h 59" mordrait sur la couronne de graduations.
    uint32_t u = nowUnix();
    if (calUnix != 0 && u > calUnix) {
      uint32_t d = u - calUnix;
      if (d < 3600UL) snprintf(buf, sizeof(buf), "cal. %lu min",
                               (unsigned long)(d / 60UL));
      else            snprintf(buf, sizeof(buf), "cal. %lu h %02lu",
                               (unsigned long)(d / 3600UL),
                               (unsigned long)((d % 3600UL) / 60UL));
    } else {
      snprintf(buf, sizeof(buf), "calibree");
    }
    drawPill(CX, 184, 22, COL_CARD, COL_MUTE, buf, COL_TEXT,
             &fonts::DejaVu12, 120);
  } else {
    drawPill(CX, 170, 22, COL_BG, COL_RED, "non calibree", COL_RED,
             &fonts::DejaVu12, 110);
    drawCentered("page MESURE, appui 1,5 s", 196, COL_MUTE, &fonts::DejaVu9);
  }
}

// ===========================================================================
//  RENDU  —  plein ecran, message, appui long
// ===========================================================================
static void renderPage() {
  spr.fillSprite(COL_BG);

  if (state == ST_ADC_FAULT && page == PG_MESURE) {
    drawArcGauge(0.0f, COL_RED, COL_RED);
    drawTickRing(COL_TRACK, COL_MUTE);
    drawStatusChip("ADC MUET", COL_RED, true);
    drawCentered("aucun echantillon", 110, COL_FG, &fonts::DejaVu18);
    drawCentered("cordon I2C, ou 0x48", 140, COL_DIM, &fonts::DejaVu12);
    drawCentered("absent du bus", 158, COL_DIM, &fonts::DejaVu12);
  } else if (!calValid && page == PG_MESURE) {
    drawArcGauge(0.0f, COL_RED, COL_RED);
    drawTickRing(COL_TRACK, COL_MUTE);
    drawStatusChip("NON CALIBRE", COL_RED, true);
    drawCentered("appui long 1,5 s", 112, COL_FG, &fonts::DejaVu18);
    drawCentered("cellule a l'air libre", 142, COL_DIM, &fonts::DejaVu12);
    char buf[32];
    snprintf(buf, sizeof(buf), "%.2f mV", (double)averageMv());
    drawCentered(buf, 168, COL_DIM, &fonts::DejaVu12);
  } else {
    switch (page) {
      case PG_MESURE:   pageMesure();   break;
      case PG_PLONGEE:  pagePlongee();  break;
      case PG_AMBIANCE: pageAmbiance(); break;
      case PG_JOURNAL:  pageJournal();  break;
      default:          pageCellule();  break;
    }
  }

  // Bandeau ephemere de confirmation d'action.
  if (millis() < flashUntil && flashMsg[0] != '\0')
    drawPill(CX, 212, 22, COL_TEAL, COL_BG, flashMsg, COL_BG,
             &fonts::DejaVu12, 110);
  else
    drawPageDots(page);

  spr.pushSprite(0, 0);
}

static void renderMessage(const char *l1, const char *l2, const char *l3,
                          uint16_t col) {
  spr.fillSprite(COL_BG);
  spr.fillArc(CX, CY, ARC_R0, ARC_R1, ARC_START, ARC_START + ARC_SPAN, col);
  drawTickRing(COL_TRACK, COL_MUTE);
  drawCentered(l1, CY - 36, col,      &fonts::DejaVu18);
  drawCentered(l2, CY + 2,  COL_FG,   &fonts::DejaVu12);
  drawCentered(l3, CY + 26, COL_DIM,  &fonts::DejaVu12);
  spr.pushSprite(0, 0);
}

// Arc de progression pendant un appui long : l'utilisateur voit l'action
// arriver et peut relacher avant qu'elle ne se declenche.
static void renderHold(float frac, const char *what) {
  if (frac < 0.0f) frac = 0.0f;
  if (frac > 1.0f) frac = 1.0f;
  spr.fillSprite(COL_BG);
  spr.fillArc(CX, CY, ARC_R0, ARC_R1, ARC_START, ARC_START + ARC_SPAN,
              COL_TRACK);
  if (frac > 0.002f)
    spr.fillArc(CX, CY, ARC_R0, ARC_R1, ARC_START,
                ARC_START + ARC_SPAN * frac, COL_TEAL);
  drawTickRing(COL_TRACK, COL_MUTE);
  drawCentered(what, CY - 14, COL_FG, &fonts::DejaVu18);
  drawCentered(frac >= 1.0f ? "relacher" : "maintenir", CY + 22,
               frac >= 1.0f ? COL_TEAL : COL_DIM, &fonts::DejaVu12);
  spr.pushSprite(0, 0);
}

// Attente active qui garde l'anneau vivant.
static void waitMs(unsigned long ms) {
  unsigned long t0 = millis();
  while (millis() - t0 < ms) { serviceRing(); delay(5); }
}

// ===========================================================================
//  CALIBRATION A L'AIR
// ===========================================================================
static void calibrateToAir() {
  state = ST_CALIB;
  calValid = false;
  cellWeak = false;
  frozen   = false;
  focus    = false;

  renderMessage("CALIBRATION", "air 20,9 %", "cellule a l'air libre",
                COL_BLUE);
  flushRing();

  unsigned long t0 = millis();
  while (millis() - t0 < CAL_WINDOW_MS) {
    pollCell();
    pollEnv();
    serviceRing();
    delay(5);
  }

  float mv = averageMv();
  char l2[32];

  if (filled() == 0) {
    state = ST_ADC_FAULT;
    renderMessage("ADC MUET", "aucun echantillon recu",
                  "ce n'est pas la cellule", COL_RED);
    waitMs(4000);
    return;
  }

  if (mv < CAL_MV_MIN || mv > CAL_MV_MAX) {
    state = ST_CELL_FAULT;
    snprintf(l2, sizeof(l2), "%.2f mV hors plage", (double)mv);
    renderMessage("ERREUR CELLULE", l2, "verifier le cablage", COL_RED);
    waitMs(3500);
    return;
  }

  if (!isStable()) {
    state = ST_CELL_FAULT;
    renderMessage("INSTABLE", "lecture non stabilisee", "recommencer",
                  COL_RED);
    waitMs(3500);
    return;
  }

  calMv    = mv;
  calHpa   = baroOk ? pressHpa : 0.0f;
  calUnix  = nowUnix();
  calValid = true;
  cellWeak = (calMv < CELL_MV_WARN);
  prefsSave();

  if (baroOk) snprintf(l2, sizeof(l2), "%.2f mV a %.0f hPa",
                       (double)calMv, (double)calHpa);
  else        snprintf(l2, sizeof(l2), "reference %.2f mV", (double)calMv);
  renderMessage("CALIBRE", l2, "20,9 % O2", COL_GREEN);
  waitMs(1800);

  if (cellWeak) {
    renderMessage("CELLULE FAIBLE", "sous 6,00 mV a l'air",
                  "prevoir un remplacement", COL_AMBER);
    waitMs(3500);
  }

  state = ST_SETTLING;
  page  = PG_MESURE;
}

// ===========================================================================
//  ACTIONS
// ===========================================================================
static void doFreeze() {
  frozen = true;
  focus  = true;
  frozenMv   = averageMv();
  frozenHpa  = pressHpa;
  frozenTemp = tempC;
  frozenPct  = o2Percent(frozenMv, frozenHpa);
  frozenUnix = nowUnix();
}

static void doLogCurrent() {
  LogEntry e;
  e.stamp = frozenUnix != 0 ? frozenUnix : nowUnix();
  e.pct   = frozenPct;
  e.mv    = frozenMv;
  e.refMv = calMv;
  e.hpa   = frozenHpa;
  e.temp  = frozenTemp;
  e.ppo2  = PPO2_TABLE[ppo2Idx];
  e.mod   = modMeters(frozenPct, e.ppo2);
  bool ok = logAppend(e);
  flash(ok ? "enregistre" : "memoire seule");
}

static void doWipeLog() {
  logWipe();
  flash("journal efface");
}

// Duree d'appui long utile sur la page courante, 0 = pas d'action longue.
static uint16_t holdDurationFor(uint8_t pg) {
  if (pg == PG_MESURE)  return HOLD_CAL_MS;
  if (pg == PG_JOURNAL) return logCount ? HOLD_WIPE_MS : 0;
  return 0;
}

static const char *holdLabelFor(uint8_t pg) {
  if (pg == PG_MESURE)  return frozen ? "ENREGISTRER" : "CALIBRER";
  if (pg == PG_JOURNAL) return "EFFACER";
  return "";
}

// ===========================================================================
//  BOUTON DE L'ENCODEUR
// ===========================================================================
static void handleButton() {
  if (digitalRead(PIN_ENC_SW) == HIGH) return;    // relache (actif bas)

  unsigned long t0 = millis();
  uint16_t hold = holdDurationFor(page);
  const char *label = holdLabelFor(page);
  bool shown = false;

  while (digitalRead(PIN_ENC_SW) == LOW) {
    unsigned long held = millis() - t0;
    // Sous 300 ms on ne montre rien : un appui court ne doit pas faire
    // clignoter l'ecran.
    if (hold != 0 && held >= 300) {
      renderHold((float)held / (float)hold, label);
      shown = true;
    }
    pollCell();
    serviceRing();
    delay(10);
  }

  unsigned long held = millis() - t0;
  (void)shown;

  if (hold != 0 && held >= hold) {
    if (page == PG_MESURE) {
      if (frozen) doLogCurrent();
      else        calibrateToAir();
    } else if (page == PG_JOURNAL) {
      doWipeLog();
    }
  } else if (held > DEBOUNCE_MS) {
    switch (page) {
      case PG_MESURE:
        if (!calValid) break;
        if (frozen) { frozen = false; focus = false; }
        else        doFreeze();
        break;
      case PG_PLONGEE:
      case PG_AMBIANCE:
        focus = !focus;
        if (!focus) prefsSave();
        break;
      case PG_JOURNAL:
        focus = (logCount > 0) ? !focus : false;
        break;
      default:                      // PG_CELLULE : page de lecture seule
        break;
    }
  }
  waitMs(120);
  encoderTakeDetents();             // ignore le jeu du bouton sur la molette
}

// ===========================================================================
//  ROTATION
// ===========================================================================
static void handleRotation(int det) {
  if (det == 0) return;

  if (!focus) {
    int p = (int)page + det;
    while (p < 0) p += PG_COUNT;                 // carrousel : on boucle
    page = (uint8_t)(p % PG_COUNT);
    return;
  }

  switch (page) {
    case PG_PLONGEE: {
      int i = (int)ppo2Idx + det;
      if (i < 0) i = 0;
      if (i > (int)PPO2_COUNT - 1) i = (int)PPO2_COUNT - 1;
      ppo2Idx = (uint8_t)i;
      break;
    }
    case PG_AMBIANCE: {
      int a = altSetM + det * 10;                // 10 m par cran
      if (a < -200) a = -200;
      if (a > 4000) a = 4000;
      altSetM = a;
      break;
    }
    case PG_JOURNAL: {
      int v = (int)logView + det;
      if (v < 0) v = 0;
      if (logCount && v > (int)logCount - 1) v = (int)logCount - 1;
      logView = (uint8_t)v;
      break;
    }
    default:
      break;                                     // MESURE fige : molette inerte
  }
}

// ===========================================================================
//  MACHINE D'ETAT
// ===========================================================================
static void updateState() {
  if (!adcOk || adcStale()) { state = ST_ADC_FAULT; return; }
  if (!calValid) { state = ST_UNCAL;     return; }
  if (frozen)    { state = ST_OK;        return; }
  state = isStable() ? ST_OK : ST_SETTLING;
}

// ===========================================================================
//  DEMARRAGE DES PERIPHERIQUES I2C
// ===========================================================================
static void startBaro() {
  baroOk = bmp.begin(ADDR_BMP581_A, &Wire1);
  if (!baroOk) baroOk = bmp.begin(ADDR_BMP581_B, &Wire1);
  if (!baroOk) return;
  // Suréchantillonnage fort sur la pression : c'est elle qui corrige le %O2.
  // Le filtre IIR lisse le bruit de quelques dixiemes de hPa.
  bmp.setPressureOversampling(BMP5XX_OVERSAMPLING_16X);
  bmp.setTemperatureOversampling(BMP5XX_OVERSAMPLING_2X);
  bmp.setIIRFilterCoeff(BMP5XX_IIR_FILTER_COEFF_15);
  bmp.setPowerMode(BMP5XX_POWERMODE_NORMAL);
  delay(60);
  bmp.performReading();
}

static void startRtc() {
  rtcOk = rtc.begin(&Wire1);
  if (!rtcOk) return;
  if (rtc.lostPower()) {
    // Pile CR1220 neuve, ou premiere mise en service : on cale l'horloge sur
    // la date de compilation. Elle sera donc juste a quelques minutes pres ;
    // la remettre a l'heure exacte demandera une recompilation, ou la page
    // reglage de la phase 3.
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
    rtcLost = true;
  }
}

// ===========================================================================
//  SETUP
// ===========================================================================
void setup() {
  Serial.begin(115200);

  // --- Radio coupee pendant l'acquisition (regle de conception) -----------
  // Une radio qui tire 240 mA en crete sur le meme rail, a deux centimetres
  // d'un front-end a 10 mV, est un probleme qu'il vaut mieux ne pas avoir a
  // diagnostiquer.
  WiFi.mode(WIFI_OFF);
  btStop();

  // --- Alimentation du panneau : SANS CECI, L'ECRAN RESTE NOIR ------------
  pinMode(PIN_PANEL_EN1, OUTPUT); digitalWrite(PIN_PANEL_EN1, HIGH);
  pinMode(PIN_PANEL_EN2, OUTPUT); digitalWrite(PIN_PANEL_EN2, HIGH);
  delay(120);

  pinMode(PIN_PWR_LED, OUTPUT); digitalWrite(PIN_PWR_LED, LOW);

  // --- Encodeur ------------------------------------------------------------
  pinMode(PIN_ENC_A,  INPUT_PULLUP);
  pinMode(PIN_ENC_B,  INPUT_PULLUP);
  pinMode(PIN_ENC_SW, INPUT_PULLUP);
  encPrev = (uint8_t)((digitalRead(PIN_ENC_A) << 1) | digitalRead(PIN_ENC_B));
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), encIsr, CHANGE);
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_B), encIsr, CHANGE);

  // --- Anneau RGB ----------------------------------------------------------
  ring.begin();
  ring.setBrightness(70);
  setRing(0, 0, 0);

  // --- Afficheur -----------------------------------------------------------
  tft.init();
  tft.setRotation(0);
  pinMode(PIN_LCD_BL, OUTPUT);
  digitalWrite(PIN_LCD_BL, HIGH);          // plein feu : usage exterieur
  tft.fillScreen(COL_BG);

  spr.setPsram(true);                      // 240x240x16 bits = 115 ko
  spr.setColorDepth(16);
  spr.createSprite(240, 240);

  renderMessage("NITROX", "v2.1  phase 2", "9H2WB / F5OWB", COL_TEAL);
  delay(1200);

  // --- Bus I2C EXTERNE (GPIO38/39) ----------------------------------------
  // Le bus du tactile CST816D (GPIO6/7) reste libre.
  Wire1.begin(PIN_EXT_SDA, PIN_EXT_SCL, 400000);

  ads.setGain(GAIN_SIXTEEN);               // +/-256 mV, 1 LSB = 7,8125 uV
  adcOk = ads.begin(ADS1X15_ADDRESS, &Wire1);

  if (!adcOk) {
    state = ST_ADC_FAULT;
    renderMessage("ERREUR ADS1115", "bus I2C 0x48", "verifier le cordon",
                  COL_RED);
    for (;;) { serviceRing(); delay(20); }
  }

  ads.setDataRate(RATE_ADS1115_32SPS);     // moyennage interne maximal utile
  lastSample = millis();                   // arme le chien de garde
  startConversion();                       // conversions uniques enchainees

  startRtc();
  startBaro();
  pollEnv();

  fsOk = LittleFS.begin(true);             // true = formater si necessaire
  prefsLoad();
  logLoad();

  // Bilan des peripheriques : trois lignes, deux secondes, et l'on sait ce qui
  // manque avant d'aller au bloc.
  {
    char l2[32], l3[32];
    snprintf(l2, sizeof(l2), "ADC %s  BARO %s",
             adcOk ? "ok" : "--", baroOk ? "ok" : "--");
    snprintf(l3, sizeof(l3), "RTC %s  JOURNAL %s",
             rtcOk ? "ok" : "--", fsOk ? "ok" : "--");
    renderMessage("PERIPHERIQUES", l2, l3,
                  (baroOk && rtcOk && fsOk) ? COL_GREEN : COL_AMBER);
    waitMs(2200);
  }

  // Recharge de la calibration si elle est recente. Une calibration vieille de
  // plus de 24 h n'est pas rechargee : la cellule derive, et il est plus sur
  // de repartir d'un point a l'air frais.
  uint32_t u = nowUnix();
  bool reload = (calMv >= CAL_MV_MIN && calMv <= CAL_MV_MAX)
             && (calUnix != 0) && (u > calUnix)
             && ((u - calUnix) < CAL_MAX_AGE_S);

  if (reload) {
    calValid = true;
    cellWeak = (calMv < CELL_MV_WARN);
    char l2[32];
    snprintf(l2, sizeof(l2), "%.2f mV  il y a %lu h",
             (double)calMv, (unsigned long)((u - calUnix) / 3600UL));
    renderMessage("CALIBRATION", l2, "rechargee de la memoire", COL_TEAL);
    waitMs(2000);
    state = ST_SETTLING;
  } else {
    renderMessage("CHAUFFE", "cellule neuve : 30 min", "apres installation",
                  COL_AMBER);
    waitMs(2000);
    calValid = false;
    state = ST_UNCAL;
  }
}

// ===========================================================================
//  BOUCLE
// ===========================================================================
void loop() {
  pollCell();
  pollEnv();
  serviceRing();
  serviceSerial();
  handleButton();
  handleRotation(encoderTakeDetents());
  updateState();

  if (millis() - lastDraw >= 90) {          // ~11 images/s : amplement suffisant
    lastDraw = millis();
    renderPage();
  }
}
