/*
 * ============================================================================
 *  TEST_CELLULE  —  outil de banc, a charger AVANT le firmware de l'analyseur
 *  Analyseur Nitrox v2.0  —  9H2WB / F5OWB
 * ============================================================================
 *
 *  Ce croquis ne touche pas a l'ecran. Il fait trois choses, dans l'ordre ou
 *  il faut les verifier :
 *
 *      1. scan du bus I2C externe (GPIO38/39) — l'ADS1115 doit repondre a 0x48
 *      2. lecture differentielle A0/A1 en continu, en millivolts
 *      3. statistiques glissantes : moyenne, mini, maxi, ecart pic-a-pic
 *
 *  L'ecart pic-a-pic est la grandeur a surveiller : c'est lui qui determine le
 *  seuil de stabilite du firmware. Relever sa valeur radio coupee, puis radio
 *  active, avant de figer quoi que ce soit.
 *
 *  Sortie sur le moniteur serie a 115200 bauds.
 *  Reglage indispensable : Tools > USB CDC On Boot > Enabled.
 *
 *  Licence CC0.
 * ============================================================================
 */

#include <Wire.h>
#include <Adafruit_ADS1X15.h>
#include <WiFi.h>
#include <esp_bt.h>

static const int PIN_EXT_SDA = 38;   // bus I2C EXTERNE
static const int PIN_EXT_SCL = 39;   // (le bus du tactile est sur 6/7)

static Adafruit_ADS1115 ads;
static bool adcOk = false;

// ---------------------------------------------------------------------------
//  Conversions uniques enchainees. NE PAS repasser en mode continu :
//  conversionComplete() lit le bit OS, qui vaut 0 tant que le convertisseur
//  convertit. En mode continu il convertit sans arret, le bit reste a 0 et la
//  fonction ne repond jamais vrai : on n'obtient aucun echantillon.
static const uint16_t CONV_MS = 26;        // 1/32 s = 31,25 ms
static bool           convBusy  = false;
static unsigned long  convStart = 0;
static unsigned long  lastSample = 0;

static void startConversion() {
  ads.startADCReading(ADS1X15_REG_CONFIG_MUX_DIFF_0_1, /*continuous=*/false);
  convStart = millis();
  convBusy  = true;
}

// Fenetre glissante d'une seconde environ a 32 ech/s
static const uint8_t N = 32;
static float buf[N];
static uint8_t idx = 0;
static bool   full = false;
static uint32_t total = 0;

// ---------------------------------------------------------------------------
static void scanI2C() {
  Serial.println(F("\n--- Scan du bus I2C externe (GPIO38 = SDA, GPIO39 = SCL) ---"));
  uint8_t found = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire1.beginTransmission(addr);
    if (Wire1.endTransmission() == 0) {
      Serial.printf("  0x%02X  present", addr);
      if (addr == 0x48) Serial.print(F("   <- ADS1115, attendu"));
      if (addr == 0x68) Serial.print(F("   <- DS3231 (phase 2)"));
      if (addr == 0x23) Serial.print(F("   <- BH1750 (phase 2)"));
      Serial.println();
      found++;
    }
  }
  if (found == 0) {
    Serial.println(F("  AUCUN peripherique."));
    Serial.println(F("  Verifier : cordon I2C, alimentation 3V3 du module,"));
    Serial.println(F("  et que le cordon est bien sur le connecteur EXTERNE."));
  } else {
    Serial.printf("  %u peripherique(s).\n", found);
  }
  Serial.println();
}

// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  delay(2500);                      // laisse le temps a l'USB CDC de s'enumerer

  // Radio coupee : c'est l'etat de reference pour mesurer le bruit du
  // front-end. La reactiver ensuite pour comparer.
  WiFi.mode(WIFI_OFF);
  btStop();

  Serial.println(F("============================================"));
  Serial.println(F(" TEST CELLULE O2  —  Nitrox v2.0  —  9H2WB"));
  Serial.println(F("============================================"));
  Serial.println(F(" Radio : WiFi et BLE DESACTIVES"));

  Wire1.begin(PIN_EXT_SDA, PIN_EXT_SCL, 400000);
  scanI2C();

  ads.setGain(GAIN_SIXTEEN);        // +/-256 mV  ->  1 LSB = 7,8125 uV
  adcOk = ads.begin(ADS1X15_ADDRESS, &Wire1);

  if (!adcOk) {
    Serial.println(F("ERREUR : ADS1115 injoignable. Arret."));
    for (;;) delay(1000);
  }

  ads.setDataRate(RATE_ADS1115_32SPS);
  lastSample = millis();
  startConversion();

  Serial.println(F("ADS1115 OK  —  differentiel A0/A1, gain x16, 32 ech/s"));
  Serial.println(F("Mode : conversions UNIQUES enchainees (PAS le mode continu)"));
  Serial.println(F("Reperes : air 7-13 mV | EAN40 13-25 mV | O2 pur 33-62 mV"));
  Serial.println(F("--------------------------------------------------------"));
  Serial.println(F("   n     brut      mV    moy_mV    min      max    p-p_uV"));
}

// ---------------------------------------------------------------------------
void loop() {
  // Chien de garde : si rien n'arrive, le dire, au lieu de laisser croire a
  // une cellule debranchee.
  if (millis() - lastSample > 2500UL) {
    lastSample = millis();
    Serial.println(F("!! aucun echantillon depuis 2,5 s — l'ADC ne repond plus."));
    Serial.println(F("   verifier le cordon I2C ; 0x48 doit apparaitre au scan."));
  }

  if (!convBusy) { startConversion(); delay(2); return; }
  if (millis() - convStart < CONV_MS)  { delay(2); return; }
  if (!ads.conversionComplete())       { delay(2); return; }

  int16_t raw = ads.getLastConversionResults();
  float   mv  = ads.computeVolts(raw) * 1000.0f;
  lastSample  = millis();
  startConversion();

  buf[idx] = mv;
  idx = (uint8_t)((idx + 1) % N);
  if (idx == 0) full = true;
  total++;

  uint8_t n = full ? N : idx;
  float sum = 0.0f, lo = buf[0], hi = buf[0];
  for (uint8_t i = 0; i < n; i++) {
    sum += buf[i];
    if (buf[i] < lo) lo = buf[i];
    if (buf[i] > hi) hi = buf[i];
  }
  float avg = sum / n;
  float pp  = (hi - lo) * 1000.0f;          // ecart pic-a-pic en microvolts

  // Une ligne sur huit : ~4 lignes par seconde, lisible a l'ecran
  if (total % 8 == 0) {
    Serial.printf("%6lu  %7d  %6.3f  %7.3f  %7.3f  %7.3f  %8.1f",
                  (unsigned long)total, (int)raw, (double)mv,
                  (double)avg, (double)lo, (double)hi, (double)pp);
    Serial.printf("   (%.1f LSB)\n", (double)(pp / 7.8125f));
  }
}
