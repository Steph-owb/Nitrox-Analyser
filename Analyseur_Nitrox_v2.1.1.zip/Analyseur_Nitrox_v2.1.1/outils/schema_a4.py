#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Schema electronique — Analyseur Nitrox v2.1.1
Format A4 paysage (297 x 210 mm), 2 feuilles : schema + nomenclature.
Toutes les coordonnees sont en millimetres sur la feuille.
Corps de caractere entre 7 et 18 points, soit 2,5 a 6,3 mm a l'impression.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Rectangle, Circle, FancyBboxPatch
from matplotlib.lines import Line2D

W, H = 297.0, 210.0
INK   = "#111111"
REF   = "#0B4FA0"      # designations
VAL   = "#8A2010"      # valeurs et remarques
GREY  = "#5A5F68"
RULE  = "#9AA0A8"
BODY  = "#FFFFFF"
FILLA = "#F4F7FC"      # corps des circuits
FILLB = "#FAF6EE"      # corps des organes de puissance
WARN  = "#B02418"
SANS  = "DejaVu Sans"
MONO  = "DejaVu Sans Mono"

LW   = 1.0             # trait de contour
LWW  = 1.1             # fil de signal
LWP  = 1.9             # fil de puissance


def new_sheet(pdf_only=False):
    fig, ax = plt.subplots(figsize=(W / 25.4, H / 25.4))
    ax.set_xlim(0, W); ax.set_ylim(0, H)
    ax.axis("off"); ax.set_aspect("equal")
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0)
    return fig, ax


# ---------------------------------------------------------------- primitives
def L(ax, pts, c=INK, lw=LWW, ls="-", z=3):
    ax.add_line(Line2D([p[0] for p in pts], [p[1] for p in pts], color=c, lw=lw,
                       linestyle=ls, solid_capstyle="round",
                       solid_joinstyle="round", zorder=z))

def T(ax, x, y, s, size=8, c=INK, ha="center", va="center",
      font=SANS, weight="normal", z=6, rot=0):
    ax.text(x, y, s, fontsize=size, color=c, ha=ha, va=va, family=font,
            fontweight=weight, zorder=z, rotation=rot,
            rotation_mode="anchor" if rot else None)

def dot(ax, x, y, r=0.9, c=INK):
    ax.add_patch(Circle((x, y), r, facecolor=c, edgecolor="none", zorder=7))

def gnd(ax, x, y, size=1.0, label=None):
    """Symbole de masse, tige vers le bas."""
    L(ax, [(x, y), (x, y - 3.2 * size)])
    for i, w in enumerate((7.0, 4.6, 2.2)):
        yy = y - 3.2 * size - i * 1.5 * size
        L(ax, [(x - w * size / 2, yy), (x + w * size / 2, yy)], lw=LWW + 0.5)
    if label:
        T(ax, x, y - 11.5 * size, label, 7, GREY)

def box(ax, x0, y0, x1, y1, ref, title, sub=None, fill=FILLA):
    """Cadre de circuit. Le sous-titre est place A L'INTERIEUR : au-dessus,
    il entrerait en collision avec le titre sur un cadre de 40 mm."""
    ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, facecolor=fill,
                           edgecolor=INK, lw=LW + 0.5, zorder=2))
    T(ax, x0, y1 + 5.2, ref, 11, REF, ha="left", weight="bold")
    T(ax, x0, y1 + 1.4, title, 8.4, INK, ha="left")
    if sub:
        T(ax, (x0 + x1) / 2, y1 - 8.0, sub, 7.6, GREY, font=MONO)
    return (x0, y0, x1, y1)


def pin(ax, b, side, pos, name, stub=6.5, c=INK, nc=False, namesize=7.6):
    """Broche nommee. pos = ordonnee (gauche/droite) ou abscisse (haut/bas)."""
    x0, y0, x1, y1 = b
    if side == "L":
        L(ax, [(x0 - stub, pos), (x0, pos)], c=c)
        T(ax, x0 + 1.6, pos, name, namesize, INK, ha="left", font=MONO)
        tip = (x0 - stub, pos)
    elif side == "R":
        L(ax, [(x1, pos), (x1 + stub, pos)], c=c)
        T(ax, x1 - 1.6, pos, name, namesize, INK, ha="right", font=MONO)
        tip = (x1 + stub, pos)
    elif side == "T":
        L(ax, [(pos, y1), (pos, y1 + stub)], c=c)
        T(ax, pos, y1 - 2.4, name, namesize, INK, ha="center", font=MONO)
        tip = (pos, y1 + stub)
    else:
        L(ax, [(pos, y0 - stub), (pos, y0)], c=c)
        T(ax, pos, y0 + 2.4, name, namesize, INK, ha="center", font=MONO)
        tip = (pos, y0 - stub)
    if nc:
        cx, cy = tip
        L(ax, [(cx - 1.6, cy - 1.6), (cx + 1.6, cy + 1.6)], lw=LW)
        L(ax, [(cx - 1.6, cy + 1.6), (cx + 1.6, cy - 1.6)], lw=LW)
    return tip

def netlabel(ax, x, y, text, side="R", c=REF):
    """Etiquette de net en drapeau."""
    w = 3.0 + len(text) * 1.75
    if side == "R":
        pts = [(x, y), (x + 2.4, y + 2.3), (x + w, y + 2.3),
               (x + w, y - 2.3), (x + 2.4, y - 2.3), (x, y)]
        tx, ha = x + 4.0, "left"
    else:
        pts = [(x, y), (x - 2.4, y + 2.3), (x - w, y + 2.3),
               (x - w, y - 2.3), (x - 2.4, y - 2.3), (x, y)]
        tx, ha = x - 4.0, "right"
    ax.add_patch(plt.Polygon(pts, closed=True, facecolor=BODY, edgecolor=c,
                             lw=LW, zorder=4))
    T(ax, tx, y, text, 7.4, c, ha=ha, font=MONO, z=6)

def battery(ax, x, y, w=16.0, vertical=False):
    """Deux paires de traits, longue = plus."""
    if not vertical:
        for i, (dx, h) in enumerate(((-3.0, 7.0), (-0.8, 3.6),
                                     (1.4, 7.0), (3.6, 3.6))):
            L(ax, [(x + dx, y - h / 2), (x + dx, y + h / 2)], lw=LW + 0.7)
        L(ax, [(x - w / 2, y), (x - 3.0, y)])
        L(ax, [(x + 3.6, y), (x + w / 2, y)])

def switch(ax, x, y, w=14.0, label="S1"):
    """Interrupteur unipolaire, lame ouverte."""
    L(ax, [(x - w / 2 - 5, y), (x - w / 2, y)])
    dot(ax, x - w / 2, y)
    L(ax, [(x - w / 2, y), (x + w / 2 - 2.0, y + 5.0)], lw=LWW + 0.3)
    dot(ax, x + w / 2, y)
    L(ax, [(x + w / 2, y), (x + w / 2 + 5, y)])
    T(ax, x, y + 8.6, label, 10, REF, weight="bold")

def jack(ax, x0, y0, x1, y1):
    """Embase jack mono : corps + ressort de pointe."""
    ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, facecolor=BODY,
                           edgecolor=INK, lw=LW + 0.5, zorder=3))
    ym = (y0 + y1) / 2
    L(ax, [(x0, ym + 3.5), (x1 - 3.0, ym + 3.5)], lw=LW)
    L(ax, [(x1 - 3.0, ym + 3.5), (x1 - 1.0, ym + 5.0)], lw=LW)
    L(ax, [(x0, ym - 3.5), (x1, ym - 3.5)], lw=LW)


def frame(ax, title, subtitle, sheet, of):
    ax.add_patch(Rectangle((7, 7), W - 14, H - 14, facecolor="none",
                           edgecolor=INK, lw=1.5, zorder=1))
    T(ax, 10, 197.5, title, 18, REF, ha="left", weight="bold")
    T(ax, 10, 191.0, subtitle, 9.5, GREY, ha="left")
    T(ax, 288, 197.0, "9H2WB / F5OWB", 10, INK, ha="right", weight="bold")
    T(ax, 288, 191.0, f"feuille {sheet}/{of}   ·   24 septembre 2026",
      8.5, GREY, ha="right")
    L(ax, [(10, 187.5), (288, 187.5)], c=RULE, lw=0.9, z=1)


def cartouche(ax, x0, y0, x1, y1, lines):
    ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, facecolor=BODY,
                           edgecolor=INK, lw=1.3, zorder=3))
    n = len(lines)
    h = (y1 - y0) / n
    for i, (k, v) in enumerate(lines):
        yy = y1 - (i + 0.5) * h
        if i:
            L(ax, [(x0, y1 - i * h), (x1, y1 - i * h)], c=RULE, lw=0.7, z=4)
        T(ax, x0 + 3, yy, k, 8, GREY, ha="left", z=5)
        T(ax, x0 + 34, yy, v, 9, INK, ha="left", weight="bold", z=5)
    L(ax, [(x0 + 31, y0), (x0 + 31, y1)], c=RULE, lw=0.7, z=4)


# =========================================================================
#  FEUILLE 1  —  SCHEMA
# =========================================================================
def sheet1():
    fig, ax = new_sheet()
    frame(ax, "ANALYSEUR NITROX v2.1.1",
          "Schema de principe  —  cellule galvanique, chaine de mesure, "
          "ambiance et alimentation", 1, 2)

    # ---------------------------------------------------------------- B1, J1
    box(ax, 10, 152, 48, 178, "B1", "Cellule O2", fill="#F1F8F2")
    ax.add_patch(Rectangle((40, 158), 8, 13, facecolor="#E0EFE4",
                           edgecolor=INK, lw=LW, zorder=3))
    T(ax, 25, 170, "R-17VAN", 9.5, INK, weight="bold")
    T(ax, 25, 164.5, "7 a 13 mV (air)", 7.6, GREY)
    T(ax, 25, 159.0, "M16 x 1", 7.6, GREY)
    L(ax, [(48, 165), (54, 165)])

    jack(ax, 54, 156, 68, 174)
    T(ax, 61, 183.0, "J1", 11, REF, weight="bold")
    T(ax, 61, 178.6, "embase 3,5 mm", 8.4, INK)

    # ---------------------------------------------------------------- U2 ADC
    u2 = box(ax, 88, 148, 128, 176, "U2", "Convertisseur A/N 16 bits",
             "ADS1115  0x48")
    pin(ax, u2, "L", 171, "A0")
    pin(ax, u2, "L", 164, "A1")
    pin(ax, u2, "L", 156, "ADDR")
    pin(ax, u2, "L", 151, "ALRT", nc=True)
    p2v = pin(ax, u2, "R", 171, "VDD")
    p2g = pin(ax, u2, "R", 164, "GND")
    p2d = pin(ax, u2, "R", 157, "SDA")
    p2c = pin(ax, u2, "R", 150, "SCL")
    T(ax, 109, 145.0, "differentiel AIN0 / AIN1", 7.4, VAL)
    T(ax, 109, 140.8, "PGA +/-256 mV  ·  1 LSB = 7,81 uV", 7.4, VAL)

    # pointe et corps du jack vers les deux entrees differentielles
    L(ax, [(68, 170), (76, 170), (76, 171), (81.5, 171)])
    L(ax, [(68, 162), (76, 162), (76, 164), (81.5, 164)])
    T(ax, 69.5, 174.0, "pointe", 7.4, VAL, ha="left")
    T(ax, 71.0, 157.5, "corps", 7.4, VAL, ha="left")

    # liaison Kelvin, prise A L'EMBASE
    dot(ax, 70, 162)
    L(ax, [(70, 162), (70, 146)], ls=(0, (3.2, 2.4)))
    gnd(ax, 70, 146)
    T(ax, 55, 133.0, "LIAISON KELVIN", 8.4, WARN, weight="bold")
    T(ax, 55, 128.5, "masse prise a l'embase J1,", 7.4, VAL)
    T(ax, 55, 124.3, "jamais sur la carte", 7.4, VAL)

    # ADDR rejoint la meme masse : une seule prise de terre, pas deux
    # symboles cote a cote qui se confondraient a l'impression.
    L(ax, [(81.5, 156), (76, 156), (76, 150), (70, 150)])
    dot(ax, 70, 150)

    # ---------------------------------------------------------------- U3, U4
    u3 = box(ax, 88, 106, 128, 132, "U3", "Barometre / thermometre",
             "BMP581  0x46")
    p3v = pin(ax, u3, "R", 127, "3V3")
    p3g = pin(ax, u3, "R", 121, "GND")
    p3d = pin(ax, u3, "R", 115, "SDA")
    p3c = pin(ax, u3, "R", 109, "SCL")
    T(ax, 104, 113, "30 a 1250 hPa", 7.4, VAL)

    u4 = box(ax, 88, 70, 128, 96, "U4", "Horloge temps reel",
             "DS3231  0x68")
    p4v = pin(ax, u4, "R", 91, "3V3")
    p4g = pin(ax, u4, "R", 85, "GND")
    p4d = pin(ax, u4, "R", 79, "SDA")
    p4c = pin(ax, u4, "R", 73, "SCL")
    pin(ax, u4, "L", 83, "BAT")

    battery(ax, 64, 83, w=14)
    T(ax, 64, 91.5, "BT2", 11, REF, weight="bold")
    T(ax, 64, 75.5, "CR1220  3 V", 7.8, INK)
    T(ax, 64, 71.3, "PILE, non rechargeable", 7.2, WARN, weight="bold")
    L(ax, [(71, 83), (81.5, 83)])
    L(ax, [(57, 83), (50, 83), (50, 79)])
    gnd(ax, 50, 79, size=0.5)

    # ---------------------------------------------------------------- rails
    RX = {"3V3": 134.0, "GND": 139.0, "SDA": 144.0, "SCL": 149.0}
    RC = {"3V3": VAL, "GND": INK, "SDA": REF, "SCL": REF}
    RY0, RY1 = 73.0, 171.0
    for k, x in RX.items():
        L(ax, [(x, RY0), (x, RY1)], c=RC[k],
          lw=LWP if k in ("3V3", "GND") else LWW)
        T(ax, x, RY1 + 3.0, k, 7.6, RC[k], font=MONO, rot=90, ha="left")

    def to_rail(tip, rail):
        L(ax, [tip, (RX[rail], tip[1])], c=RC[rail],
          lw=LWP if rail in ("3V3", "GND") else LWW)
        dot(ax, RX[rail], tip[1], c=RC[rail])

    for t, r in ((p2v, "3V3"), (p2g, "GND"), (p2d, "SDA"), (p2c, "SCL"),
                 (p3v, "3V3"), (p3g, "GND"), (p3d, "SDA"), (p3c, "SCL"),
                 (p4v, "3V3"), (p4g, "GND"), (p4d, "SDA"), (p4c, "SCL")):
        to_rail(t, r)

    T(ax, 153.5, 120, "BUS I2C EXTERNE  —  GPIO38 / GPIO39", 8.0, REF,
      rot=90, ha="center", weight="bold")

    # ---------------------------------------------------------------- U1
    u1 = box(ax, 158, 104, 200, 176, "U1", "Afficheur - calculateur")
    q3 = pin(ax, u1, "L", 170, "3V3")
    qg = pin(ax, u1, "L", 163, "GND")
    qd = pin(ax, u1, "L", 156, "GPIO38")
    qc = pin(ax, u1, "L", 149, "GPIO39")
    pin(ax, u1, "B", 172, "5V")
    pin(ax, u1, "B", 186, "GND")
    for tip, rail in ((q3, "3V3"), (qg, "GND"), (qd, "SDA"), (qc, "SCL")):
        L(ax, [(RX[rail], tip[1]), tip], c=RC[rail],
          lw=LWP if rail in ("3V3", "GND") else LWW)
        dot(ax, RX[rail], tip[1], c=RC[rail])

    ax.add_patch(Circle((183, 138), 14.0, facecolor="#141414",
                        edgecolor="#3A3A3A", lw=1.2, zorder=4))
    T(ax, 183, 140.5, "240 x 240", 8, "#FFFFFF", z=5)
    T(ax, 183, 135.0, "GC9A01", 7.2, "#9AA0A8", z=5)
    T(ax, 179, 121.5, "CrowPanel 1,28 pouce", 7.6, GREY, z=5, font=MONO)
    T(ax, 179, 116.5, "encodeur + anneau RGB", 7.4, GREY, z=5)
    T(ax, 179, 112.0, "ESP32-S3  ·  PSRAM 8 Mo", 7.4, GREY, z=5)

    # ---------------------------------------------------------------- M1
    m1 = box(ax, 158, 46, 200, 86, "M1", "Alimentation / chargeur",
             fill=FILLB)
    pin(ax, m1, "L", 64, "BAT")
    pin(ax, m1, "L", 54, "EN")
    pin(ax, m1, "T", 172, "5V")
    pin(ax, m1, "T", 186, "GND")
    T(ax, 179, 76, "PowerBoost 1000C", 7.6, GREY, font=MONO)
    T(ax, 179, 69, "5 V  1 A", 9.5, INK, weight="bold")
    T(ax, 179, 59, "partage de charge", 7.6, GREY)
    T(ax, 179, 41.5, "USB micro-B = recharge de l'accu", 7.4, VAL)
    L(ax, [(172, 92.5), (172, 97.5)], c=VAL, lw=LWP)
    L(ax, [(186, 92.5), (186, 97.5)], c=INK, lw=LWP)

    # ---------------------------------------------------------------- BT1
    battery(ax, 35, 64, w=22)
    T(ax, 35, 74.5, "BT1", 11, REF, weight="bold")
    T(ax, 35, 70.0, "accu Li-Po", 8.4, INK)
    T(ax, 35, 56.5, "3,7 V   2500 mAh", 7.8, INK)
    T(ax, 35, 52.3, "connecteur JST-PH 2 mm", 7.2, GREY)
    L(ax, [(46, 64), (151.5, 64)], c=VAL, lw=LWP)
    L(ax, [(24, 64), (16, 64), (16, 48)], c=INK, lw=LWP)
    gnd(ax, 16, 48)

    # ---------------------------------------------------------------- S1
    switch(ax, 122, 50, w=16)
    L(ax, [(135, 50), (144, 50), (144, 54), (151.5, 54)])
    L(ax, [(109, 50), (96, 50), (96, 46)])
    gnd(ax, 96, 46, size=0.5)
    T(ax, 124, 41.0, "S1 coupe EN : quelques uA", 7.4, VAL)

    # ---------------------------------------------------------------- notes
    ax.add_patch(Rectangle((10, 10), 140, 26, facecolor="#FDF4F3",
                           edgecolor=WARN, lw=1.0, zorder=1))
    T(ax, 13, 32.2, "A RESPECTER", 9.2, WARN, ha="left", weight="bold")
    notes = [
        "1   Masse de la cellule reprise A L'EMBASE J1 : liaison Kelvin.",
        "2   Bus I2C EXTERNE = GPIO38 / 39. Tactile (GPIO6/7) non utilise.",
        "3   GPIO1 et GPIO2 forcees a l'etat haut par setup(), sinon ecran noir.",
        "4   La cellule ne voit JAMAIS la pression : te a sortie libre.",
    ]
    for i, n in enumerate(notes):
        T(ax, 13, 27.4 - i * 4.6, n, 7.6, "#3A1414", ha="left", font=MONO)

    # ---------------------------------------------------------- nomenclature
    x0, x1, yT = 206.0, 288.0, 178.0
    T(ax, x0, yT + 3.2, "NOMENCLATURE", 10.5, REF, ha="left", weight="bold")
    rows = [
        ("B1",   "Cellule O2 Vandagraph R-17VAN"),
        ("J1",   "Embase jack mono 3,5 mm"),
        ("U1",   "Elecrow CrowPanel 1,28\" HMI"),
        ("U2",   "Adafruit ADS1115   (1085)"),
        ("U3",   "Adafruit BMP581   (6407)"),
        ("U4",   "Adafruit DS3231 QT   (5188)"),
        ("BT1",  "Accu Li-Po 3,7 V  2500 mAh"),
        ("BT2",  "Pile CR1220  3 V"),
        ("M1",   "Adafruit PowerBoost 1000C  (2465)"),
        ("S1",   "Interrupteur unipolaire"),
        ("W1-3", "Cordons STEMMA QT  100 mm"),
        ("MP1",  "Te de prelevement DIN 300 bar"),
        ("MP2",  "Restricteur calibre M16 x 1"),
        ("MP3",  "Boitier et visserie"),
    ]
    rh = 8.4
    ax.add_patch(Rectangle((x0, yT - rh), x1 - x0, rh, facecolor="#E8EDF4",
                           edgecolor=INK, lw=LW, zorder=2))
    T(ax, x0 + 3, yT - rh / 2, "Rep.", 8.4, INK, ha="left", weight="bold")
    T(ax, x0 + 22, yT - rh / 2, "Designation", 8.4, INK, ha="left",
      weight="bold")
    for i, (r, d) in enumerate(rows):
        y = yT - rh * (i + 2)
        ax.add_patch(Rectangle((x0, y), x1 - x0, rh,
                               facecolor="#F7F8FA" if i % 2 else BODY,
                               edgecolor=RULE, lw=0.6, zorder=2))
        T(ax, x0 + 3, y + rh / 2, r, 8.0, REF, ha="left", weight="bold",
          font=MONO)
        T(ax, x0 + 22, y + rh / 2, d, 7.8, INK, ha="left")
    ybot = yT - rh * (len(rows) + 1)
    ax.add_patch(Rectangle((x0, ybot), x1 - x0, yT - ybot, facecolor="none",
                           edgecolor=INK, lw=LW + 0.3, zorder=3))
    T(ax, x0, ybot - 5.2, "References fabricant, caracteristiques et",
      7.6, GREY, ha="left")
    T(ax, x0, ybot - 9.6, "fournisseurs : feuille 2.", 7.6, GREY, ha="left")

    cartouche(ax, 156, 10, 288, 36, [
        ("Projet",   "Analyseur Nitrox"),
        ("Feuille",  "1/2  —  schema de principe"),
        ("Revision", "2.1.1  —  24 sept. 2026"),
        ("Auteur",   "Stephan  ·  9H2WB / F5OWB"),
    ])
    return fig


# =========================================================================
#  FEUILLE 2  —  NOMENCLATURE DETAILLEE
# =========================================================================
def sheet2():
    fig, ax = new_sheet()
    frame(ax, "NOMENCLATURE", "Analyseur Nitrox v2.1.1  —  liste complete "
          "des composants et fournisseurs", 2, 2)

    cols = [("Rep.", 14), ("Designation", 48), ("Caracteristiques", 90),
            ("Reference", 58), ("Fournisseur", 46), ("Qte", 12)]
    rows = [
        ("B1", "Cellule O2 galvanique",
         "7 a 13 mV dans l'air, jack 3,5 mm, filetage M16 x 1",
         "Vandagraph R-17VAN  0110217", "Vandagraph, Scuba Support", "1"),
        ("J1", "Embase jack mono 3,5 mm",
         "chassis, corps repris a la masse (liaison Kelvin)",
         "—", "distribution generale", "1"),
        ("U1", "Afficheur - calculateur",
         "ESP32-S3, 240x240 GC9A01, encodeur, anneau RGB",
         "CrowPanel 1,28\" HMI Rotary", "Elecrow, BerryBase", "1"),
        ("U2", "Convertisseur A/N 16 bits",
         "I2C 0x48, PGA +/-256 mV, entrees differentielles",
         "Adafruit ADS1115   (1085)", "Adafruit, BerryBase", "1"),
        ("U3", "Barometre / thermometre",
         "I2C 0x46 ou 0x47, 30 a 1250 hPa, STEMMA QT",
         "Adafruit BMP581   (6407)", "Adafruit, BerryBase", "1"),
        ("U4", "Horloge temps reel",
         "I2C 0x68, +/-2 ppm, STEMMA QT",
         "Adafruit DS3231   (5188)", "Adafruit, BerryBase", "1"),
        ("BT2", "Pile lithium 3 V",
         "CR1220 — PILE PRIMAIRE, pas d'accu LIR2032",
         "CR1220", "distribution generale", "1"),
        ("M1", "Alimentation / chargeur",
         "5 V 1 A, partage de charge, broche EN de coupure",
         "Adafruit PowerBoost 1000C  (2465)", "Adafruit, BerryBase", "1"),
        ("BT1", "Accu lithium-polymere",
         "3,7 V, 2500 mAh, connecteur JST-PH 2 mm",
         "—", "BerryBase", "1"),
        ("S1", "Interrupteur unipolaire",
         "commute la broche EN de M1, quelques uA",
         "—", "distribution generale", "1"),
        ("W1-W3", "Cordons STEMMA QT / Qwiic",
         "100 mm, 4 conducteurs, chainage des modules",
         "—", "Adafruit, BerryBase", "3"),
        ("MP1", "Te de prelevement",
         "DIN 300 bar, sortie libre, taraudage M16 x 1",
         "—", "Vandagraph, Scuba Support", "1"),
        ("MP2", "Restricteur calibre",
         "orifice en ecoulement sonique, debit vise 0,5 a 2 L/min",
         "—", "usinage, voir dossier v1.2", "1"),
        ("MP3", "Boitier et visserie",
         "decoupe ronde pour l'afficheur, passage du jack",
         "—", "distribution generale", "1"),
    ]

    x0 = 10.0
    xs, x = [], x0
    for _, w in cols:
        xs.append(x); x += w
    xEnd = x
    yT, rh = 176.0, 8.2

    ax.add_patch(Rectangle((x0, yT - rh), xEnd - x0, rh, facecolor="#E8EDF4",
                           edgecolor=INK, lw=LW + 0.3, zorder=2))
    for (name, _), xc in zip(cols, xs):
        T(ax, xc + 2.5, yT - rh / 2, name, 8.8, INK, ha="left", weight="bold")

    for i, r in enumerate(rows):
        y = yT - rh * (i + 2)
        ax.add_patch(Rectangle((x0, y), xEnd - x0, rh,
                               facecolor="#F7F8FA" if i % 2 else BODY,
                               edgecolor=RULE, lw=0.6, zorder=2))
        for j, (cell, xc) in enumerate(zip(r, xs)):
            col = REF if j == 0 else INK
            wt = "bold" if j == 0 else "normal"
            sz = 8.4 if j in (0, 1) else 8.0
            fnt = MONO if j == 0 else SANS
            if "PRIMAIRE" in cell:
                col, wt = WARN, "bold"
            T(ax, xc + 2.5, y + rh / 2, cell, sz, col, ha="left", font=fnt,
              weight=wt)
    ybot = yT - rh * (len(rows) + 1)
    ax.add_patch(Rectangle((x0, ybot), xEnd - x0, yT - ybot, facecolor="none",
                           edgecolor=INK, lw=LW + 0.5, zorder=3))
    for xc in xs[1:]:
        L(ax, [(xc, ybot), (xc, yT)], c=RULE, lw=0.7, z=4)

    ax.add_patch(Rectangle((10, 10), 140, 36, facecolor="#F4F7FC",
                           edgecolor=REF, lw=1.0, zorder=1))
    T(ax, 13, 42.0, "REMARQUES D'APPROVISIONNEMENT", 9.2, REF, ha="left",
      weight="bold")
    rem = [
        "Le choix de la cellule tient a sa mecanique, non a sa metrologie : jack 3,5 mm",
        "deja monte et filetage M16 x 1 standard suppriment tout usinage.",
        "",
        "BT2 est une PILE. Le module Adafruit 5188 n'a pas de circuit de charge,",
        "contrairement aux clones ZS-042 : ne jamais y monter un accu LIR2032.",
        "",
        "Les trois modules I2C se chainent par cordons STEMMA QT : aucune soudure.",
    ]
    for i, n in enumerate(rem):
        T(ax, 13, 37.0 - i * 4.2, n, 7.6, "#16324F", ha="left")

    cartouche(ax, 156, 10, 288, 40, [
        ("Projet",   "Analyseur Nitrox"),
        ("Feuille",  "2/2  —  nomenclature"),
        ("Revision", "2.1.1  —  24 sept. 2026"),
        ("Auteur",   "Stephan  ·  9H2WB / F5OWB"),
    ])
    return fig


# =========================================================================
f1, f2 = sheet1(), sheet2()
with PdfPages("/home/claude/nitrox_v2/Schema_Nitrox_v211.pdf") as pdf:
    pdf.savefig(f1); pdf.savefig(f2)
f1.savefig("/home/claude/nitrox_v2/schema_nitrox_v211.png", dpi=200,
           facecolor="white")
f2.savefig("/home/claude/nitrox_v2/nomenclature_nitrox_v211.png", dpi=200,
           facecolor="white")
print("Schema_Nitrox_v211.pdf  (A4 paysage, 2 feuilles)")
print("plus petit corps de caractere : 7,2 pt  =  2,54 mm a l'impression")
