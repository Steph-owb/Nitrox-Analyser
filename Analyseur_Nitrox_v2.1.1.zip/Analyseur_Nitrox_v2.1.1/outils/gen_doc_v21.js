/* Documentation d'installation et de mise en oeuvre — Analyseur Nitrox v2.1 */
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
  PageBreak, ImageRun, LevelFormat, PageOrientation,
  Header, Footer, PageNumber,
} = require('docx');

const F = 'Calibri', MONO = 'Consolas';
const ACC = '0B4FA0', WARN = 'B02418', OKC = '1E7A32', GREY = '555555';
const CW = 9638;                       // largeur utile en DXA

// --- briques -------------------------------------------------------------
const p = (t, o = {}) => new Paragraph({
  spacing: { after: 110, line: 264 }, ...o.par,
  children: [new TextRun({ text: t, font: F, size: 21, ...o.run })],
});
const lead = (t) => new Paragraph({
  spacing: { after: 160 },
  children: [new TextRun({ text: t, font: F, size: 21, italics: true, color: GREY })],
});
const warnP = (t) => new Paragraph({
  spacing: { before: 90, after: 150 }, indent: { left: 170 },
  border: { left: { style: BorderStyle.SINGLE, size: 18, color: WARN, space: 8 } },
  children: [new TextRun({ text: t, font: F, size: 21, bold: true, color: WARN })],
});
const noteP = (t) => new Paragraph({
  spacing: { before: 90, after: 150 }, indent: { left: 170 },
  border: { left: { style: BorderStyle.SINGLE, size: 18, color: ACC, space: 8 } },
  children: [new TextRun({ text: t, font: F, size: 21, color: '1A1A1A' })],
});
const bul = (t, b) => new Paragraph({
  numbering: { reference: 'puces', level: 0 }, spacing: { after: 70 },
  children: [
    ...(b ? [new TextRun({ text: b + ' — ', bold: true, font: F, size: 21 })] : []),
    new TextRun({ text: t, font: F, size: 21 })],
});
const step = (n, t, b) => new Paragraph({
  spacing: { after: 90 }, indent: { left: 340, hanging: 340 },
  children: [
    new TextRun({ text: n + '.  ', bold: true, font: F, size: 21, color: ACC }),
    ...(b ? [new TextRun({ text: b + ' — ', bold: true, font: F, size: 21 })] : []),
    new TextRun({ text: t, font: F, size: 21 })],
});
const h1 = (t) => new Paragraph({
  heading: HeadingLevel.HEADING_1, spacing: { before: 300, after: 150 },
  children: [new TextRun({ text: t, font: F, size: 28, bold: true, color: ACC })],
});
const h2 = (t) => new Paragraph({
  heading: HeadingLevel.HEADING_2, spacing: { before: 230, after: 110 },
  children: [new TextRun({ text: t, font: F, size: 23, bold: true, color: ACC })],
});
const code = (t) => new Paragraph({
  spacing: { before: 50, after: 50 }, shading: { type: ShadingType.CLEAR, fill: 'F2F3F5' },
  children: [new TextRun({ text: t.length ? '  ' + t : ' ', font: MONO, size: 17, color: '1A1A1A' })],
});

function cell(t, { w, bold, mono, fill, color, size } = {}) {
  return new TableCell({
    width: { size: w, type: WidthType.DXA },
    shading: fill ? { type: ShadingType.CLEAR, fill } : undefined,
    margins: { top: 60, bottom: 60, left: 90, right: 90 },
    children: [new Paragraph({
      spacing: { after: 0 },
      children: [new TextRun({
        text: t, font: mono ? MONO : F, size: size || (mono ? 17 : 18),
        bold: !!bold, color: color || '1A1A1A',
      })],
    })],
  });
}
function table(head, rows, widths, monoCols = []) {
  return new Table({
    columnWidths: widths,
    width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA },
    borders: {
      top:    { style: BorderStyle.SINGLE, size: 4, color: 'B8BCC4' },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: 'B8BCC4' },
      left:   { style: BorderStyle.SINGLE, size: 4, color: 'B8BCC4' },
      right:  { style: BorderStyle.SINGLE, size: 4, color: 'B8BCC4' },
      insideHorizontal: { style: BorderStyle.SINGLE, size: 3, color: 'D5D8DE' },
      insideVertical:   { style: BorderStyle.SINGLE, size: 3, color: 'D5D8DE' },
    },
    rows: [
      new TableRow({
        tableHeader: true,
        children: head.map((t, i) => cell(t, { w: widths[i], bold: true, fill: 'E8EDF4' })),
      }),
      ...rows.map((r, ri) => new TableRow({
        children: r.map((t, i) => cell(t, {
          w: widths[i], mono: monoCols.includes(i),
          fill: ri % 2 ? 'F7F8FA' : undefined,
        })),
      })),
    ],
  });
}
const gap = (h = 120) => new Paragraph({ spacing: { after: h }, children: [] });

// =========================================================================
const body = [];

// --- page de titre -------------------------------------------------------
body.push(
  gap(900),
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 90 },
    children: [new TextRun({ text: 'ANALYSEUR NITROX', font: F, size: 52, bold: true, color: ACC })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 400 },
    children: [new TextRun({ text: 'v2.1  ·  phase 2', font: F, size: 34, color: GREY })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 120 },
    children: [new TextRun({ text: 'Documentation d’installation et de mise en œuvre', font: F, size: 28, bold: true })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 600 },
    children: [new TextRun({
      text: 'Installation depuis l’IDE Arduino  ·  mise en service  ·  manuel d’utilisation  ·  dépannage',
      font: F, size: 21, color: GREY })],
  }),
);

if (fs.existsSync('/home/claude/nitrox_v2/ecrans_v21.png')) {
  body.push(new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 500 },
    children: [new ImageRun({
      type: 'png',
      data: fs.readFileSync('/home/claude/nitrox_v2/ecrans_v21.png'),
      transformation: { width: 580, height: 325 },
    })],
  }));
}

body.push(
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 60 },
    children: [new TextRun({ text: 'Stephan  ·  9H2WB / F5OWB', font: F, size: 22, bold: true })],
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { after: 400 },
    children: [new TextRun({ text: 'révision 2.1.1  ·  24 septembre 2026', font: F, size: 20, color: GREY })],
  }),
  warnP('Appareil non certifié. Toute analyse critique doit être recoupée sur un second instrument indépendant. Ne jamais mettre la cellule en pression : restricteur DIN calibré et té de prélèvement à sortie libre, toujours.'),
  new Paragraph({ children: [new PageBreak()] }),
);

// --- sommaire ------------------------------------------------------------
body.push(
  h1('Sommaire'),
  gap(60),
  table(
    ['Partie', 'Contenu'],
    [
      ['1.  \u00c0 propos de ce document', 'ce que couvre ce dossier, mat\u00e9riel suppos\u00e9 en place'],
      ['2.  Notes de conception', 'facteur limitant \u00b7 mode diff\u00e9rentiel et gain \u00d716 \u00b7 liaison Kelvin \u00b7 compensation en pression \u00b7 radio coup\u00e9e \u00b7 molette seule \u00b7 ce qui reste \u00e0 v\u00e9rifier'],
      ['3.  Installation depuis l\u2019IDE Arduino', 'logiciels et versions \u00b7 support ESP32 \u00b7 biblioth\u00e8ques \u00b7 r\u00e9glages de carte \u00b7 t\u00e9l\u00e9versement \u00b7 port introuvable'],
      ['4.  Premi\u00e8re mise en service', 'croquis de banc \u00b7 \u00e9cart pic-\u00e0-pic \u00b7 bilan des p\u00e9riph\u00e9riques \u00b7 horloge \u00b7 altitude \u00b7 calibration \u00e0 l\u2019air'],
      ['5.  Manuel d\u2019utilisation', 'grammaire de la molette \u00b7 les cinq pages \u00b7 anneau lumineux \u00b7 mesurer un bloc \u00b7 journal \u00b7 recalibrer'],
      ['6.  D\u00e9pannage', 'quinze sympt\u00f4mes, cause probable et rem\u00e8de'],
      ['7.  Annexes', 'brochage \u00b7 format du journal \u00b7 formules \u00b7 v\u00e9rifications faites \u00b7 protocole de la campagne gaz \u00b7 sources \u00b7 schema et nomenclature'],
    ],
    [3100, 6538]),
  gap(),
  lead('Les trois r\u00e9glages qui expliquent presque toutes les pannes de mise en route sont au \u00a7 3.4 : USB CDC On Boot, PSRAM, et surtout le profil de partition.'),
  new Paragraph({ children: [new PageBreak()] }),
);

// =========================================================================
body.push(
  h1('1.  À propos de ce document'),
  lead('Trois manuels en un : ce qui a été conçu et pourquoi, comment installer la chaîne logicielle, comment se servir de l’appareil.'),
  p('La partie 2 rassemble mes notes de conception : les choix techniques qui ne se lisent pas dans le code et qu’il serait coûteux de redécouvrir dans deux ans. La partie 3 est la procédure d’installation depuis l’IDE Arduino, écrite pour être suivie une ligne après l’autre. Les parties 4 et 5 sont la mise en service et le manuel d’utilisation. La partie 6 est un tableau de dépannage, la partie 7 les annexes.'),
  p('Le matériel est supposé câblé et vérifié : CrowPanel 1,28 pouce, ADS1115, BMP581 et DS3231 chaînés sur le bus I2C externe, cellule Vandagraph R-17VAN sur jack 3,5 mm, alimentation PowerBoost 1000C et accu LiPo.'),
  gap(60),
  table(
    ['Révision', 'Ce qui change'],
    [
      ['2.0  phase 1', 'mesure O2 et calibration à la molette'],
      ['2.1  phase 2', 'BMP581 et DS3231 · compensation en pression · journal horodaté sur LittleFS · interface refondue en cinq pages · commandes série'],
      ['2.1.1', 'correction de l’acquisition ADS1115 (§ 2.8) · chien de garde d’acquisition · écran ADC MUET · message distinct à la calibration'],
    ],
    [2400, 7238]),

  h1('2.  Notes de conception'),
  lead('Ce qui a été décidé, et la raison. Un choix dont on a oublié le motif finit par être défait par erreur.'),

  h2('2.1  Le facteur limitant est la cellule, pas l’électronique'),
  p('L’ADS1115 en gain ×16 résout 7,81 µV par pas. Sur une cellule qui délivre 12,0 mV dans l’air, cela représente 0,014 % d’oxygène par pas : deux ordres de grandeur sous ce que la cellule elle-même garantit. Toute l’incertitude utile vient donc de la cellule, de sa température, de son âge et de la stabilité du débit de prélèvement. Il ne sert à rien de raffiner la chaîne de mesure ; il sert à surveiller la cellule, ce que fait la page CELLULE.'),
  noteP('Conséquence pratique : la seule amélioration de précision qui vaille encore la peine est de mesurer la linéarité de la cellule sur cinq gaz (air, EAN32, EAN36, EAN40, O2 pur). C’est faisable à Massongy et cela reste à faire.'),

  h2('2.2  Mode différentiel et gain ×16'),
  p('La conversion est faite en différentiel AIN0–AIN1, jamais en asymétrique. Une cellule galvanique est une source flottante de quelques millivolts : en asymétrique, la moindre chute de tension dans le retour de masse s’ajoute au signal. En différentiel, elle est commune aux deux entrées et s’élimine.'),
  p('Le gain ×16 donne une pleine échelle de ±256 mV. La plage utile va de 7 mV (air, cellule en fin de vie) à 62 mV (oxygène pur, cellule neuve) : le calibre est largement couvert, calibration deux points comprise, sans risque de saturation.'),
  code('ads.setGain(GAIN_SIXTEEN);                      // +/-256 mV, 7,8125 uV/LSB'),
  code('ads.startADCReading(ADS1X15_REG_CONFIG_MUX_DIFF_0_1, true);'),
  p('La lecture est non bloquante : le croquis interroge conversionComplete() à chaque tour de boucle au lieu d’attendre. À 32 échantillons par seconde, la fenêtre glissante de 24 valeurs couvre environ 750 ms.'),

  h2('2.3  La masse est reprise à l’embase jack'),
  p('Le négatif de la cellule part vers AIN1 et, séparément, vers la masse — mais cette reprise de masse est prise À L’EMBASE, pas sur la carte. C’est une liaison Kelvin.'),
  warnP('Sans cette reprise, une cellule entièrement flottante peut sortir de la plage de tension de mode commun de l’ADS1115 (GND−0,3 V à VDD+0,3 V). Le symptôme est déroutant : lectures erratiques, ou erreur cellule sans cause apparente, alors que le multimètre affiche une tension parfaitement normale aux bornes de la cellule.'),

  h2('2.4  La compensation en pression — l’apport réel du BMP581'),
  p('Une cellule galvanique ne mesure pas une fraction d’oxygène : elle mesure une pression partielle. Sa tension suit V = k · FO2 · Pabs. La calibration à l’air mémorise V_cal sous la pression P_cal ; toute mesure ultérieure sous une pression P doit donc être corrigée :'),
  code('FO2 = 0,209 x (V / V_cal) x (P_cal / P)'),
  p('Tant qu’on calibre et qu’on mesure au même endroit à quelques minutes d’intervalle, le facteur vaut 1 et la question ne se pose pas. Elle se pose dès que la météo bouge entre-temps, et elle devient sérieuse dès qu’on change d’altitude. Le cas concret :'),
  gap(60),
  table(
    ['Situation', 'Sans compensation', 'Avec compensation', 'Conséquence'],
    [
      ['Calibration et mesure à Malte, 1013 hPa', '32,00 %', '32,00 %', 'aucune'],
      ['Calibration à Malte, mesure à Massongy, 955 hPa', '30,16 %', '32,00 %', 'MOD annoncée 36,4 m au lieu de 33,8 m'],
      ['Météo : 25 hPa de baisse entre calibration et mesure', '31,21 %', '32,00 %', 'MOD annoncée 34,9 m au lieu de 33,8 m'],
    ],
    [3400, 1800, 1800, 2638]),
  gap(),
  p('L’erreur va toujours dans le sens dangereux : sans compensation, un mélange mesuré en altitude paraît plus pauvre qu’il n’est, donc la profondeur maxi calculée est trop optimiste. C’est la raison d’être du BMP581 dans ce montage.'),
  noteP('Le calcul n’utilise que la pression ABSOLUE, qui ne demande aucun étalonnage. L’altitude réglable de la page AMBIANCE ne sert qu’à afficher un QNH lisible par un humain : elle n’entre pas dans le %O2. C’est volontaire — un réglage qui influencerait la mesure serait un réglage qu’on peut fausser.'),
  p('Un garde-fou neutralise la correction si le rapport P_cal/P sort de 0,80 à 1,25. Au-delà, ce n’est plus de la météo : c’est un capteur en défaut ou une calibration faite à une tout autre altitude. La page AMBIANCE affiche alors « pression suspecte » au lieu du facteur.'),

  h2('2.5  La radio est coupée'),
  p('WiFi et Bluetooth sont désactivés dès le début de setup(). Une radio qui tire 240 mA en crête sur le même rail, à deux centimètres d’un front-end à 10 mV, est un problème qu’il vaut mieux ne pas avoir à diagnostiquer. Le gain en autonomie est un bonus, pas le motif.'),

  h2('2.6  La molette seule, jamais le tactile'),
  p('Le CrowPanel a une dalle tactile capacitive. Elle n’est utilisée nulle part et le bus qui la porte (GPIO6/7) reste libre. Un écran capacitif ne répond ni aux doigts mouillés ni aux gants — c’est-à-dire précisément dans les conditions où l’on se sert de cet appareil. Aucune fonction ne doit donc passer obligatoirement par le tactile.'),
  p('L’interface est bâtie sur deux niveaux, comme un bouton intelligent : la rotation change de page, l’appui court entre dans la page et la rotation règle alors la valeur de cette page. Les appuis longs affichent un arc de progression, de sorte qu’on voit l’action arriver et qu’on peut renoncer avant de relâcher.'),

  h2('2.7  Ce qui reste à vérifier'),
  lead('Honnêteté du dossier : voici ce qui n’a pas encore été mesuré sur le matériel réel.'),
  gap(60),
  table(
    ['Point', 'Statut', 'Comment le lever'],
    [
      ['Bruit réel du front-end, radio coupée et radio active',
       'non mesuré', 'croquis test_cellule.ino, relever l’écart pic-à-pic dans les deux cas'],
      ['Justesse absolue sur gaz connu', 'non mesurée',
       'campagne gaz à Malte, protocole en annexe E'],
      ['Débit réel du restricteur DIN', 'calculé, non vérifié',
       'débitmètre à bille ; Cd = 0,62 reste une hypothèse à ±10 %'],
      ['Linéarité de la cellule', 'non mesurée',
       'campagne gaz à Malte, protocole en annexe E'],
      ['Dérive de la cellule dans le temps', 'suivi en place',
       'le champ ref_mv de chaque ligne du journal reconstruit la courbe'],
      ['Autonomie sur accu', 'non mesurée',
       'rétroeclairage à fond, c’est le poste dominant'],
    ],
    [3100, 2000, 4538]),

  h2('2.8  Le piège du mode continu de l’ADS1115'),
  lead('Trouvé aux premiers essais sur le matériel réel. À ne jamais réintroduire.'),
  p('La première version de l’acquisition démarrait le convertisseur en mode continu, puis attendait conversionComplete() avant chaque lecture. C’est faux, et la panne est trompeuse.'),
  p('conversionComplete() de la bibliothèque Adafruit lit le bit OS du registre de configuration. Ce bit vaut 0 TANT QUE le convertisseur convertit, et 1 seulement lorsqu’il est au repos. En mode continu, l’ADS1115 convertit sans interruption : le bit reste à 0 indéfiniment et la fonction ne répond jamais vrai.'),
  warnP('Conséquence : aucun échantillon n’entre dans la fenêtre glissante, la moyenne vaut 0,00 mV, et la calibration échoue sous le seuil bas de 4 mV en affichant ERREUR CELLULE — vérifier le câblage. Le message envoie chercher la panne exactement là où elle n’est pas, alors que le multimètre lit 12 mV parfaitement normaux aux bornes de la cellule.'),
  p('Le symptôme distinctif : la commande i annonce une tension de 0,0000 mV avec un écart pic-à-pic de 999 000 µV, valeur sentinelle qui signifie « moins de deux échantillons ». Une cellule réellement débranchée donnerait du bruit, pas un zéro parfait.'),
  p('Le firmware enchaîne désormais des conversions UNIQUES. Chaque échantillon correspond à une conversion réelle et distincte — propriété dont dépend le critère de stabilité, qui mesure un écart pic-à-pic : des échantillons relus deux fois feraient paraître stable un signal qui ne l’est pas. Une garde temporelle de 26 ms, pour une conversion qui en dure 31,25 à 32 éch/s, interdit d’interroger le bit OS avant que la conversion ait réellement commencé.'),
  code('ads.startADCReading(ADS1X15_REG_CONFIG_MUX_DIFF_0_1, /*continuous=*/false);'),
  noteP('Indice qui aurait dû alerter plus tôt : la bibliothèque Adafruit n’emploie le mode continu dans aucune de ses propres fonctions de lecture. Son readADC_Differential_0_1() fait une conversion unique puis attend. Quand une bibliothèque n’utilise jamais un de ses propres modes, c’est rarement un oubli.'),
  p('Deux garde-fous ont été ajoutés pour qu’une panne d’acquisition se dénonce elle-même au lieu de se déguiser en cellule absente : un chien de garde bascule en ADC MUET après 2,5 s sans conversion, avec une page dédiée à l’écran, et la calibration distingue désormais « aucun échantillon reçu » de « tension hors plage ».'),
  new Paragraph({ children: [new PageBreak()] }),
);

// =========================================================================
body.push(
  h1('3.  Installation depuis l’IDE Arduino'),
  lead('Une seule séquence à suivre dans l’ordre. Les trois réglages critiques sont signalés.'),

  h2('3.1  Ce qu’il faut installer'),
  gap(60),
  table(
    ['Élément', 'Version', 'Provenance'],
    [
      ['IDE Arduino', '2.3 ou plus récent', 'arduino.cc/en/software'],
      ['Support de cartes esp32', '3.0 ou plus récent', 'gestionnaire de cartes, voir 3.2'],
      ['LovyanGFX', '1.1 ou plus récent', 'gestionnaire de bibliothèques'],
      ['Adafruit ADS1X15', '2.6 ou plus récent', 'gestionnaire de bibliothèques'],
      ['Adafruit NeoPixel', '1.12 ou plus récent', 'gestionnaire de bibliothèques'],
      ['Adafruit BMP5xx Library', '1.0.2 ou plus récent', 'gestionnaire de bibliothèques'],
      ['RTClib', '2.1 ou plus récent', 'gestionnaire de bibliothèques'],
    ],
    [3400, 2400, 3838]),
  gap(),
  noteP('Aucun pilote USB à installer. L’ESP32-S3 du CrowPanel expose un port USB natif ; Windows 10 et 11, macOS et Linux le reconnaissent seuls, sous le nom « USB Serial Device ». Si vous cherchez un pilote CP2102 ou CH340, vous vous êtes trompé de carte.'),

  h2('3.2  Ajouter le support ESP32'),
  step(1, 'Ouvrir Fichier > Préférences.'),
  step(2, 'Dans « URL de gestionnaire de cartes supplémentaires », coller :'),
  code('https://espressif.github.io/arduino-esp32/package_esp32_index.json'),
  step(3, 'Valider, puis ouvrir Outils > Type de carte > Gestionnaire de cartes.'),
  step(4, 'Chercher esp32, installer le paquet « esp32 » d’Espressif Systems. Le téléchargement fait plusieurs centaines de mégaoctets ; c’est normal.'),
  step(5, 'Sélectionner ensuite Outils > Type de carte > esp32 > ESP32S3 Dev Module.'),

  h2('3.3  Installer les bibliothèques'),
  p('Outils > Gérer les bibliothèques, puis chercher et installer les cinq entrées du tableau 3.1, en respectant les noms exacts — plusieurs bibliothèques portent des noms voisins.'),
  warnP('Adafruit BMP5xx Library et RTClib demandent des dépendances (Adafruit BusIO, Adafruit Unified Sensor). L’IDE le propose dans une boîte de dialogue : répondre « Install all ». Répondre « Install only this » produit des erreurs de compilation incompréhensibles.'),

  h2('3.4  Réglages de carte'),
  p('Menu Outils. Ces réglages ne sont pas des préférences : chacun a une conséquence précise en cas d’erreur.'),
  gap(60),
  table(
    ['Réglage', 'Valeur', 'Si c’est faux'],
    [
      ['Board', 'ESP32S3 Dev Module', 'rien ne compile, ou rien ne démarre'],
      ['USB CDC On Boot', 'Enabled', 'le moniteur série reste muet — panne nº 1'],
      ['USB Mode', 'Hardware CDC and JTAG', 'port absent après le premier téléversement'],
      ['PSRAM', 'OPI PSRAM', 'createSprite() échoue, écran noir'],
      ['Flash Size', '16MB (128Mb)', 'téléversement refusé ou plantage au démarrage'],
      ['Partition Scheme', 'Huge APP (3MB No OTA/1MB SPIFFS)', 'le journal n’est jamais écrit — voir ci-dessous'],
      ['CPU Frequency', '240 MHz', 'affichage saccadé'],
      ['Upload Speed', '921600', 'si échec répété, redescendre à 115200'],
    ],
    [2900, 3300, 3438]),
  gap(),
  warnP('Le profil de partition est le piège de cette version. LittleFS monte par défaut la partition dont l’ÉTIQUETTE est « spiffs ». Or les deux profils 16 Mo proposés par l’IDE — « 16M Flash (2MB APP/12.5MB FATFS) » et « 16M Flash (3MB APP/9.9MB FATFS) » — ne créent qu’une partition « ffat ». Avec eux, LittleFS.begin() échoue, l’écran de bilan affiche JOURNAL --, et chaque enregistrement répond « mémoire seule » : les mesures disparaissent à l’extinction.'),
  p('Le profil Huge APP donne 3 Mo d’application — environ le triple de ce que pèse ce croquis — et 896 ko de partition spiffs, soit de l’ordre de 14 000 mesures dans le journal. C’est le bon compromis ici : l’OTA ne sert à rien puisque la radio est coupée.'),

  h2('3.5  Brancher et téléverser'),
  step(1, 'Relier le CrowPanel au PC par un câble USB-C de DONNÉES. Un câble de charge seul ne fait apparaître aucun port : c’est la deuxième cause de perte de temps après USB CDC On Boot.'),
  step(2, 'Vérifier que le port apparaît dans Outils > Port. Sous Windows il porte le nom « USB Serial Device (COMx) ».'),
  step(3, 'Ouvrir le croquis, puis Téléverser. La première compilation est longue ; les suivantes sont rapides.'),
  step(4, 'Ouvrir le moniteur série à 115200 bauds pour voir les messages.'),

  h2('3.6  Si le port n’apparaît pas'),
  p('Forcer le mode téléversement : maintenir BOOT enfoncé, appuyer brièvement sur RESET, relâcher BOOT. La carte est alors en attente de téléversement quel que soit l’état du croquis précédent. Après le téléversement, appuyer une fois sur RESET pour repartir normalement.'),
  warnP('Ne pas maintenir la molette enfoncée au démarrage : GPIO45 et GPIO46 sont des broches de strapping de l’ESP32-S3 et conditionnent le mode de démarrage.'),
  new Paragraph({ children: [new PageBreak()] }),
);

// =========================================================================
body.push(
  h1('4.  Première mise en service'),
  lead('Dans cet ordre. Chaque étape valide la précédente.'),

  h2('4.1  D’abord le croquis de banc'),
  p('Charger test_cellule.ino AVANT le firmware. Il ne touche pas à l’écran et fait trois choses : scan du bus I2C externe, lecture différentielle continue en millivolts, et statistiques glissantes dont l’écart pic-à-pic.'),
  p('Au scan, on doit voir répondre :'),
  gap(60),
  table(
    ['Adresse', 'Périphérique', 'Remarque'],
    [
      ['0x48', 'ADS1115', 'adresse par défaut, ADDR à la masse'],
      ['0x68', 'DS3231', 'horloge'],
      ['0x57', 'AT24C32', 'uniquement sur les modules clones ; absent sur l’Adafruit 5188'],
      ['0x46 ou 0x47', 'BMP581', '0x46 par défaut ; 0x47 si le pont d’adresse est coupé'],
    ],
    [1900, 2400, 5338], [0]),
  gap(),
  warnP('Si le scan ne trouve rien, c’est presque toujours que le cordon est branché sur le mauvais connecteur. Le bus EXTERNE est sur GPIO38 (SDA) et GPIO39 (SCL). Le bus du tactile est sur GPIO6/7 et ne porte aucun de ces modules.'),

  h2('4.2  Interpréter l’écart pic-à-pic'),
  p('C’est la grandeur à relever, radio coupée puis radio active, avant de figer quoi que ce soit. Elle détermine le seuil de stabilité du firmware.'),
  gap(60),
  table(
    ['Écart pic-à-pic', 'Lecture', 'Action'],
    [
      ['moins de 25 µV (3 LSB)', 'excellent', 'rien à faire'],
      ['25 à 50 µV', 'normal', 'rien à faire, le seuil du firmware est à 50 µV'],
      ['50 à 150 µV', 'perturbé', 'vérifier la reprise de masse à l’embase, éloigner les fils de cellule du rétroeclairage'],
      ['plus de 150 µV', 'anormal', 'contact de jack, ou cellule en fin de vie, ou mode commun — voir 2.3'],
    ],
    [2500, 1900, 5238]),
  gap(),
  p('Le seuil retenu dans le firmware est le plus grand de 50 µV et de 0,4 % de la lecture. Un seuil plus serré que le bruit propre de l’ADS1115 ne pourrait jamais être satisfait : la mesure resterait éternellement « en acquisition ».'),

  h2('4.3  Charger le firmware'),
  p('Téléverser nitrox_v2.ino. Au démarrage, l’appareil affiche successivement le logo, un écran de bilan des périphériques, puis soit la calibration rechargée, soit l’écran de chauffe.'),
  p('L’écran de bilan liste quatre états. Il est vert si tout répond, ambre sinon :'),
  bul('ADC ok — l’ADS1115 répond. S’il manque, l’appareil s’arrête là : sans lui il n’y a pas de mesure.', 'ADC'),
  bul('BARO ok — le BMP581 répond. S’il manque, la compensation en pression est inactive et la page AMBIANCE le dit.', 'BARO'),
  bul('RTC ok — le DS3231 répond. S’il manque, les enregistrements n’ont pas d’horodatage.', 'RTC'),
  bul('JOURNAL ok — LittleFS est monté. S’il manque, revoir le profil de partition (3.4).', 'JOURNAL'),

  h2('4.4  Régler l’horloge'),
  p('À la première mise sous tension avec une pile CR1220 neuve, le DS3231 signale une perte d’alimentation ; le firmware le cale alors sur la date de compilation, ce qui est juste à quelques minutes près. Pour la régler exactement, ouvrir le moniteur série à 115200 bauds et envoyer :'),
  code('T1790000000'),
  p('où le nombre est l’heure Unix (epoch) du moment. Un epoch antérieur à 2024 est refusé : c’est une faute de frappe, pas une date.'),
  noteP('La pile du module Adafruit DS3231 (réf. 5188) est une CR1220, une pile PRIMAIRE. Le module n’a pas de circuit de charge — contrairement aux modules clones ZS-042. Ne pas y mettre d’accu rechargeable LIR2032.'),

  h2('4.5  Régler l’altitude du lieu'),
  p('Aller sur la page AMBIANCE à la molette, appuyer brièvement pour entrer, tourner par pas de 10 m, appuyer de nouveau pour sortir et enregistrer. Malte : 0 m. Massongy : environ 500 m.'),
  p('Rappel : ce réglage n’influence que l’affichage du QNH. Il ne change pas d’un iota le pourcentage d’oxygène mesuré.'),

  h2('4.6  Calibration à l’air'),
  step(1, 'Cellule à l’air libre, hors du té de prélèvement, loin de tout souffle et de toute source de chaleur.'),
  step(2, 'Page MESURE. Appui long de 1,5 s sur la molette. L’arc de progression se remplit, l’écran annonce CALIBRER ; relâcher.'),
  step(3, 'L’appareil intègre pendant 4 s, puis affiche la tension de référence et la pression correspondante.'),
  step(4, 'Si la lecture est instable ou hors de la fenêtre 4 à 35 mV, la calibration est refusée et l’écran le dit. Recommencer après avoir laissé la cellule se stabiliser.'),
  warnP('Une cellule neuve doit chauffer environ 30 minutes après installation avant de donner une lecture reproductible. C’est une propriété de la cellule, pas un défaut du montage.'),
  p('La calibration est enregistrée en mémoire non volatile avec sa pression et son horodatage. Au démarrage suivant, elle est rechargée telle quelle si elle a moins de 24 h ; au-delà, l’appareil redémarre non calibré et le réclame. Une cellule dérive : il est plus sûr de repartir d’un point à l’air frais.'),
  new Paragraph({ children: [new PageBreak()] }),
);

// =========================================================================
body.push(
  h1('5.  Manuel d’utilisation'),
  lead('Tout se fait à la molette. Deux niveaux, cinq pages, trois gestes.'),

  h2('5.1  La grammaire de la molette'),
  gap(60),
  table(
    ['Geste', 'En navigation', 'Dans la page (après appui court)'],
    [
      ['Rotation', 'changer de page', 'régler la valeur de la page'],
      ['Appui court', 'entrer dans la page', 'sortir'],
      ['Appui long 1,5 s', 'MESURE : calibrer à l’air', 'MESURE figée : enregistrer au journal'],
      ['Appui long 2,5 s', 'JOURNAL : effacer le journal', '—'],
    ],
    [2300, 3600, 3738]),
  gap(),
  p('Pendant un appui long, un arc de progression se remplit et le nom de l’action s’affiche. Relâcher avant la fin annule.'),

  h2('5.2  Les cinq pages'),
  gap(60),
  table(
    ['Page', 'Affiche', 'La molette y règle'],
    [
      ['1  MESURE', '%O2 en grand, nom du mélange, tension cellule, pression, MOD de la consigne',
       'rien — l’appui court fige et défige la lecture'],
      ['2  PLONGÉE', 'profondeur maxi en grand pour la consigne retenue, les trois consignes',
       'la consigne ppO2 : 1,2 / 1,4 / 1,6 bar'],
      ['3  AMBIANCE', 'pression absolue, température, altitude et QNH, date et heure, facteur de compensation',
       'l’altitude du lieu, par pas de 10 m'],
      ['4  JOURNAL', 'une entrée à la fois : %O2, date, heure, température, tension, pression, MOD',
       'le défilement dans les entrées'],
      ['5  CELLULE', 'tension instantanée, verdict de santé, tension de référence, âge de la calibration',
       'rien — page de lecture seule'],
    ],
    [1700, 4400, 3538]),
  gap(),
  p('La couronne circulaire porte une grandeur sur chaque page : le %O2 sur MESURE, PLONGÉE et JOURNAL avec le même dégradé, la température sur AMBIANCE, la tension de référence sur CELLULE. Deux pages qui montrent la même grandeur se comparent donc à l’œil, sans lire les chiffres.'),

  h2('5.3  L’anneau lumineux'),
  gap(60),
  table(
    ['Couleur', 'Signification'],
    [
      ['vert fixe', 'mesure valide et stabilisée'],
      ['ambre pulsant', 'acquisition en cours, la lecture n’est pas encore stable'],
      ['bleu', 'calibration en cours'],
      ['rouge pulsant', 'pas encore calibré'],
      ['rouge fixe', 'défaut : ADS1115 injoignable ou cellule hors plage'],
    ],
    [2600, 7038]),

  h2('5.4  Mesurer un bloc'),
  step(1, 'Monter le té de prélèvement et son restricteur sur le robinet. La cellule ne doit JAMAIS voir la pression du bloc.', 'Montage'),
  step(2, 'Ouvrir très lentement. Le débit utile est de 0,5 à 2 L/min ; un débit excessif fait lire TROP HAUT.', 'Débit'),
  step(3, 'Attendre que le bandeau passe de ACQUISITION à VERROUILLÉ et que l’anneau passe au vert. Compter 30 à 60 s.', 'Attente'),
  step(4, 'Appui court : la lecture se fige, le bandeau affiche FIGÉ. Fermer le robinet.', 'Gel'),
  step(5, 'Appui long 1,5 s : la mesure part au journal avec sa date, sa pression et sa température.', 'Enregistrement'),
  step(6, 'Appui court pour défiger et revenir en mesure continue.', 'Retour'),
  warnP('Ne jamais se fier à une lecture prise pendant que le bandeau affiche ACQUISITION. Le firmware refuse de la qualifier de stable pour une bonne raison.'),

  h2('5.5  Relire et récupérer le journal'),
  p('À l’écran : page JOURNAL, appui court pour entrer, rotation pour défiler. L’entrée 1 est la plus récente. La barre sous le bandeau indique la position dans la pile.'),
  p('Sur ordinateur : brancher l’USB, ouvrir le moniteur série à 115200 bauds et envoyer la commande d. Le fichier CSV complet est déversé entre deux lignes repères ; il suffit de sélectionner, copier et coller dans un tableur.'),
  gap(60),
  table(
    ['Commande', 'Effet'],
    [
      ['d', 'déverse le journal CSV sur la liaison série'],
      ['i', 'état des périphériques, de la calibration et de l’ambiance'],
      ['T<epoch>', 'règle l’horloge, par exemple T1790000000'],
      ['?', 'aide'],
    ],
    [2200, 7438], [0]),
  gap(),
  noteP('Le séparateur est le point-virgule : Excel et LibreOffice en configuration française ouvrent le fichier directement, sans assistant d’importation.'),
  p('Chaque ligne porte le champ ref_mv, c’est-à-dire la tension de référence à l’air au moment de la mesure. C’est ce champ qui permettra, dans deux ans, de tracer la courbe de vieillissement de la cellule à partir du seul journal.'),

  h2('5.6  Recalibrer'),
  p('Retirer la cellule du té, la laisser à l’air libre, page MESURE, appui long 1,5 s. Recalibrer systématiquement : au début de chaque séance d’analyse, après un changement d’altitude, après un changement marqué de température, et après tout remplacement de cellule.'),
  new Paragraph({ children: [new PageBreak()] }),
);

// =========================================================================
body.push(
  h1('6.  Dépannage'),
  gap(60),
  table(
    ['Symptôme', 'Cause probable', 'Remède'],
    [
      ['Écran noir, carte alimentée', 'PSRAM non réglée sur OPI PSRAM, ou GPIO1/GPIO2 non forcées à l’état haut',
       'vérifier le réglage PSRAM ; ne jamais recabler GPIO1 et GPIO2, setup() s’en charge'],
      ['Moniteur série muet, croquis qui tourne', 'USB CDC On Boot sur Disabled',
       'passer sur Enabled et reteléverser'],
      ['Aucun port dans le menu Outils', 'câble de charge sans fils de données',
       'changer de câble ; sinon forcer le mode téléversement (3.6)'],
      ['ERREUR ADS1115 au démarrage', 'cordon sur le bus du tactile, ou module non alimenté',
       'bus externe GPIO38/39 ; vérifier le 3V3 du module'],
      ['Écran de bilan : JOURNAL --', 'profil de partition sans partition « spiffs »',
       'Partition Scheme = Huge APP (3MB No OTA/1MB SPIFFS), puis reteléverser'],
      ['« mémoire seule » à l’enregistrement', 'même cause que ci-dessus',
       'même remède ; les mesures restent en RAM jusqu’à l’extinction'],
      ['Écran de bilan : BARO --', 'BMP581 ni en 0x46 ni en 0x47, ou cordon QT mal enfoncé',
       'refaire un scan I2C avec test_cellule.ino'],
      ['Horodatages absurdes', 'DS3231 jamais réglé, ou pile CR1220 absente',
       'commande T<epoch> ; vérifier la pile'],
      ['ERREUR CELLULE à la calibration', 'tension hors de 4 à 35 mV : jack mal enfoncé, cellule épuisée',
       'mesurer la cellule au multimètre ; 7 à 13 mV attendus dans l’air'],
      ['INSTABLE à la calibration', 'courant d’air, cellule qui n’a pas fini de chauffer, mode commun',
       'attendre ; vérifier la reprise de masse à l’embase (2.3)'],
      ['Lecture erratique, multimètre normal', 'cellule flottante hors plage de mode commun',
       'reprendre la masse À L’EMBASE jack, pas sur la carte'],
      ['Lecture systématiquement haute', 'débit de prélèvement trop fort',
       'ouvrir plus lentement ; viser 0,5 à 2 L/min'],
      ['« pression suspecte » sur AMBIANCE', 'rapport P_cal/P hors de 0,80 à 1,25',
       'recalibrer sur place ; sinon suspecter le BMP581'],
      ['CELLULE FAIBLE au démarrage', 'référence à l’air sous 6,00 mV',
       'commander une cellule ; l’appareil reste utilisable en attendant'],
      ['Reste en ACQUISITION sans jamais verrouiller', 'bruit supérieur au seuil de stabilité',
       'relever l’écart pic-à-pic avec test_cellule.ino et traiter la cause (4.2)'],
      ['ADC MUET à l’écran', 'plus aucune conversion depuis 2,5 s : cordon I2C débranché à chaud, ou module hors tension',
       'vérifier le cordon ; si le défaut persiste avec 0x48 présent au scan, revoir le mode de lecture (2.8)'],
      ['ERREUR CELLULE annonçant 0,00 mV', 'aucun échantillon reçu, pas une cellule absente',
       'signature du piège du § 2.8 ; vérifier que le firmware est bien en 2.1.1 ou plus récent'],
    ],
    [2900, 3400, 3338]),
  new Paragraph({ children: [new PageBreak()] }),
);

// =========================================================================
body.push(
  h1('7.  Annexes'),

  h2('A.  Brochage et bus'),
  gap(60),
  table(
    ['Fonction', 'Broche', 'Remarque'],
    [
      ['Bus I2C externe SDA', 'GPIO38', 'ADS1115, BMP581, DS3231 en chaîne QT'],
      ['Bus I2C externe SCL', 'GPIO39', ''],
      ['Bus tactile CST816D', 'GPIO6 / GPIO7', 'non utilisé, reste libre'],
      ['Alimentation dalle', 'GPIO1', 'forcée haute par setup() — sans cela, écran noir'],
      ['Anode rétroeclairage', 'GPIO2', 'idem'],
      ['Rétroeclairage', 'GPIO46', 'actif haut'],
      ['LCD SCLK / MOSI / DC / CS / RST', '10 / 11 / 3 / 9 / 14', 'GC9A01, SPI2_HOST à 80 MHz'],
      ['Encodeur A / B / bouton', 'GPIO45 / 42 / 41', 'bouton actif bas ; 45 et 46 sont des broches de strapping'],
      ['Anneau WS2812', 'GPIO48', '5 pixels'],
      ['Cellule O2', 'AIN0 / AIN1 de l’ADS1115', 'différentiel ; pointe du jack = O2+, corps = O2−'],
    ],
    [3100, 2400, 4138], [1]),

  h2('B.  Format du journal'),
  code('epoch;pct_o2;mv;ref_mv;hpa;temp_c;ppo2;mod_m'),
  code('1790000000;32.14;18.4021;12.0034;955.27;21.40;1.40;33.8'),
  gap(60),
  table(
    ['Champ', 'Unité', 'Signification'],
    [
      ['epoch', 's', 'heure Unix de la mesure, DS3231'],
      ['pct_o2', '%', 'fraction d’oxygène, compensée en pression'],
      ['mv', 'mV', 'tension cellule au moment du gel'],
      ['ref_mv', 'mV', 'tension de référence à l’air de la calibration en vigueur'],
      ['hpa', 'hPa', 'pression absolue de la mesure, BMP581'],
      ['temp_c', '°C', 'température de la mesure'],
      ['ppo2', 'bar', 'consigne retenue au moment de l’enregistrement'],
      ['mod_m', 'm', 'profondeur maxi correspondante, eau de mer'],
    ],
    [2000, 1400, 6238], [0]),

  h2('C.  Formules'),
  p('Pourcentage d’oxygène, compensé en pression :'),
  code('FO2 = 20,9 x (V / V_cal) x (P_cal / P)'),
  p('Profondeur maxi d’utilisation, en mètres d’eau de mer :'),
  code('MOD = 10 x ( ppO2 / (FO2/100) - 1 )'),
  p('QNH réduit au niveau de la mer pour l’altitude réglée, atmosphère standard OACI — affichage seulement :'),
  code('QNH = P / (1 - alt/44330,77)^5,255'),
  p('Résolution de la chaîne de mesure, gain ×16 :'),
  code('1 LSB = 0,256 V / 32768 = 7,8125 uV'),

  h2('D.  Vérifications faites sur cette version'),
  bul('Compilation sans avertissement sous g++ -Wall -Wextra -Wformat=2, avec des en-têtes de substitution pour LovyanGFX, ADS1X15, NeoPixel, BMP5xx, RTClib, Preferences et LittleFS.', 'Compilation'),
  bul('Quarante contrôles numériques : compensation en pression et son garde-fou, bornes du %O2, table des MOD, nom du mélange sur toute la plage 0 à 100 %, aller-retour du format CSV, calcul du QNH.', 'Calculs'),
  bul('Pile du journal éprouvée à 100 entrées dans un tampon de 40 : ordre, plafond, relecture du fichier.', 'Journal'),
  bul('Chaque élément graphique échantillonné et comparé à la couronne dessinée, pour garantir qu’aucun texte ni aucune pastille n’est rogné par la lunette ronde. Trois collisions réelles ont été trouvées et corrigées par ce contrôle.', 'Mise en page'),
  bul('Noms exacts et versions des bibliothèques relevés dans leurs fichiers library.properties ; profils de partition relevés dans boards.txt et dans les fichiers CSV du cœur esp32.', 'Sources'),
  bul('Mode de lecture de l’ADS1115 vérifié dans le source de la bibliothèque (Adafruit_ADS1X15.cpp) et non d’après sa documentation : c’est ce qui a permis d’identifier le piège du § 2.8.', 'Acquisition'),
  bul('Essais sur le matériel réel : affichage, encodeur, BMP581, DS3231, journal et acquisition de la cellule en fonctionnement. Reste la campagne gaz, annexe E.', 'Matériel'),

  h2('E.  Protocole de la campagne gaz'),
  lead('À faire à Malte, en une séance. Tout tient dans le journal de l’appareil : aucune prise de notes.'),
  p('Objectif double : mesurer la justesse absolue sur des gaz connus, et vérifier la linéarité de la cellule sur toute la plage utile. Une cellule galvanique se dégrade d’abord par perte de linéarité dans le haut de la plage — c’est pourquoi l’oxygène pur est le point le plus informatif, et le premier à dériver.'),
  step(1, 'Calibrer à l’air au début de la séance, cellule à l’air libre. Noter la tension de référence affichée sur la page CELLULE.', 'Calibration'),
  step(2, 'Pour chaque gaz disponible, dans cet ordre : air, EAN32, EAN36, EAN40, oxygène pur. Débit 0,5 à 2 L/min, attendre VERROUILLÉ, figer, appui long pour enregistrer.', 'Série montante'),
  step(3, 'Refaire un point à l’air en fin de série, sans recalibrer. L’écart avec le premier point mesure la dérive pendant la séance : s’il dépasse 0,3 point de %O2, la séance est à refaire au calme.', 'Point de contrôle'),
  step(4, 'Vider le journal par la commande d et coller dans un tableur.', 'Récupération'),
  step(5, 'Tracer %O2 mesuré en fonction du %O2 réel. Une cellule saine donne une droite passant par l’origine, de pente 1 à mieux que 1 %. Une pente correcte en bas de plage mais un écrasement au-dessus de 60 % signe une cellule en fin de vie, même si sa tension à l’air reste normale.', 'Dépouillement'),
  warnP('L’oxygène pur exige un matériel compatible oxygène et des mains propres de tout corps gras. Si le montage de prélèvement n’est pas qualifié O2, s’arrêter à l’EAN40 : trois points suffisent à détecter une non-linéarité franche.'),
  noteP('Si la campagne ne peut être faite qu’en partie, garder l’air et l’EAN32 : ce sont les deux points qui valident l’usage courant. L’EAN36 et l’EAN40 affinent la pente, l’oxygène pur teste le pire cas.'),

  h2('F.  Sources'),
  bul('Espressif, arduino-esp32 — boards.txt et tools/partitions/*.csv (étiquettes de partition).', ''),
  bul('Adafruit — library.properties de Adafruit BMP5xx Library 1.0.2, RTClib 2.1.4, Adafruit ADS1X15 2.6.2, Adafruit NeoPixel 1.15.5.', ''),
  bul('lovyan03 — LovyanGFX, LGFXBase.hpp et lgfx_fonts.hpp (primitives anticrénelées et fontes DejaVu).', ''),
  bul('Elecrow — wiki CrowPanel 1,28 pouce HMI Rotary Display (brochage, configuration du panneau GC9A01).', ''),
  bul('Vandagraph — fiche technique de la cellule R-17VAN, réf. 0110217 (sortie 7 à 13 mV dans l’air).', ''),
  bul('Texas Instruments — fiche technique ADS1115 (plage de mode commun, bruit en fonction du PGA).', ''),
);

// =========================================================================
const doc = new Document({
  creator: 'Stephan 9H2WB / F5OWB',
  title: 'Analyseur Nitrox v2.1 — installation et mise en oeuvre',
  numbering: {
    config: [{
      reference: 'puces',
      levels: [{
        level: 0, format: LevelFormat.BULLET, text: '•',
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 340, hanging: 220 } } },
      }],
    }],
  },
  styles: {
    default: {
      heading1: { run: { font: F, size: 28, bold: true, color: ACC } },
      heading2: { run: { font: F, size: 23, bold: true, color: ACC } },
    },
  },
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838, orientation: PageOrientation.PORTRAIT },
        margin: { top: 1134, bottom: 1134, left: 1134, right: 1134 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: 'C8CCD4', space: 4 } },
          children: [new TextRun({
            text: 'Analyseur Nitrox v2.1  ·  9H2WB / F5OWB',
            font: F, size: 16, color: GREY })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ children: [PageNumber.CURRENT], font: F, size: 16, color: GREY })],
        })],
      }),
    },
    children: body,
  },
  ...['schema_nitrox_v211.png', 'nomenclature_nitrox_v211.png'].map((f, i) => ({
    properties: {
      page: {
        // docx-js permute lui-meme largeur et hauteur : on passe les cotes
        // du portrait et l'orientation paysage.
        size: { width: 11906, height: 16838, orientation: PageOrientation.LANDSCAPE },
        margin: { top: 720, bottom: 720, left: 720, right: 720 },
      },
    },
    children: [
      new Paragraph({
        spacing: { after: 100 },
        children: [new TextRun({
          text: (i ? 'Annexe G  —  nomenclature complete'
                   : 'Annexe G  —  schema de principe'),
          font: F, size: 23, bold: true, color: ACC })],
      }),
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new ImageRun({
          type: 'png',
          data: fs.readFileSync('/home/claude/nitrox_v2/' + f),
          transformation: { width: 900, height: 636 },
        })],
      }),
    ],
  })),
  ],
});

Packer.toBuffer(doc).then((b) => {
  fs.writeFileSync('/home/claude/nitrox_v2/Nitrox_v21_installation_et_mise_en_oeuvre.docx', b);
  console.log('docx ecrit :', b.length, 'octets');
});
