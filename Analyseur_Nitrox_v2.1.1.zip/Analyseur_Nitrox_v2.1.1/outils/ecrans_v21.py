#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Maquettes des ecrans — Analyseur Nitrox v2.1 phase 2.
Reproduit a l'identique la geometrie et la palette du firmware :
memes rayons, memes angles, memes coordonnees, memes corps de caractere.
Sert aussi de controle de decoupe : chaque chaine est mesuree et comparee a la
corde utile du cercle a sa hauteur.
"""
import math, os
from PIL import Image, ImageDraw, ImageFont

S      = 4                  # suréchantillonnage
W      = 240
CX = CY = 120
ARC_R0, ARC_R1 = 96, 112
TICK_R0, TICK_R1 = 116, 123
ARC_START, ARC_SPAN = 135.0, 270.0

def c565(v):
    r = (v >> 11) & 0x1F; g = (v >> 5) & 0x3F; b = v & 0x1F
    return (r * 255 // 31, g * 255 // 63, b * 255 // 31)

COL_BG    = c565(0x0000); COL_FG   = c565(0xFFFF); COL_TEXT = c565(0xE73C)
COL_DIM   = c565(0x8410); COL_MUTE = c565(0x4208); COL_TRACK = c565(0x1884)
COL_CARD  = c565(0x10A2); COL_GREEN = c565(0x0390); COL_TEAL = c565(0x035C)
COL_BLUE  = c565(0x429F); COL_AMBER = c565(0xFAC4); COL_RED  = c565(0xF929)
ARC_C0    = c565(0x07BF); ARC_C1   = c565(0x0391)

FDIR = "/usr/share/fonts/truetype/dejavu"
_cache = {}
def F(n):
    if n not in _cache:
        _cache[n] = ImageFont.truetype(os.path.join(FDIR, "DejaVuSans.ttf"), n * S)
    return _cache[n]

warn = []

# --- controle de decoupe -------------------------------------------------
# Un element est en faute s il empiete sur la partie DESSINEE de la couronne :
# l anneau de rayon ARC_R0..TICK_R1, mais seulement sur les 270 degres traces.
# L ouverture basse est libre : c est la qu on place les pastilles et les points
# de pagination. On echantillonne la forme reelle (rectangle de texte, stade
# pour une pastille), pas sa boite englobante : un coin de pastille est arrondi.
def _hits(px, py):
    dx, dy = px - CX, py - CY
    r = math.hypot(dx, dy)
    if r < ARC_R0 - 1 or r > TICK_R1 + 1:
        return False
    a = math.degrees(math.atan2(dy, dx)) % 360.0
    if a < ARC_START:
        a += 360.0
    return a <= ARC_START + ARC_SPAN

def rect_pts(cx, cy, hw, hh, step=1.5):
    n = max(2, int(2 * hw / step)); m = max(2, int(2 * hh / step))
    return [(cx - hw + 2 * hw * i / n, cy - hh + 2 * hh * j / m)
            for i in range(n + 1) for j in range(m + 1)]

def stadium_pts(cx, cy, w, h, step=1.5):
    r = h / 2.0
    inner = w / 2.0 - r
    pts = rect_pts(cx, cy, max(inner, 0.0), r, step)
    for sx in (-1, 1):
        ox = cx + sx * inner
        k = max(8, int(2 * math.pi * r / step))
        for i in range(k + 1):
            t = 2 * math.pi * i / k
            pts.append((ox + r * math.cos(t), cy + r * math.sin(t)))
    return pts

def check(name, y, pts):
    bad = [p for p in pts if _hits(*p)]
    if bad:
        worst = max(bad, key=lambda p: math.hypot(p[0] - CX, p[1] - CY))
        warn.append(f'{name} a y={y:.0f} : {len(bad)} point(s) sur la couronne, '
                    f'le plus loin a r={math.hypot(worst[0]-CX, worst[1]-CY):.0f} px')

# --------------------------------------------------------------------------
def lerp(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(a[i] + (b[i] - a[i]) * t + 0.5) for i in range(3))

def polar(deg, r):
    a = math.radians(deg)
    return CX + math.cos(a) * r, CY + math.sin(a) * r

class Screen:
    def __init__(self):
        self.im = Image.new("RGB", (W * S, W * S), COL_BG)
        self.d  = ImageDraw.Draw(self.im)

    def arc_band(self, a0, a1, r0, r1, col):
        self.d.arc([ (CX - (r0 + r1) / 2) * S, (CY - (r0 + r1) / 2) * S,
                     (CX + (r0 + r1) / 2) * S, (CY + (r0 + r1) / 2) * S ],
                   a0, a1, fill=col, width=int((r1 - r0) * S))

    def gauge(self, frac, c0, c1):
        self.arc_band(ARC_START, ARC_START + ARC_SPAN, ARC_R0, ARC_R1, COL_TRACK)
        rmid, cap = (ARC_R0 + ARC_R1) / 2, (ARC_R1 - ARC_R0) // 2
        if frac <= 0.0005: return
        x, y = polar(ARC_START, rmid); self.dot(x, y, cap, c0)
        span = ARC_SPAN * frac
        N = 30
        for i in range(N):
            a0 = ARC_START + span * i / N
            a1 = ARC_START + span * (i + 1) / N
            self.arc_band(a0, a1 + 0.6, ARC_R0, ARC_R1,
                          lerp(c0, c1, (a0 - ARC_START) / ARC_SPAN))
        x, y = polar(ARC_START + span, rmid)
        self.dot(x, y, cap, lerp(c0, c1, frac))
        self.dot(x, y, cap - 5, COL_FG)

    def ticks(self, minor=COL_TRACK, major=COL_MUTE):
        for i in range(41):
            deg = ARC_START + ARC_SPAN * i / 40.0
            big = (i % 4 == 0)
            x0, y0 = polar(deg, TICK_R0 - 3 if big else TICK_R0)
            x1, y1 = polar(deg, TICK_R1)
            self.d.line([x0 * S, y0 * S, x1 * S, y1 * S],
                        fill=major if big else minor,
                        width=int((2.8 if big else 1.4) * S))

    def dot(self, x, y, r, col):
        self.d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S],
                       fill=col)

    def tw(self, txt, n):
        return self.d.textlength(txt, font=F(n)) / S

    def text(self, txt, x, y, col, n, anchor="mm"):
        self.d.text((x * S, y * S), txt, font=F(n), fill=col, anchor=anchor)
        hw, hh = self.tw(txt, n) / 2, n * 0.62
        check(f'"{txt}"', y, rect_pts(x, y, hw, hh))

    def pill(self, cx, cy, h, fill, border, txt, txtcol, n, minw):
        tw = self.tw(txt, n)
        w  = max(tw + h, minw)
        r  = h / 2
        box = [(cx - w / 2) * S, (cy - h / 2) * S,
               (cx + w / 2) * S, (cy + h / 2) * S]
        if fill != COL_BG:
            self.d.rounded_rectangle(box, radius=r * S, fill=fill)
        if border != COL_BG:
            self.d.rounded_rectangle(box, radius=r * S, outline=border,
                                     width=int(1.6 * S))
        self.d.text((cx * S, cy * S), txt, font=F(n), fill=txtcol, anchor="mm")
        check(f'pastille "{txt}"', cy, stadium_pts(cx, cy, w, h))

    def chip(self, txt, col, filled):
        if filled: self.pill(CX, 48, 22, col, COL_BG, txt, COL_BG, 12, 60)
        else:      self.pill(CX, 48, 22, COL_CARD, col, txt, col, 12, 60)

    def dots(self, cur, n=5):
        step = 13; x0 = CX - (n - 1) * step / 2
        for i in range(n):
            x = x0 + i * step
            self.dot(x, 224, 3 if i == cur else 2,
                     COL_FG if i == cur else COL_MUTE)

    def finish(self):
        # masque rond + lunette, comme la dalle reelle
        m = Image.new("L", (W * S, W * S), 0)
        ImageDraw.Draw(m).ellipse([0, 0, W * S - 1, W * S - 1], fill=255)
        out = Image.new("RGB", (W * S, W * S), (14, 14, 16))
        out.paste(self.im, (0, 0), m)
        d = ImageDraw.Draw(out)
        d.ellipse([1 * S, 1 * S, (W - 1) * S, (W - 1) * S],
                  outline=(46, 48, 54), width=int(2.5 * S))
        return out.resize((W, W), Image.LANCZOS)

# --------------------------------------------------------------------------
def page_mesure():
    s = Screen()
    s.gauge(32.1 / 100.0, ARC_C0, ARC_C1); s.ticks()
    s.chip("VERROUILLE", COL_GREEN, True)
    s.text("32.1", 108, 110, COL_FG, 56)
    s.text("%", 178, 92, COL_DIM, 18)
    s.text("EAN32", CX, 150, COL_GREEN, 18)
    s.text("18.43 mV  955 hPa", CX, 171, COL_DIM, 12)
    s.pill(CX, 196, 24, COL_CARD, COL_MUTE, "MOD 33 m  1.4", COL_TEXT, 12, 120)
    s.dots(0)
    return s.finish(), "1 · MESURE"

def page_plongee():
    s = Screen()
    s.gauge(32.1 / 100.0, ARC_C0, ARC_C1); s.ticks()
    s.chip("EAN32", COL_DIM, False)
    s.text("33", 108, 100, COL_FG, 56)
    s.text("m", 160, 114, COL_DIM, 18)
    s.text("profondeur maxi", CX, 138, COL_DIM, 12)
    s.text("32.1 % O2", CX, 157, COL_TEXT, 12)
    for i, v in enumerate(("1.2", "1.4", "1.6")):
        x = CX + (i - 1) * 42
        if i == 1: s.pill(x, 182, 24, COL_CARD, COL_TEAL, v, COL_FG, 12, 44)
        else:      s.pill(x, 182, 24, COL_BG, COL_BG, v, COL_MUTE, 12, 44)
    s.text("appui : choisir la ppO2", CX, 206, COL_MUTE, 9)
    s.dots(1)
    return s.finish(), "2 · PLONGEE"

def page_ambiance():
    s = Screen()
    s.gauge(21.4 / 40.0, COL_TEAL, COL_TEAL); s.ticks()
    s.chip("AMBIANCE", COL_DIM, False)
    s.text("955.3", 100, 96, COL_FG, 40)
    s.text("hPa", 172, 104, COL_DIM, 12)
    s.text("21.4 C", CX, 128, COL_TEAL, 18)
    s.pill(CX, 152, 20, COL_BG, COL_BG, "alt 500 m   QNH 1014", COL_DIM, 12, 100)
    s.text("24/09/2026  14:32", CX, 174, COL_DIM, 12)
    s.text("compens. x1.0610", CX, 197, COL_TEXT, 12)
    s.dots(2)
    return s.finish(), "3 · AMBIANCE"

def page_journal():
    s = Screen()
    s.gauge(36.0 / 100.0, ARC_C0, ARC_C1); s.ticks()
    s.chip("3 / 12", COL_TEAL, True)
    x = CX - 55
    s.d.rounded_rectangle([x * S, 66 * S, (x + 110) * S, 69 * S],
                          radius=1.5 * S, fill=COL_TRACK)
    s.d.rounded_rectangle([(x + 20) * S, 66 * S, (x + 29) * S, 69 * S],
                          radius=1.5 * S, fill=COL_TEAL)
    s.text("36.0", 104, 104, COL_FG, 40)
    s.text("%", 164, 94, COL_DIM, 12)
    s.text("23/09  17:04   21 C", CX, 137, COL_TEXT, 12)
    s.text("20.67 mV   955 hPa", CX, 156, COL_DIM, 12)
    s.pill(CX, 182, 22, COL_CARD, COL_MUTE, "MOD 28 m  1.4", COL_TEXT, 12, 118)
    s.text("molette : defiler", CX, 204, COL_MUTE, 9)
    s.dots(3)
    return s.finish(), "4 · JOURNAL"

def page_cellule():
    s = Screen()
    s.gauge((12.0 - 4.0) / 10.0, COL_GREEN, COL_GREEN); s.ticks()
    s.chip("CELLULE", COL_DIM, False)
    s.text("12.02", 102, 100, COL_FG, 40)
    s.text("mV", 168, 108, COL_DIM, 12)
    s.text("neuve", CX, 134, COL_GREEN, 18)
    s.text("ref 12.00 mV  955 hPa", CX, 158, COL_DIM, 12)
    s.pill(CX, 184, 22, COL_CARD, COL_MUTE, "cal. 2 h 14", COL_TEXT, 12, 120)
    s.dots(4)
    return s.finish(), "5 · CELLULE"

def page_hold():
    s = Screen()
    s.arc_band(ARC_START, ARC_START + ARC_SPAN, ARC_R0, ARC_R1, COL_TRACK)
    s.arc_band(ARC_START, ARC_START + ARC_SPAN * 0.72, ARC_R0, ARC_R1, COL_TEAL)
    s.ticks()
    s.text("CALIBRER", CX, CY - 14, COL_FG, 18)
    s.text("maintenir", CX, CY + 22, COL_DIM, 12)
    return s.finish(), "appui long · arc de progression"

def page_uncal():
    s = Screen()
    s.gauge(0.0, COL_RED, COL_RED); s.ticks()
    s.chip("NON CALIBRE", COL_RED, True)
    s.text("appui long 1,5 s", CX, 112, COL_FG, 18)
    s.text("cellule a l'air libre", CX, 142, COL_DIM, 12)
    s.text("12.02 mV", CX, 168, COL_DIM, 12)
    s.dots(0)
    return s.finish(), "etat initial · non calibre"

def page_flash():
    s = Screen()
    s.gauge(32.1 / 100.0, ARC_C0, ARC_C1); s.ticks()
    s.chip("FIGE", COL_TEAL, True)
    s.text("32.1", 108, 110, COL_FG, 56)
    s.text("%", 178, 92, COL_DIM, 18)
    s.text("EAN32", CX, 150, COL_TEAL, 18)
    s.text("18.43 mV  955 hPa", CX, 171, COL_DIM, 12)
    s.pill(CX, 196, 24, COL_CARD, COL_MUTE, "MOD 33 m  1.4", COL_TEXT, 12, 120)
    s.pill(CX, 212, 22, COL_TEAL, COL_BG, "enregistre", COL_BG, 12, 110)
    return s.finish(), "mesure figee · enregistrement"

# --------------------------------------------------------------------------
pages = [page_mesure(), page_plongee(), page_ambiance(),
         page_journal(), page_cellule(), page_uncal(), page_hold(), page_flash()]

COLS, PAD, LAB = 4, 26, 26
rows = (len(pages) + COLS - 1) // COLS
CW, CH = W + PAD, W + PAD + LAB
sheet = Image.new("RGB", (CW * COLS + PAD, CH * rows + PAD), (24, 25, 28))
sd = ImageDraw.Draw(sheet)
lab = ImageFont.truetype(os.path.join(FDIR, "DejaVuSans-Bold.ttf"), 13)

for i, (im, title) in enumerate(pages):
    cx = PAD + (i % COLS) * CW
    cy = PAD + (i // COLS) * CH
    sheet.paste(im, (cx, cy))
    sd.text((cx + W // 2, cy + W + 15), title, font=lab,
            fill=(196, 200, 208), anchor="mm")

sheet.save("/home/claude/nitrox_v2/ecrans_v21.png")
print(f"ecrans_v21.png  {sheet.size[0]}x{sheet.size[1]}")
print(f"{len(warn)} avertissement(s) de decoupe")
for w in warn:
    print("  !", w)
