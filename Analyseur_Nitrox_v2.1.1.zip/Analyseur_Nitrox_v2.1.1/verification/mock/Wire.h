#pragma once
#include "Arduino.h"
class TwoWire { public:
  bool begin(int sda, int scl, uint32_t freq);
  void beginTransmission(uint8_t);
  uint8_t endTransmission();
};
extern TwoWire Wire;
extern TwoWire Wire1;
