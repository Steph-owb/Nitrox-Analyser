#pragma once
#include "Arduino.h"
enum wifi_mode_t { WIFI_OFF, WIFI_STA };
class WiFiClass { public: bool mode(wifi_mode_t); };
extern WiFiClass WiFi;
