#pragma once
#include "Arduino.h"
class Preferences {
public:
  bool begin(const char *name, bool readOnly = false);
  void end();
  size_t putFloat(const char*, float);
  size_t putUInt(const char*, uint32_t);
  size_t putInt(const char*, int32_t);
  size_t putUChar(const char*, uint8_t);
  float    getFloat(const char*, float);
  uint32_t getUInt(const char*, uint32_t);
  int32_t  getInt(const char*, int32_t);
  uint8_t  getUChar(const char*, uint8_t);
};
