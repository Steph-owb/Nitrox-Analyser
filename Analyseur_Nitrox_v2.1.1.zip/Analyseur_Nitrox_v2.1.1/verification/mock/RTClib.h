#pragma once
#include "Arduino.h"
#include "Wire.h"
class DateTime {
public:
  DateTime(uint32_t unixt);
  DateTime(const char *date, const char *time);
  uint16_t year() const; uint8_t month() const; uint8_t day() const;
  uint8_t hour() const;  uint8_t minute() const; uint8_t second() const;
  uint32_t unixtime() const;
};
class RTC_DS3231 {
public:
  bool begin(TwoWire *w = &Wire);
  bool lostPower();
  void adjust(const DateTime&);
  DateTime now();
  float getTemperature();
};
