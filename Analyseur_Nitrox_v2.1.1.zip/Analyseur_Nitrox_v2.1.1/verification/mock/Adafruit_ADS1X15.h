#pragma once
#include "Arduino.h"
#include "Wire.h"
enum adsGain_t { GAIN_TWOTHIRDS, GAIN_ONE, GAIN_TWO, GAIN_FOUR, GAIN_EIGHT, GAIN_SIXTEEN };
#define ADS1X15_ADDRESS 0x48
#define ADS1X15_REG_CONFIG_MUX_DIFF_0_1 0x0000
enum { RATE_ADS1115_8SPS, RATE_ADS1115_16SPS, RATE_ADS1115_32SPS, RATE_ADS1115_64SPS,
       RATE_ADS1115_128SPS, RATE_ADS1115_250SPS, RATE_ADS1115_475SPS, RATE_ADS1115_860SPS };
class Adafruit_ADS1115 {
public:
  bool begin(uint8_t addr = ADS1X15_ADDRESS, TwoWire *w = &Wire);
  void setGain(adsGain_t);
  void setDataRate(uint16_t);
  void startADCReading(uint16_t mux, bool continuous);
  bool conversionComplete();
  int16_t getLastConversionResults();
  float computeVolts(int16_t);
};
