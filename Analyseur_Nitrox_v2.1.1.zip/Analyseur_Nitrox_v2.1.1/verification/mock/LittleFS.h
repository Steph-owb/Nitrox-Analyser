#pragma once
#include "Arduino.h"
class File {
public:
  operator bool() const;
  int available();
  int read();
  size_t print(const char*);
  int printf(const char*, ...) __attribute__((format(printf,2,3)));
  void close();
};
class FSImpl {
public:
  bool begin(bool formatOnFail = false);
  File open(const char *path, const char *mode);
  bool exists(const char *path);
  bool remove(const char *path);
};
extern FSImpl LittleFS;
