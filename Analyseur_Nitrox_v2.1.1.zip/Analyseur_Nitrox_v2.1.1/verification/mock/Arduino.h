#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#define HIGH 1
#define LOW 0
#define INPUT_PULLUP 2
#define OUTPUT 1
#define CHANGE 3
#define IRAM_ATTR
#define SPI2_HOST 1
#define SPI_DMA_CH_AUTO 3
unsigned long millis();
void delay(unsigned long);
void pinMode(uint8_t, uint8_t);
void digitalWrite(uint8_t, uint8_t);
int  digitalRead(uint8_t);
void noInterrupts();
void interrupts();
int  digitalPinToInterrupt(int);
void attachInterrupt(int, void(*)(), int);
class HardwareSerial { public:
  void begin(unsigned long);
  void print(const char*);
  void println(const char*);
  void println();
  int  printf(const char*, ...) __attribute__((format(printf,2,3)));
  int  available();
  int  read();
  size_t write(uint8_t);
};
#define F(x) (x)
extern HardwareSerial Serial;
