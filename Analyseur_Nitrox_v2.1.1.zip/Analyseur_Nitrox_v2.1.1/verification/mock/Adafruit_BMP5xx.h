#pragma once
#include "Arduino.h"
#include "Wire.h"
enum bmp5xx_oversampling_t { BMP5XX_OVERSAMPLING_1X, BMP5XX_OVERSAMPLING_2X,
  BMP5XX_OVERSAMPLING_4X, BMP5XX_OVERSAMPLING_8X, BMP5XX_OVERSAMPLING_16X,
  BMP5XX_OVERSAMPLING_32X, BMP5XX_OVERSAMPLING_64X, BMP5XX_OVERSAMPLING_128X };
enum bmp5xx_iir_filter_t { BMP5XX_IIR_FILTER_BYPASS, BMP5XX_IIR_FILTER_COEFF_1,
  BMP5XX_IIR_FILTER_COEFF_3, BMP5XX_IIR_FILTER_COEFF_7,
  BMP5XX_IIR_FILTER_COEFF_15, BMP5XX_IIR_FILTER_COEFF_31,
  BMP5XX_IIR_FILTER_COEFF_63, BMP5XX_IIR_FILTER_COEFF_127 };
enum bmp5xx_powermode_t { BMP5XX_POWERMODE_STANDBY, BMP5XX_POWERMODE_NORMAL,
  BMP5XX_POWERMODE_FORCED, BMP5XX_POWERMODE_CONTINOUS,
  BMP5XX_POWERMODE_DEEP_STANDBY };
#define BMP5XX_DEFAULT_ADDRESS 0x46
#define BMP5XX_ALTERNATIVE_ADDRESS 0x47
class Adafruit_BMP5xx {
public:
  bool begin(uint8_t addr = BMP5XX_DEFAULT_ADDRESS, TwoWire *w = &Wire);
  bool performReading();
  bool dataReady();
  float readTemperature();
  float readPressure();
  float readAltitude(float seaLevel = 1013.25f);
  bool setTemperatureOversampling(bmp5xx_oversampling_t);
  bool setPressureOversampling(bmp5xx_oversampling_t);
  bool setIIRFilterCoeff(bmp5xx_iir_filter_t);
  bool setPowerMode(bmp5xx_powermode_t);
  float temperature;
  float pressure;
};
