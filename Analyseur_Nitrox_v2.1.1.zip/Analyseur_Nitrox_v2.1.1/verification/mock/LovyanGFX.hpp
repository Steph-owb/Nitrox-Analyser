#pragma once
#include "Arduino.h"

enum class textdatum_t { middle_center, middle_left, top_left };

namespace lgfx {

struct IFont { int dummy; };

struct BusCfg {
  int spi_host, spi_mode; uint32_t freq_write, freq_read;
  bool spi_3wire, use_lock; int dma_channel;
  int pin_sclk, pin_mosi, pin_miso, pin_dc;
};
struct PanelCfg {
  int pin_cs, pin_rst, pin_busy;
  int memory_width, memory_height, panel_width, panel_height;
  int offset_x, offset_y, offset_rotation;
  int dummy_read_pixel, dummy_read_bits;
  bool readable, invert, rgb_order, dlen_16bit, bus_shared;
};

class Bus_SPI {
public:
  BusCfg config() const;
  void config(const BusCfg&);
};

class Panel_GC9A01 {
public:
  PanelCfg config() const;
  void config(const PanelCfg&);
  void setBus(Bus_SPI*);
};

class LGFXBase {
public:
  void fillScreen(uint16_t);
  void fillSprite(uint16_t);
  void fillArc(int32_t x, int32_t y, int32_t r0, int32_t r1,
               float a0, float a1, const uint16_t& color);
  void setFont(const IFont*);
  void setTextColor(uint16_t fg, uint16_t bg);
  void setTextDatum(textdatum_t);
  void drawString(const char*, int32_t x, int32_t y);
  int32_t textWidth(const char*);
  int32_t fontHeight();
  void drawRoundRect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t r,
                     const uint16_t& color);
  void fillSmoothRoundRect(int32_t x, int32_t y, int32_t w, int32_t h,
                           int32_t r, const uint16_t& color);
  void fillSmoothCircle(int32_t x, int32_t y, int32_t r,
                        const uint16_t& color);
  void drawWideLine(int32_t x0, int32_t y0, int32_t x1, int32_t y1,
                    float r, const uint16_t& color);
};

class LGFX_Device : public LGFXBase {
public:
  bool init();
  void setRotation(uint8_t);
  void setPanel(Panel_GC9A01*);
};

} // namespace lgfx

namespace fonts {
  extern const lgfx::IFont Font2;
  extern const lgfx::IFont Font4;
  extern const lgfx::IFont Font7;
  extern const lgfx::IFont DejaVu9;
  extern const lgfx::IFont DejaVu12;
  extern const lgfx::IFont DejaVu18;
  extern const lgfx::IFont DejaVu24;
  extern const lgfx::IFont DejaVu40;
  extern const lgfx::IFont DejaVu56;
}

class LGFX_Sprite : public lgfx::LGFXBase {
public:
  LGFX_Sprite(lgfx::LGFX_Device*);
  void setPsram(bool);
  void setColorDepth(uint8_t);
  void* createSprite(int32_t w, int32_t h);
  void pushSprite(int32_t x, int32_t y);
};
