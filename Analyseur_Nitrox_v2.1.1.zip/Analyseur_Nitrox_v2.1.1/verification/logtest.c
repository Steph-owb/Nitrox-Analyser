/* Controle de la pile du journal : insertion en tete, plafond, ordre */
#include <stdio.h>
#define LOG_RAM 40
typedef struct { unsigned id; } E;
static E buf[LOG_RAM]; static unsigned char cnt = 0;

static void push(E e) {
  unsigned char n = (cnt < LOG_RAM) ? cnt : (unsigned char)(LOG_RAM - 1);
  for (unsigned char i = n; i > 0; i--) buf[i] = buf[i-1];
  buf[0] = e;
  if (cnt < LOG_RAM) cnt++;
}
int main(void) {
  int fail = 0;
  /* 100 entrees dans un tampon de 40 */
  for (unsigned i = 1; i <= 100; i++) { E e = { i }; push(e); }
  if (cnt != LOG_RAM) { printf("ECHEC compte = %u\n", cnt); fail++; }
  /* buf[0] doit etre la plus recente (100), buf[39] la 61e */
  if (buf[0].id != 100) { printf("ECHEC tete = %u, attendu 100\n", buf[0].id); fail++; }
  if (buf[LOG_RAM-1].id != 61) { printf("ECHEC queue = %u, attendu 61\n", buf[LOG_RAM-1].id); fail++; }
  for (int i = 0; i < LOG_RAM; i++)
    if (buf[i].id != (unsigned)(100 - i)) { printf("ECHEC ordre en %d : %u\n", i, buf[i].id); fail++; break; }
  /* remplissage partiel */
  cnt = 0;
  for (unsigned i = 1; i <= 3; i++) { E e = { i }; push(e); }
  if (cnt != 3 || buf[0].id != 3 || buf[2].id != 1) { printf("ECHEC remplissage partiel\n"); fail++; }
  /* Relecture du fichier : les lignes sont ecrites de la plus ancienne a la
     plus recente, donc push() dans cet ordre remet bien la plus recente en 0. */
  cnt = 0;
  unsigned fichier[5] = { 10, 11, 12, 13, 14 };      /* ordre du CSV */
  for (int i = 0; i < 5; i++) { E e = { fichier[i] }; push(e); }
  if (buf[0].id != 14) { printf("ECHEC relecture CSV : tete = %u, attendu 14\n", buf[0].id); fail++; }
  printf(fail ? "*** %d ECHEC(S) ***\n" : "pile du journal : conforme (%d echec)\n", fail);
  return fail != 0;
}
