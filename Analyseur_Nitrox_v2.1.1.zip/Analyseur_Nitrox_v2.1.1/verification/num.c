/* Verification numerique — Analyseur Nitrox v2.1 phase 2 */
#include <stdio.h>
#include <string.h>
#include <math.h>

#define AIR 20.9f
#define PRATIO_MIN 0.80f
#define PRATIO_MAX 1.25f
#define MODMAX 99.9f

static int fails = 0;
static void ck(const char *what, int ok, const char *fmt, double a, double b) {
  if (!ok) { printf("  ECHEC  %-38s ", what); printf(fmt, a, b); printf("\n"); fails++; }
}

static float pratio(float calH, float p, int baroOk) {
  if (!baroOk || calH <= 0.f || p <= 0.f) return 1.f;
  float r = calH / p;
  if (r < PRATIO_MIN || r > PRATIO_MAX) return 1.f;
  return r;
}
static float o2pct(float mv, float calMv, float calH, float p, int baroOk) {
  if (calMv <= 0.f) return 0.f;
  float x = AIR * (mv / calMv) * pratio(calH, p, baroOk);
  if (x < 0.f) x = 0.f; if (x > 100.f) x = 100.f;
  return x;
}
static float mod(float pct, float pp) {
  if (pct < 1.f) return MODMAX;
  float d = 10.f * ((pp / (pct/100.f)) - 1.f);
  if (d < 0.f) d = 0.f; if (d > MODMAX) d = MODMAX;
  return d;
}
static void gasName(float pct, char *o, size_t n) {
  if (pct >= 99.f) snprintf(o,n,"O2 PUR");
  else if (pct >= 20.4f && pct <= 21.4f) snprintf(o,n,"AIR");
  else snprintf(o,n,"EAN%.0f",(double)pct);
}
static float qnh(float p, int alt) {
  float f = 1.f - ((float)alt/44330.77f); if (f<0.1f) f=0.1f;
  return p / powf(f, 5.255f);
}

int main(void) {
  printf("=== 1. Compensation en pression ===\n");
  /* Cellule reelle de Stephan : 12,0 mV a l'air. */
  float calMv = 12.00f, calH = 1013.25f;

  /* Meme lieu, meme pression : la correction doit etre neutre. */
  float p = o2pct(calMv, calMv, calH, calH, 1);
  ck("air, meme pression = 20,9 %", fabsf(p-20.9f) < 0.001f, "%.4f vs %.4f", p, 20.9);

  /* EAN32 : la cellule donne 12,0 * 32/20,9 = 18,373 mV a 1013 hPa. */
  float mvE32 = calMv * (32.0f/20.9f);
  p = o2pct(mvE32, calMv, calH, 1013.25f, 1);
  ck("EAN32 a la pression de cal.", fabsf(p-32.0f) < 0.01f, "%.3f vs %.3f", p, 32.0);

  /* Massongy ~500 m : 955 hPa. La cellule voit une ppO2 plus basse. */
  float pMass = 955.0f;
  float mvMass = mvE32 * (pMass/1013.25f);       /* meme FO2, moins de pression */
  float brut = AIR * (mvMass/calMv);             /* sans compensation */
  float corr = o2pct(mvMass, calMv, calH, pMass, 1);
  printf("  cal Malte 1013 hPa, mesure Massongy 955 hPa, EAN32 reel :\n");
  printf("    sans compensation : %.2f %%   (erreur %+.2f pt)\n", (double)brut, (double)(brut-32.0f));
  printf("    avec compensation : %.2f %%   (erreur %+.2f pt)\n", (double)corr, (double)(corr-32.0f));
  ck("sans comp. lit bas d'env. 1,8 pt", fabsf(brut-30.16f) < 0.05f, "%.3f vs %.3f", brut, 30.16);
  ck("avec comp. retrouve 32,0 %", fabsf(corr-32.0f) < 0.01f, "%.4f vs %.4f", corr, 32.0);

  /* Garde-fou : rapport aberrant -> correction neutralisee, pas de derapage. */
  p = o2pct(mvE32, calMv, 1013.25f, 700.0f, 1);   /* ratio 1,447 > 1,25 */
  ck("rapport aberrant neutralise", fabsf(p-32.0f) < 0.01f, "%.3f vs %.3f", p, 32.0);
  ck("ratio hors plage = 1,0", pratio(1013.25f, 700.f, 1) == 1.0f, "%.3f vs %.3f", (double)pratio(1013.25f,700.f,1), 1.0);
  ck("baro absent = 1,0", pratio(1013.25f, 955.f, 0) == 1.0f, "%.3f vs %.3f", (double)pratio(1013.25f,955.f,0), 1.0);
  /* Meteo ordinaire : 25 hPa d'ecart, doit etre compense. */
  ck("meteo 988 hPa compensee", fabsf(pratio(1013.25f, 988.f, 1) - 1013.25f/988.f) < 1e-6f, "%.6f vs %.6f", (double)pratio(1013.25f,988.f,1), (double)(1013.25f/988.f));

  printf("\n=== 2. Bornes du %%O2 ===\n");
  ck("mv nul -> 0 %", o2pct(0.f, calMv, calH, calH, 1) == 0.0f, "%.3f vs %.3f", (double)o2pct(0,calMv,calH,calH,1), 0.0);
  ck("mv enorme -> plafond 100 %", o2pct(500.f, calMv, calH, calH, 1) == 100.0f, "%.3f vs %.3f", (double)o2pct(500,calMv,calH,calH,1), 100.0);
  ck("mv negatif -> 0 %", o2pct(-3.f, calMv, calH, calH, 1) == 0.0f, "%.3f vs %.3f", (double)o2pct(-3,calMv,calH,calH,1), 0.0);
  ck("calMv nul -> 0 %", o2pct(12.f, 0.f, calH, calH, 1) == 0.0f, "%.3f vs %.3f", (double)o2pct(12,0,calH,calH,1), 0.0);

  printf("\n=== 3. MOD ===\n");
  struct { float pct, pp, want; } M[] = {
    {32.f,1.4f,33.75f}, {32.f,1.6f,40.0f}, {32.f,1.2f,27.5f},
    {36.f,1.4f,28.89f}, {40.f,1.6f,30.0f}, {21.f,1.4f,56.67f},
    {100.f,1.6f,6.0f},  {99.f,1.4f,4.14f}
  };
  for (unsigned i=0;i<sizeof(M)/sizeof(M[0]);i++) {
    float g = mod(M[i].pct, M[i].pp);
    char nm[48]; snprintf(nm,sizeof(nm),"MOD %.0f%% @ %.1f", (double)M[i].pct,(double)M[i].pp);
    ck(nm, fabsf(g-M[i].want) < 0.02f, "%.2f vs %.2f", g, M[i].want);
  }
  ck("pct 0 -> plafond", mod(0.f,1.4f)==MODMAX, "%.2f vs %.2f", (double)mod(0,1.4f), MODMAX);
  /* Un melange tres pauvre donnerait une MOD > 99,9 m : elle doit etre bornee. */
  ck("pct 5 -> borne 99,9", mod(5.f,1.4f)==MODMAX, "%.2f vs %.2f", (double)mod(5,1.4f), MODMAX);

  printf("\n=== 4. Nom du melange, sur toute la plage ===\n");
  int nbad=0, wmax=0;
  for (int i=0;i<=1000;i++) {
    float v=(float)i*0.1f; char nm[12]; gasName(v,nm,sizeof(nm));
    int L=(int)strlen(nm); if (L>wmax) wmax=L;
    if (L>=(int)sizeof(nm)) nbad++;
  }
  ck("aucun debordement de buffer", nbad==0, "%.0f vs %.0f", (double)nbad, 0.0);
  printf("  longueur maxi du nom : %d caracteres (buffer 12)\n", wmax);
  { char nm[12];
    gasName(20.9f,nm,sizeof nm); ck("20,9 -> AIR", !strcmp(nm,"AIR"), "%.0f vs %.0f",0.0,0.0);
    gasName(21.4f,nm,sizeof nm); ck("21,4 -> AIR", !strcmp(nm,"AIR"), "%.0f vs %.0f",0.0,0.0);
    gasName(21.5f,nm,sizeof nm); ck("21,5 -> EAN22", !strcmp(nm,"EAN22"), "%.0f vs %.0f",0.0,0.0);
    gasName(20.3f,nm,sizeof nm); ck("20,3 -> EAN20", !strcmp(nm,"EAN20"), "%.0f vs %.0f",0.0,0.0);
    gasName(32.0f,nm,sizeof nm); ck("32,0 -> EAN32", !strcmp(nm,"EAN32"), "%.0f vs %.0f",0.0,0.0);
    gasName(99.6f,nm,sizeof nm); ck("99,6 -> O2 PUR", !strcmp(nm,"O2 PUR"), "%.0f vs %.0f",0.0,0.0);
  }

  printf("\n=== 5. Aller-retour CSV du journal ===\n");
  {
    unsigned long st=1790000000UL; double pc=32.14,mv=18.4021,rf=12.0034,hp=955.27,tp=21.4,pp=1.4,md=33.8;
    char line[160];
    snprintf(line,sizeof(line),"%lu;%.2f;%.4f;%.4f;%.2f;%.2f;%.2f;%.1f\n",st,pc,mv,rf,hp,tp,pp,md);
    printf("  ligne : %s", line);
    ck("ligne sous 160 octets", strlen(line)<159, "%.0f vs %.0f",(double)strlen(line),159.0);
    unsigned long s2=0; double a[7]={0};
    int got=sscanf(line,"%lu;%lf;%lf;%lf;%lf;%lf;%lf;%lf",&s2,&a[0],&a[1],&a[2],&a[3],&a[4],&a[5],&a[6]);
    ck("8 champs relus", got==8, "%.0f vs %.0f",(double)got,8.0);
    ck("horodatage conserve", s2==st, "%.0f vs %.0f",(double)s2,(double)st);
    ck("pct conserve a 0,01", fabs(a[0]-pc)<0.005, "%.4f vs %.4f",a[0],pc);
    ck("mv conserve a 0,1 uV", fabs(a[1]-mv)<0.00005, "%.5f vs %.5f",a[1],mv);
    ck("hPa conserve", fabs(a[3]-hp)<0.005, "%.4f vs %.4f",a[3],hp);
    /* L'en-tete ne doit pas etre pris pour une entree. */
    const char *hdr="epoch;pct_o2;mv;ref_mv;hpa;temp_c;ppo2;mod_m";
    ck("en-tete rejete (1er car. non chiffre)", !(hdr[0]>='0'&&hdr[0]<='9'), "%.0f vs %.0f",0.0,0.0);
  }

  printf("\n=== 6. QNH depuis l'altitude reglee ===\n");
  ck("alt 0 -> QNH = P mesuree", fabsf(qnh(1013.25f,0)-1013.25f)<0.01f, "%.2f vs %.2f",(double)qnh(1013.25f,0),1013.25);
  printf("  Massongy 500 m, P=955 hPa -> QNH %.1f hPa\n",(double)qnh(955.f,500));
  ck("Massongy QNH plausible", qnh(955.f,500)>1010.f && qnh(955.f,500)<1020.f, "%.2f vs %.2f",(double)qnh(955.f,500),1013.0);
  ck("alt bornee, pas de division par 0", qnh(955.f,4000)>0.f, "%.2f vs %.2f",(double)qnh(955.f,4000),0.0);

  printf("\n=== 7. Largeur des chaines affichees ===\n");
  { char b[48]; int m=0;
    snprintf(b,sizeof b,"%.2f mV  %.0f hPa",(double)62.0,(double)1250.0); if((int)strlen(b)>m)m=(int)strlen(b);
    printf("  ligne mV/hPa, pire cas : \"%s\" (%d car.)\n",b,(int)strlen(b));
    snprintf(b,sizeof b,"MOD %.0f m  %.1f",(double)99.9,(double)1.6); printf("  pastille MOD     : \"%s\" (%d car.)\n",b,(int)strlen(b));
    snprintf(b,sizeof b,"alt %d m   QNH %.0f",4000,(double)1099.0); printf("  ligne altitude   : \"%s\" (%d car.)\n",b,(int)strlen(b));
    snprintf(b,sizeof b,"compens. O2  x%.4f",(double)1.2499); printf("  pastille compens.: \"%s\" (%d car.)\n",b,(int)strlen(b));
    snprintf(b,sizeof b,"%.2f mV  %.0f hPa  %.0f C",(double)62.0,(double)1250.0,(double)-40.0); printf("  ligne journal    : \"%s\" (%d car.)\n",b,(int)strlen(b));
    snprintf(b,sizeof b,"calibree il y a %lu h %02lu",23UL,59UL); printf("  pastille cal.    : \"%s\" (%d car.)\n",b,(int)strlen(b));
    snprintf(b,sizeof b,"%.1f bar   %.0f m",(double)1.6,(double)99.9); printf("  ligne ppO2       : \"%s\" (%d car.)\n",b,(int)strlen(b));
  }

  printf("\n%s  (%d echec%s)\n", fails?"*** DES CONTROLES ONT ECHOUE ***":"TOUS LES CONTROLES PASSENT",
         fails, fails==1?"":"s");
  return fails!=0;
}
