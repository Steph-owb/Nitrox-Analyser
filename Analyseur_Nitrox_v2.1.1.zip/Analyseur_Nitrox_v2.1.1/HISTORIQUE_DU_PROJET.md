# Analyseur Nitrox — historique du projet

Journal de conception, de la question initiale à la version 2.1.1.
Stephan, 9H2WB / F5OWB — septembre 2026.

Ce fichier existe pour une raison : dans deux ans, la question ne sera pas
« comment ça marche » — la documentation le dit — mais « pourquoi c'est fait
comme ça ». Les décisions sont ici avec leurs motifs, y compris celles qui ont
été prises puis défaites.

---

## 1. Point de départ

La question initiale était commerciale : quel est le meilleur prix pour un
analyseur nitrox sur le marché européen, la solution open source n'étant pas à
exclure.

Le comparatif a montré un marché à deux étages. En bas, des appareils à 180–250 €
dont la cellule représente l'essentiel du coût et qui n'apportent rien de plus
qu'un voltmètre bien calibré. En haut, des appareils à 400 € et plus, dont les
fonctions supplémentaires (log, MOD, compensation) sont du logiciel.

Conclusion : la valeur ajoutée d'un achat se situe dans le logiciel, pas dans la
métrologie. C'est exactement la part qu'on peut faire soi-même. Le projet DIY
s'est imposé à partir de là, pas par économie mais parce que la fonction
recherchée était celle qui se programme.

Le firmware EJ Labs a été examiné comme point de comparaison. Bon travail, mais
architecture figée sur un affichage donné.

---

## 2. Contrainte matérielle : pas de circuit imprimé

Contrainte posée d'emblée : impossible de faire graver un PCB à Malte dans des
délais raisonnables. Tout devait tenir en modules du commerce et câblage fil à
fil, avec des composants trouvables chez fabian.com.mt ou par correspondance.

Matériel déjà en main : Teensy 4.0, clones Arduino Nano.

**Décision — Nano plutôt que Teensy.** Le Teensy 4.0 est en 3,3 V et n'accepte
pas 5 V sur ses entrées. L'afficheur LCD 2 lignes disponible localement est un
module 5 V. Le Nano supprime tout adaptateur de niveau. La puissance de calcul
n'entrait pas en ligne de compte : il s'agit de moyenner vingt-quatre valeurs.

---

## 3. Le choix de la cellule a été dicté par la mécanique

**Cellule retenue : Vandagraph R-17VAN, référence 0110217.**

Le choix ne s'est pas fait sur la métrologie — les cellules galvaniques du marché
se valent à quelques pourcents près — mais sur deux détails mécaniques :

- **jack mono 3,5 mm** déjà monté, donc aucune connectique à fabriquer ;
- **filetage M16×1**, qui est le standard des tés de prélèvement du commerce.

Ces deux points suppriment tout usinage. Une cellule moins chère avec des
cosses à souder et un filetage exotique aurait coûté une soirée d'atelier et un
risque de fuite.

Sortie nominale : 7 à 13 mV dans l'air. Mesuré sur l'exemplaire reçu : **12,0 mV**,
donc au-dessus du milieu de la fenêtre neuve.

---

## 4. Le prélèvement et le calcul du restricteur

La cellule ne doit **jamais** voir la pression du bloc. Le montage retenu est un
té de prélèvement DIN 300 à sortie libre, avec un restricteur calibré.

Le diamètre de perçage a été calculé en écoulement sonique (bloqué) : au-delà
d'un rapport de pression de 1,893 pour l'air, le débit ne dépend plus que de la
pression amont et de la section. Coefficient de décharge retenu Cd = 0,62, qui
reste une hypothèse à ±10 % tant qu'un débitmètre ne l'aura pas confirmée.

**Correction en cours de route.** La première version du dossier retenait
0,2 L/min, valeur reprise d'une fiche Divesoft isolée. Recoupement sur cinq
sources : le débit utile est de **0,5 à 2 L/min**. L'erreur n'était pas neutre —
un débit excessif fait lire **trop haut**, donc dans le sens dangereux.

---

## 5. v1.2 — Arduino Nano et LCD deux lignes

Première version complète : Nano, ADS1115, LCD 16×2, LED verte OK et LED rouge
ERREUR, alimentation pile.

**Cette version reste vivante et n'est pas remplacée.** Son écran LCD est
réflectif positif : il **gagne** en contraste au soleil, là où un IPS rétroéclairé
en perd. C'est l'instrument de terrain. La v2 est l'instrument de référence,
avec le journal et la compensation.

Corrections trouvées à la vérification de cette version :

- **Débordement de l'affichage 16 caractères.** À 100 % d'O2, le format produisait
  17 caractères. Trouvé par un banc d'essai en C balayant toute la plage de
  valeurs, pas à la lecture.
- **Seuil de stabilité sous le bruit de l'ADC.** Le critère était fixé à 20 µV,
  soit moins que le bruit propre de l'ADS1115 en PGA ±256 mV (1 à 2 LSB, soit 8
  à 16 µV RMS). Il n'aurait jamais pu être satisfait : l'appareil serait resté
  éternellement « en acquisition ». Relevé au plus grand de 50 µV et 0,4 %.
- **Seuil de cellule faible au-dessus du minimum d'une cellule neuve.** Fixé à
  8 mV, il aurait signalé comme usée une R-17VAN neuve mais basse, dont la fiche
  garantit 7 mV. Abaissé à 6,0 mV, et la borne basse de calibration de 5,0 à 4,0 mV.

**Un schéma refusé.** Le premier synoptique était un assemblage de rectangles.
Refait avec de vrais symboles IEC, broches numérotées, croix de non-connexion,
étiquettes de net et cartouche. schemdraw n'étant pas disponible, les symboles
ont été construits à la main en matplotlib.

---

## 6. v2.0 — CrowPanel 1,28 pouce, ESP32-S3

La contrainte qui imposait le 5 V — l'afficheur LCD — disparaissait si
l'afficheur changeait. Le CrowPanel 1,28" HMI Rotary est un module complet :
ESP32-S3, dalle ronde 240×240 GC9A01, encodeur à poussoir, anneau RGB, PSRAM.

Ce qu'il permettait et que le Nano ne permettait pas : horodatage, journal,
sélection de la consigne ppO2, affichage simultané des MOD, et une interface
qui ne soit pas deux lignes de seize caractères.

**Règle de conception posée à ce moment : le tactile n'est jamais un passage
obligé.** Une dalle capacitive ne répond ni aux doigts mouillés ni aux gants,
c'est-à-dire précisément dans les conditions d'emploi. Le bus du tactile
(GPIO6/7) est resté libre et la molette fait tout.

**Deux pièges non documentés du CrowPanel**, trouvés dans le wiki Elecrow et
inscrits en tête du firmware :

- **GPIO1 et GPIO2 doivent être forcées à l'état haut** dans `setup()`, sinon le
  panneau reste noir sans autre symptôme ;
- **le bus I2C externe est sur GPIO38/39**, pas sur celui du tactile.

Matériel commandé chez BerryBase et reçu en France : accu LiPo, PowerBoost 1000C,
ADS1115 Adafruit, cellule Vandagraph, CrowPanel. Puis, dans un second temps,
BMP581 et DS3231 Adafruit, chaînés en STEMMA QT.

Point de détail qui a failli être une erreur : le module **Adafruit DS3231 (5188)
utilise une pile CR1220 primaire et n'a pas de circuit de charge** — contrairement
aux modules clones ZS-042. Un accu rechargeable LIR2032 y serait inapproprié.
L'avertissement initial, écrit pour les clones, a été retiré.

---

## 7. Phase 1 — mesure et calibration

Consigne explicite reçue avant l'écriture du firmware, et qui était la bonne :
**ADS1115 en mode différentiel AIN0/AIN1, gain ×16**. Retenu tel quel.

Raisons inscrites au dossier : une cellule galvanique est une source flottante de
quelques millivolts ; en asymétrique, toute chute de tension dans le retour de
masse s'ajoute au signal. En différentiel elle est commune aux deux entrées et
s'élimine. Le gain ×16 donne ±256 mV pour une plage utile de 7 à 62 mV.

**Liaison Kelvin.** Le négatif de la cellule part vers AIN1 **et** vers la masse,
cette reprise étant prise à l'embase jack et non sur la carte. Une cellule
entièrement flottante peut sortir de la plage de tension de mode commun de
l'ADS1115 et produire des lectures erratiques — avec un multimètre qui affiche
une tension parfaitement normale à ses bornes. C'est le genre de panne qu'on
cherche une soirée.

**Radio coupée** dès le début de `setup()`. Une radio qui tire 240 mA en crête
sur le même rail, à deux centimètres d'un front-end à 10 mV, est un problème
qu'il vaut mieux ne pas avoir à diagnostiquer. L'autonomie gagnée est un bonus,
pas le motif.

---

## 8. Phase 2 — la compensation en pression

L'ajout du BMP581 et du DS3231 a été présenté comme un ajout de confort
(horodatage, log). Il s'est révélé **métrologiquement déterminant**.

Une cellule galvanique ne mesure pas une fraction d'oxygène : elle mesure une
pression partielle. `V = k · FO2 · Pabs`. Donc :

```
FO2 = 0,209 × (V / V_cal) × (P_cal / P)
```

Chiffré sur le cas réel — calibration à Malte au niveau de la mer, mesure à
Massongy vers 500 m :

| | sans compensation | avec compensation |
|---|---|---|
| EAN32 réel mesuré à 955 hPa | 30,16 % | 32,00 % |
| MOD annoncée à ppO2 1,4 | 36,4 m | 33,8 m |

L'erreur va toujours dans le sens dangereux : le mélange paraît plus pauvre
qu'il n'est, donc la profondeur calculée est trop optimiste de trois mètres.

**Décision — l'altitude réglable n'entre pas dans le calcul.** Le %O2 est corrigé
par la pression **absolue**, qui ne demande aucun étalonnage. L'altitude réglée
dans la page AMBIANCE ne sert qu'à afficher un QNH lisible. Un réglage qui
influencerait la mesure serait un réglage qu'on peut fausser.

Garde-fou : la correction est neutralisée si le rapport P_cal/P sort de 0,80 à
1,25, et l'écran affiche « pression suspecte ». Au-delà, ce n'est plus de la
météo.

**Journal.** Chaque entrée porte l'horodatage, le %O2, la tension, la pression,
la température, la consigne, la MOD — et surtout `ref_mv`, la tension de
référence à l'air en vigueur. C'est ce champ qui permettra de reconstruire la
courbe de vieillissement de la cellule à partir du seul journal.

---

## 9. Refonte graphique

Retour reçu sur la première interface : « pas très joli ». Refonte complète dans
l'esprit des démonstrations CrowPanel : arc dégradé à capuchons arrondis et pointe
blanche, couronne de graduations, pastilles anticrénelées, typographie DejaVu
56/40/18/12 au lieu des fontes bitmap, cinq pages en carrousel.

**Interface à deux niveaux**, comme un bouton intelligent : la rotation change de
page, l'appui court entre dans la page et la rotation règle alors sa valeur. Les
appuis longs affichent un arc de progression, de sorte qu'on voit l'action
arriver et qu'on peut renoncer avant de relâcher.

**Contrôle de découpe.** Un banc d'essai échantillonne la forme réelle de chaque
élément — rectangle pour un texte, stade pour une pastille — et la compare à la
couronne dessinée, en tenant compte de l'ouverture basse. Il a trouvé **trois
collisions réelles** que la relecture visuelle avait laissées passer : le bandeau
de la page PLONGÉE, la pastille de compensation, et une ligne du journal à
25 caractères. Corrigées.

Corollaire de méthode : sur un écran rond, l'œil ne suffit pas. La lunette rogne
les coins et une chaîne qui rentre à 32 % d'O2 ne rentre plus à 100 %.

---

## 10. Deux erreurs trouvées après coup

### Le profil de partition

Recommandation initiale : « 16M Flash (3MB APP/9.9MB FATFS) ». **Fausse.**

Vérification dans `boards.txt` et les CSV du cœur esp32 : LittleFS monte par
défaut la partition dont **l'étiquette** est `spiffs`. Or les deux profils 16 Mo
de l'IDE ne créent qu'une partition `ffat`. Avec eux, `LittleFS.begin()` échoue
silencieusement et le journal n'est jamais écrit sur le flash.

Profil correct : **Huge APP (3MB No OTA/1MB SPIFFS)** — 3 Mo d'application et
896 ko de journal, soit environ 14 000 mesures. L'OTA ne sert à rien puisque la
radio est coupée.

Dans la foulée : le journal était écrit mais **inaccessible**, le téléverseur
LittleFS de l'IDE sachant écrire dans la partition, pas la lire. Quatre commandes
série ont été ajoutées — `d` déverse le CSV, `i` donne l'état complet, `T<epoch>`
règle l'horloge, `?` l'aide.

### Le mode continu de l'ADS1115

Trouvé aux premiers essais sur le matériel réel, et c'est la plus instructive.

L'acquisition démarrait le convertisseur en **mode continu**, puis attendait
`conversionComplete()` avant chaque lecture. Or cette fonction lit le bit OS du
registre de configuration, et ce bit vaut **0 tant que le convertisseur
convertit**. En mode continu il convertit sans interruption : le bit reste à 0
indéfiniment, la fonction ne répond jamais vrai, **aucun échantillon n'entre dans
la fenêtre**.

Symptôme : moyenne à 0,00 mV, donc calibration refusée sous le seuil bas de 4 mV,
avec le message « ERREUR CELLULE — vérifier le câblage ». Le firmware envoyait
chercher la panne exactement là où elle n'était pas, alors que le câblage était
juste et que le multimètre lisait 12 mV.

Indice qui aurait dû alerter : **la bibliothèque Adafruit n'emploie le mode
continu dans aucune de ses propres fonctions de lecture**. Quand une bibliothèque
n'utilise jamais un de ses propres modes, c'est rarement un oubli.

Correctif : conversions **uniques** enchaînées, avec une garde temporelle de 26 ms
pour une conversion qui en dure 31,25 à 32 éch/s. Chaque échantillon est ainsi une
conversion réelle et distincte — propriété dont dépend le critère de stabilité,
qui mesure un écart pic-à-pic : des échantillons relus deux fois feraient
paraître stable un signal qui ne l'est pas.

Deux garde-fous ajoutés pour qu'une panne d'acquisition se dénonce elle-même :
bascule en **ADC MUET** après 2,5 s sans conversion, et message distinct à la
calibration entre « aucun échantillon reçu » et « tension hors plage ».

---

## 11. État au 24 septembre 2026

**Fonctionne sur le matériel réel :** affichage, encodeur et interface cinq pages,
ADS1115 et acquisition de la cellule, BMP581, DS3231, journal LittleFS,
commandes série, compensation en pression.

**Reste à mesurer :**

| Point | Où |
|---|---|
| Écart pic-à-pic réel, radio coupée puis active | banc, `test_cellule.ino` |
| Justesse absolue sur gaz connus | campagne gaz à Malte |
| Linéarité de la cellule sur toute la plage | campagne gaz à Malte |
| Débit réel du restricteur | débitmètre à bille |
| Autonomie sur accu | rétroéclairage à fond |
| Dérive de la cellule dans le temps | se construit tout seul via `ref_mv` |

La campagne gaz se fera à Malte. Protocole en annexe E de la documentation :
cinq points en série montante, un point de contrôle à l'air en fin de série sans
recalibrer, tout dans le journal de l'appareil. Si le temps manque, garder l'air
et l'EAN32 — ce sont les deux points qui valident l'usage courant.

---

## 12. Ce qui a été appris, au-delà de cet appareil

- **Le facteur limitant n'est pas où on le croit.** L'ADS1115 en ×16 résout
  0,014 % d'O2 par pas. Toute l'incertitude vient de la cellule. Raffiner
  l'électronique n'aurait rien apporté ; surveiller la cellule, si.

- **Une panne de mesure se déguise en panne de câblage.** Deux fois dans ce
  projet — le mode commun et le mode continu — le symptôme désignait le câblage.
  Un firmware doit pouvoir dire « je ne reçois rien » et non « vérifiez votre
  câblage ».

- **Vérifier le source d'une bibliothèque, pas sa documentation.** Le piège du
  mode continu ne se voyait que dans `Adafruit_ADS1X15.cpp`.

- **Les bancs d'essai trouvent ce que la relecture laisse passer.** Débordement à
  16 caractères, seuil sous le bruit, trois collisions graphiques : aucun de ces
  défauts n'a été vu à la lecture, tous ont été trouvés par un contrôle
  automatique.
